"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Activity, Cloud, CreditCard, FileText, HelpCircle, Plus, DollarSign, AlertCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { useAuth } from "@/components/auth-provider"
import { EmptyPlaceholder } from "@/components/empty-placeholder"
import { toast } from "@/components/ui/use-toast"

export default function ClientDashboard() {
  const { user } = useAuth()
  const [dbStatus, setDbStatus] = useState<"loading" | "connected" | "disconnected">("loading")
  const [invoices, setInvoices] = useState<any[]>([]) // Assuming invoices is an array of objects

  useEffect(() => {
    async function checkDbConnection() {
      try {
        const response = await fetch("/api/health")
        const data = await response.json()
        setDbStatus(data.database === "connected" ? "connected" : "disconnected")
      } catch (error) {
        console.error("Failed to check database connection:", error)
        setDbStatus("disconnected")
      }

      // Mock invoices data for demonstration
      const mockInvoices = [
        { id: 1, dueDate: "2024-01-01", status: "PAID" },
        { id: 2, dueDate: "2023-10-05", status: "PENDING" },
        { id: 3, dueDate: "2023-11-15", status: "PENDING" },
      ]
      setInvoices(mockInvoices)

      // Check for overdue invoices
      const today = new Date()
      const overdueInvoices = invoices.filter(
        (invoice) => invoice.status === "PENDING" && new Date(invoice.dueDate) < today,
      )

      if (overdueInvoices.length > 0) {
        toast({
          title: "Overdue Invoices",
          description: `You have ${overdueInvoices.length} overdue invoice${overdueInvoices.length > 1 ? "s" : ""} that require attention.`,
          variant: "destructive",
        })
      }
    }

    checkDbConnection()
  }, [invoices])

  if (dbStatus === "loading") {
    return (
      <div className="flex-1 flex items-center justify-center w-full h-full">
        <div className="h-12 w-12 rounded-full border-4 border-fluxcloud-cyan border-t-transparent animate-spin"></div>
      </div>
    )
  }

  if (dbStatus === "disconnected") {
    return (
      <div className="flex-1 p-6 space-y-4 w-full">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Database Connection Error</AlertTitle>
          <AlertDescription>
            Unable to connect to the database. Please check your database configuration and try again.
          </AlertDescription>
        </Alert>
      </div>
    )
  }

  return (
    <div className="flex-1 w-full p-6 pb-8 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <h1 className="text-3xl font-bold tracking-tight text-white">Dashboard</h1>
        <Button className="bg-fluxcloud-cyan text-black hover:bg-fluxcloud-cyan/80 shadow-neon-cyan btn-hover-effect">
          <Plus className="mr-2 h-4 w-4" />
          Request Service
        </Button>
      </div>

      <Tabs defaultValue="overview" className="space-y-6 w-full">
        <TabsList className="bg-fluxcloud-black/40 border border-white/10 p-1">
          <TabsTrigger
            value="overview"
            className="data-[state=active]:bg-fluxcloud-cyan data-[state=active]:text-black rounded-md"
          >
            Overview
          </TabsTrigger>
          <TabsTrigger
            value="services"
            className="data-[state=active]:bg-fluxcloud-cyan data-[state=active]:text-black rounded-md"
          >
            Services
          </TabsTrigger>
          <TabsTrigger
            value="invoices"
            className="data-[state=active]:bg-fluxcloud-cyan data-[state=active]:text-black rounded-md"
          >
            Invoices
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6 w-full">
          {/* Stats Cards */}
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 w-full">
            <StatsCard
              title="Active Services"
              value="0"
              icon={<Cloud className="h-5 w-5 text-fluxcloud-cyan" />}
              description="No active services yet"
              valueColor="text-fluxcloud-cyan"
            />
            <StatsCard
              title="Pending Invoices"
              value="0"
              icon={<FileText className="h-5 w-5 text-fluxcloud-navy-yellow" />}
              description="No pending invoices"
              valueColor="text-fluxcloud-navy-yellow"
            />
            <StatsCard
              title="Total Spent"
              value="₹0.00"
              icon={<DollarSign className="h-5 w-5 text-fluxcloud-navy-green" />}
              description="No payments made yet"
              valueColor="text-fluxcloud-navy-green"
            />
          </div>

          {/* Main Content Cards */}
          <div className="grid gap-6 md:grid-cols-2 w-full">
            <Card className="bg-fluxcloud-black/40 border-white/10 shadow-lg">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <div>
                  <CardTitle className="text-xl font-bold text-white">Your Services</CardTitle>
                  <CardDescription className="text-white/70">Overview of your active cloud services</CardDescription>
                </div>
                <Cloud className="h-5 w-5 text-fluxcloud-cyan" />
              </CardHeader>
              <CardContent className="pt-6">
                <EmptyServiceState />
              </CardContent>
            </Card>

            <Card className="bg-fluxcloud-black/40 border-white/10 shadow-lg">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <div>
                  <CardTitle className="text-xl font-bold text-white">Support Tickets</CardTitle>
                  <CardDescription className="text-white/70">Your active support requests</CardDescription>
                </div>
                <HelpCircle className="h-5 w-5 text-fluxcloud-cyan" />
              </CardHeader>
              <CardContent className="pt-6">
                <EmptySupportState />
              </CardContent>
            </Card>

            <Card className="bg-fluxcloud-black/40 border-white/10 shadow-lg">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <div>
                  <CardTitle className="text-xl font-bold text-white">Upcoming Payments</CardTitle>
                  <CardDescription className="text-white/70">Your scheduled payments</CardDescription>
                </div>
                <CreditCard className="h-5 w-5 text-fluxcloud-navy-green" />
              </CardHeader>
              <CardContent className="pt-6">
                <EmptyPlaceholder
                  icon={CreditCard}
                  title="No upcoming payments"
                  description="Your upcoming payments will appear here"
                  compact
                />
              </CardContent>
            </Card>

            <Card className="bg-fluxcloud-black/40 border-white/10 shadow-lg">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <div>
                  <CardTitle className="text-xl font-bold text-white">System Status</CardTitle>
                  <CardDescription className="text-white/70">Current system performance</CardDescription>
                </div>
                <Activity className="h-5 w-5 text-fluxcloud-navy-yellow" />
              </CardHeader>
              <CardContent className="pt-6">
                <div className="text-center">
                  <div className="text-xl font-bold text-green-500 mb-2">All Systems Operational</div>
                  <p className="text-sm text-white/70">Last checked: {new Date().toLocaleTimeString()}</p>
                  <Button
                    variant="outline"
                    size="sm"
                    className="mt-4 w-full border-white/10 text-white hover:bg-white/10 hover:text-fluxcloud-cyan"
                  >
                    View System Status
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="services" className="w-full">
          <Card className="bg-fluxcloud-black/40 border-white/10 shadow-lg">
            <CardHeader>
              <CardTitle className="text-xl font-bold text-white">Your Services</CardTitle>
              <CardDescription className="text-white/70">Manage your active cloud services</CardDescription>
            </CardHeader>
            <CardContent>
              <EmptyServiceState />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="invoices" className="w-full">
          <Card className="bg-fluxcloud-black/40 border-white/10 shadow-lg">
            <CardHeader>
              <CardTitle className="text-xl font-bold text-white">Invoices</CardTitle>
              <CardDescription className="text-white/70">View and manage your invoices</CardDescription>
            </CardHeader>
            <CardContent>
              <EmptyPlaceholder
                icon={FileText}
                title="No invoices yet"
                description="Your invoices will appear here once services are billed"
                action={
                  <Button
                    variant="outline"
                    className="border-white/10 text-white hover:bg-white/10 hover:text-fluxcloud-cyan"
                  >
                    View Billing History
                  </Button>
                }
              />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

function StatsCard({
  title,
  value,
  icon,
  description,
  valueColor,
}: {
  title: string
  value: string
  icon: React.ReactNode
  description: string
  valueColor: string
}) {
  return (
    <Card className="bg-fluxcloud-black/40 border-white/10 shadow-lg">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-medium text-white">{title}</CardTitle>
        {icon}
      </CardHeader>
      <CardContent>
        <div className={`text-3xl font-bold ${valueColor}`}>{value}</div>
        <p className="text-xs text-white/70 mt-1">{description}</p>
      </CardContent>
    </Card>
  )
}

function EmptyServiceState() {
  return (
    <div className="flex flex-col items-center justify-center text-center py-8">
      <div className="bg-fluxcloud-black/60 rounded-full p-6 mb-4">
        <Cloud className="h-12 w-12 text-fluxcloud-cyan/50" />
      </div>
      <h3 className="text-lg font-semibold text-white mb-1">No services yet</h3>
      <p className="text-white/70 mb-6">Request your first service to get started</p>
      <Button className="bg-fluxcloud-cyan text-black hover:bg-fluxcloud-cyan/80 shadow-neon-cyan btn-hover-effect">
        Request Service
      </Button>
    </div>
  )
}

function EmptySupportState() {
  return (
    <div className="flex flex-col items-center justify-center text-center py-8">
      <div className="bg-fluxcloud-black/60 rounded-full p-6 mb-4">
        <HelpCircle className="h-12 w-12 text-fluxcloud-cyan/50" />
      </div>
      <h3 className="text-lg font-semibold text-white mb-1">No support tickets</h3>
      <p className="text-white/70 mb-6">Create a ticket if you need assistance</p>
      <Button className="bg-fluxcloud-black border border-white/20 text-white hover:bg-white/10 hover:text-fluxcloud-cyan">
        Create Ticket
      </Button>
    </div>
  )
}

