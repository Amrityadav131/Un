"use client"

import { useState, useEffect } from "react"
import {
  CreditCard,
  Search,
  ArrowUpDown,
  MoreHorizontal,
  AlertCircle,
  Plus,
  Download,
  Calendar,
  CheckCircle,
} from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { EmptyPlaceholder } from "@/components/empty-placeholder"
import { useAuth } from "@/components/auth-provider"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function PaymentsPage() {
  const { user } = useAuth()
  const [payments, setPayments] = useState([])
  const [paymentMethods, setPaymentMethods] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [searchQuery, setSearchQuery] = useState("")
  const [sortBy, setSortBy] = useState("date")
  const [sortOrder, setSortOrder] = useState("desc")
  const apiUrl = process.env.NEXT_PUBLIC_API_URL || "/api"

  useEffect(() => {
    const fetchPayments = async () => {
      try {
        // In a real app, this would fetch from the API
        const response = await fetch(`${apiUrl}/clients/payments`, {
          credentials: "include",
        })

        if (response.ok) {
          const data = await response.json()
          setPayments(data)
        } else {
          throw new Error("Failed to fetch payments")
        }

        // Fetch payment methods
        const methodsResponse = await fetch(`${apiUrl}/clients/payment-methods`, {
          credentials: "include",
        })

        if (methodsResponse.ok) {
          const methodsData = await methodsResponse.json()
          setPaymentMethods(methodsData)
        }

        setLoading(false)
      } catch (err) {
        console.error("Error fetching payments:", err)
        setError("Failed to load payments. Please try again.")
        setLoading(false)
      }
    }

    fetchPayments()
  }, [apiUrl])

  // Filter and sort payments
  const filteredPayments = payments
    .filter((payment) => {
      // Apply search filter
      if (searchQuery) {
        const query = searchQuery.toLowerCase()
        return (
          payment.transactionId.toLowerCase().includes(query) ||
          payment.invoiceNumber.toLowerCase().includes(query) ||
          payment.method.toLowerCase().includes(query)
        )
      }

      return true
    })
    .sort((a, b) => {
      // Apply sorting
      const aValue = a[sortBy]
      const bValue = b[sortBy]

      if (sortBy === "date") {
        return sortOrder === "asc"
          ? new Date(aValue).getTime() - new Date(bValue).getTime()
          : new Date(bValue).getTime() - new Date(aValue).getTime()
      }

      if (typeof aValue === "string") {
        return sortOrder === "asc" ? aValue.localeCompare(bValue) : bValue.localeCompare(aValue)
      }

      return sortOrder === "asc" ? aValue - bValue : bValue - aValue
    })

  const toggleSort = (field) => {
    if (sortBy === field) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc")
    } else {
      setSortBy(field)
      setSortOrder("desc")
    }
  }

  // Function to format currency
  const formatCurrency = (amount) => {
    return `₹${amount.toFixed(2)}`
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full w-full p-6">
        <div className="h-12 w-12 rounded-full border-4 border-fluxcloud-cyan border-t-transparent animate-spin"></div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="p-6 space-y-4">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
        <Button onClick={() => window.location.reload()}>Try Again</Button>
      </div>
    )
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <h1 className="text-3xl font-bold tracking-tight text-white neon-text-cyan">Payments</h1>
        <div className="flex gap-2">
          <Button variant="outline" className="border-white/10 text-white hover:bg-white/10 hover:text-fluxcloud-cyan">
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
        </div>
      </div>

      <Tabs defaultValue="history" className="w-full">
        <TabsList className="bg-fluxcloud-black/40 border border-white/10 p-1">
          <TabsTrigger
            value="history"
            className="data-[state=active]:bg-fluxcloud-cyan data-[state=active]:text-black rounded-md"
          >
            Payment History
          </TabsTrigger>
          <TabsTrigger
            value="methods"
            className="data-[state=active]:bg-fluxcloud-cyan data-[state=active]:text-black rounded-md"
          >
            Payment Methods
          </TabsTrigger>
        </TabsList>

        <TabsContent value="history" className="mt-4 space-y-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/50" />
              <Input
                placeholder="Search payments..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9 bg-white/5 border-white/10 text-white placeholder:text-white/50 focus-visible:ring-fluxcloud-cyan"
              />
            </div>
          </div>

          {filteredPayments.length === 0 ? (
            <EmptyPlaceholder
              icon={CreditCard}
              title="No payment history"
              description="Your payment history will appear here once you make payments"
            />
          ) : (
            <Card className="glass-card border-white/10">
              <CardContent className="p-0">
                <Table>
                  <TableHeader className="bg-white/5">
                    <TableRow className="border-white/10 hover:bg-white/5">
                      <TableHead className="text-white">
                        <Button
                          variant="ghost"
                          className="p-0 font-medium text-white hover:text-fluxcloud-cyan hover:bg-transparent"
                          onClick={() => toggleSort("date")}
                        >
                          Date
                          <ArrowUpDown className={`ml-2 h-4 w-4 ${sortBy === "date" ? "opacity-100" : "opacity-50"}`} />
                        </Button>
                      </TableHead>
                      <TableHead className="text-white">
                        <Button
                          variant="ghost"
                          className="p-0 font-medium text-white hover:text-fluxcloud-cyan hover:bg-transparent"
                          onClick={() => toggleSort("transactionId")}
                        >
                          Transaction ID
                          <ArrowUpDown
                            className={`ml-2 h-4 w-4 ${sortBy === "transactionId" ? "opacity-100" : "opacity-50"}`}
                          />
                        </Button>
                      </TableHead>
                      <TableHead className="text-white">Invoice</TableHead>
                      <TableHead className="text-white">Method</TableHead>
                      <TableHead className="text-white">
                        <Button
                          variant="ghost"
                          className="p-0 font-medium text-white hover:text-fluxcloud-cyan hover:bg-transparent"
                          onClick={() => toggleSort("amount")}
                        >
                          Amount
                          <ArrowUpDown
                            className={`ml-2 h-4 w-4 ${sortBy === "amount" ? "opacity-100" : "opacity-50"}`}
                          />
                        </Button>
                      </TableHead>
                      <TableHead className="text-white">Status</TableHead>
                      <TableHead className="text-right text-white">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredPayments.map((payment) => (
                      <TableRow key={payment.id} className="border-white/10 hover:bg-white/5">
                        <TableCell className="text-white/70">
                          <div className="flex items-center gap-1">
                            <Calendar className="h-3 w-3 text-white/50" />
                            <span>{new Date(payment.date).toLocaleDateString()}</span>
                          </div>
                        </TableCell>
                        <TableCell className="font-medium text-white">
                          <div className="flex items-center gap-2">
                            <CreditCard className="h-4 w-4 text-fluxcloud-cyan" />
                            <span>{payment.transactionId}</span>
                          </div>
                        </TableCell>
                        <TableCell className="text-white/70">{payment.invoiceNumber}</TableCell>
                        <TableCell className="text-white/70">{payment.method}</TableCell>
                        <TableCell className="text-white font-medium">{formatCurrency(payment.amount)}</TableCell>
                        <TableCell>
                          <Badge className="bg-green-500 text-black hover:bg-green-600">
                            <CheckCircle className="h-3 w-3 mr-1" />
                            Successful
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" className="h-8 w-8 p-0 text-white hover:bg-white/10">
                                <span className="sr-only">Open menu</span>
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent
                              align="end"
                              className="bg-fluxcloud-black/90 border-white/10 backdrop-blur-md"
                            >
                              <DropdownMenuLabel className="text-white">Actions</DropdownMenuLabel>
                              <DropdownMenuSeparator className="bg-white/10" />
                              <DropdownMenuItem className="text-white/70 hover:bg-white/10 hover:text-fluxcloud-cyan">
                                View details
                              </DropdownMenuItem>
                              <DropdownMenuItem className="text-white/70 hover:bg-white/10 hover:text-fluxcloud-cyan">
                                Download receipt
                              </DropdownMenuItem>
                              <DropdownMenuItem className="text-white/70 hover:bg-white/10 hover:text-fluxcloud-cyan">
                                View invoice
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="methods" className="mt-4 space-y-4">
          <div className="flex justify-end">
            <Button className="bg-fluxcloud-cyan text-black hover:bg-fluxcloud-cyan/80 shadow-neon-cyan btn-hover-effect">
              <Plus className="mr-2 h-4 w-4" />
              Add Payment Method
            </Button>
          </div>

          {paymentMethods.length === 0 ? (
            <EmptyPlaceholder
              icon={CreditCard}
              title="No payment methods"
              description="Add a payment method to enable automatic payments"
              action={
                <Button className="bg-fluxcloud-cyan text-black hover:bg-fluxcloud-cyan/80 shadow-neon-cyan btn-hover-effect">
                  <Plus className="mr-2 h-4 w-4" />
                  Add Payment Method
                </Button>
              }
            />
          ) : (
            <div className="grid gap-4 md:grid-cols-2">
              {paymentMethods.map((method) => (
                <Card key={method.id} className="glass-card border-white/10 card-hover-lift overflow-hidden">
                  <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-fluxcloud-cyan via-fluxcloud-navy-green to-fluxcloud-navy-yellow"></div>
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start">
                      <div className="flex items-center gap-3">
                        <div className="p-2 rounded-full bg-white/5 text-fluxcloud-cyan">
                          <CreditCard className="h-5 w-5" />
                        </div>
                        <div>
                          <CardTitle className="text-lg text-white">{method.type}</CardTitle>
                          <CardDescription className="text-white/70">
                            {method.type === "Credit Card" ? `**** **** **** ${method.lastFour}` : method.description}
                          </CardDescription>
                        </div>
                      </div>
                      {method.isDefault && <Badge className="bg-fluxcloud-cyan text-black">Default</Badge>}
                    </div>
                  </CardHeader>
                  <CardContent className="pb-2">
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      {method.type === "Credit Card" && (
                        <>
                          <div className="flex flex-col p-2 rounded-md bg-white/5">
                            <span className="text-white/50">Cardholder</span>
                            <span className="text-white font-medium">{method.name}</span>
                          </div>
                          <div className="flex flex-col p-2 rounded-md bg-white/5">
                            <span className="text-white/50">Expires</span>
                            <span className="text-white font-medium">
                              {method.expiryMonth}/{method.expiryYear}
                            </span>
                          </div>
                        </>
                      )}
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between border-t border-white/10 pt-4">
                    <Button
                      variant="outline"
                      size="sm"
                      className="border-white/10 text-white hover:bg-white/10 hover:text-fluxcloud-cyan"
                    >
                      Edit
                    </Button>
                    {!method.isDefault && (
                      <Button
                        variant="outline"
                        size="sm"
                        className="border-white/10 text-white hover:bg-white/10 hover:text-fluxcloud-cyan"
                      >
                        Set as Default
                      </Button>
                    )}
                    <Button
                      variant="outline"
                      size="sm"
                      className="border-white/10 text-red-500 hover:bg-red-500/10 hover:text-red-400"
                    >
                      Remove
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>

      <div className="mt-8">
        <Card className="glass-card border-white/10">
          <CardHeader>
            <CardTitle className="text-xl text-white">Automatic Payments</CardTitle>
            <CardDescription className="text-white/70">Configure automatic payments for your invoices</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col md:flex-row gap-6 items-center">
              <div className="flex-1 space-y-4">
                <p className="text-white/70">
                  Enable automatic payments to have your invoices paid automatically when they are due. This ensures
                  your services continue without interruption.
                </p>
                <div className="flex items-center space-x-2">
                  <div className="flex-shrink-0 h-4 w-4 rounded-full bg-green-500"></div>
                  <p className="text-sm text-white">Automatic payments are currently enabled</p>
                </div>
              </div>
              <Button
                variant="outline"
                className="border-white/10 text-white hover:bg-white/10 hover:text-fluxcloud-cyan"
              >
                Configure Settings
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

