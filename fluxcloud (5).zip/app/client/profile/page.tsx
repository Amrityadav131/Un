"use client"

import { useState } from "react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { Loader2, Upload } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/components/ui/use-toast"
import { useAuth } from "@/components/auth-provider"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Textarea } from "@/components/ui/textarea"

const profileFormSchema = z.object({
  name: z.string().min(2, {
    message: "Name must be at least 2 characters.",
  }),
  email: z.string().email({
    message: "Please enter a valid email address.",
  }),
  company: z
    .string()
    .min(2, {
      message: "Company name must be at least 2 characters.",
    })
    .optional(),
  phone: z
    .string()
    .min(5, {
      message: "Phone number must be at least 5 characters.",
    })
    .optional(),
  address: z
    .string()
    .min(5, {
      message: "Address must be at least 5 characters.",
    })
    .optional(),
})

const passwordFormSchema = z
  .object({
    currentPassword: z.string().min(6, {
      message: "Password must be at least 6 characters.",
    }),
    newPassword: z.string().min(6, {
      message: "Password must be at least 6 characters.",
    }),
    confirmPassword: z.string().min(6, {
      message: "Password must be at least 6 characters.",
    }),
  })
  .refine((data) => data.newPassword === data.confirmPassword, {
    message: "Passwords do not match.",
    path: ["confirmPassword"],
  })

export default function ClientProfilePage() {
  const { user } = useAuth()
  const { toast } = useToast()
  const [isProfileLoading, setIsProfileLoading] = useState(false)
  const [isPasswordLoading, setIsPasswordLoading] = useState(false)

  const profileForm = useForm<z.infer<typeof profileFormSchema>>({
    resolver: zodResolver(profileFormSchema),
    defaultValues: {
      name: user?.name || "",
      email: user?.email || "",
      company: "Acme Inc",
      phone: "+1 (555) 123-4567",
      address: "123 Business Ave, Suite 100, Tech City, TC 12345",
    },
  })

  const passwordForm = useForm<z.infer<typeof passwordFormSchema>>({
    resolver: zodResolver(passwordFormSchema),
    defaultValues: {
      currentPassword: "",
      newPassword: "",
      confirmPassword: "",
    },
  })

  async function onProfileSubmit(values: z.infer<typeof profileFormSchema>) {
    setIsProfileLoading(true)
    try {
      // In a real app, this would call an API endpoint
      await new Promise((resolve) => setTimeout(resolve, 1000))
      toast({
        title: "Profile updated",
        description: "Your profile has been updated successfully.",
      })
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to update profile. Please try again.",
      })
    } finally {
      setIsProfileLoading(false)
    }
  }

  async function onPasswordSubmit(values: z.infer<typeof passwordFormSchema>) {
    setIsPasswordLoading(true)
    try {
      // In a real app, this would call an API endpoint
      await new Promise((resolve) => setTimeout(resolve, 1000))
      toast({
        title: "Password updated",
        description: "Your password has been updated successfully.",
      })
      passwordForm.reset({
        currentPassword: "",
        newPassword: "",
        confirmPassword: "",
      })
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to update password. Please try again.",
      })
    } finally {
      setIsPasswordLoading(false)
    }
  }

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((part) => part[0])
      .join("")
      .toUpperCase()
      .substring(0, 2)
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight text-white">Profile</h2>
        <p className="text-white/70">Manage your account settings and preferences.</p>
      </div>

      <Tabs defaultValue="general" className="space-y-4">
        <TabsList className="bg-white/10">
          <TabsTrigger value="general" className="data-[state=active]:bg-fluxcloud-cyan data-[state=active]:text-black">
            General
          </TabsTrigger>
          <TabsTrigger
            value="password"
            className="data-[state=active]:bg-fluxcloud-cyan data-[state=active]:text-black"
          >
            Password
          </TabsTrigger>
          <TabsTrigger value="billing" className="data-[state=active]:bg-fluxcloud-cyan data-[state=active]:text-black">
            Billing
          </TabsTrigger>
        </TabsList>

        <TabsContent value="general">
          <Card className="glass-card border-white/10">
            <CardHeader>
              <CardTitle className="text-white">General Information</CardTitle>
              <CardDescription className="text-white/70">Update your account information.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex flex-col items-center space-y-4 sm:flex-row sm:space-x-4 sm:space-y-0">
                <Avatar className="h-24 w-24">
                  <AvatarImage src={user?.avatar || "/placeholder.svg"} alt={user?.name} />
                  <AvatarFallback className="bg-fluxcloud-cyan/20 text-fluxcloud-cyan text-xl">
                    {user?.name ? getInitials(user.name) : "??"}
                  </AvatarFallback>
                </Avatar>
                <div className="space-y-2">
                  <div className="text-sm text-white/70">Allowed file types: PNG, JPG, GIF. Maximum size: 2MB.</div>
                  <div className="flex flex-wrap gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="border-white/10 text-white hover:bg-white/10 hover:text-fluxcloud-cyan"
                    >
                      <Upload className="mr-2 h-4 w-4" />
                      Upload
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="border-white/10 text-white hover:bg-white/10 hover:text-red-500"
                    >
                      Remove
                    </Button>
                  </div>
                </div>
              </div>

              <Form {...profileForm}>
                <form onSubmit={profileForm.handleSubmit(onProfileSubmit)} className="space-y-4">
                  <FormField
                    control={profileForm.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white">Name</FormLabel>
                        <FormControl>
                          <Input
                            {...field}
                            className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus-visible:ring-fluxcloud-cyan"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={profileForm.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white">Email</FormLabel>
                        <FormControl>
                          <Input
                            {...field}
                            className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus-visible:ring-fluxcloud-cyan"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={profileForm.control}
                    name="company"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white">Company</FormLabel>
                        <FormControl>
                          <Input
                            {...field}
                            className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus-visible:ring-fluxcloud-cyan"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={profileForm.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white">Phone</FormLabel>
                        <FormControl>
                          <Input
                            {...field}
                            className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus-visible:ring-fluxcloud-cyan"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={profileForm.control}
                    name="address"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white">Address</FormLabel>
                        <FormControl>
                          <Textarea
                            {...field}
                            className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus-visible:ring-fluxcloud-cyan"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <Button
                    type="submit"
                    className="bg-fluxcloud-cyan text-black hover:bg-fluxcloud-cyan/80"
                    disabled={isProfileLoading}
                  >
                    {isProfileLoading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Saving...
                      </>
                    ) : (
                      "Save Changes"
                    )}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="password">
          <Card className="glass-card border-white/10">
            <CardHeader>
              <CardTitle className="text-white">Change Password</CardTitle>
              <CardDescription className="text-white/70">
                Update your password to keep your account secure.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...passwordForm}>
                <form onSubmit={passwordForm.handleSubmit(onPasswordSubmit)} className="space-y-4">
                  <FormField
                    control={passwordForm.control}
                    name="currentPassword"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white">Current Password</FormLabel>
                        <FormControl>
                          <Input
                            type="password"
                            {...field}
                            className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus-visible:ring-fluxcloud-cyan"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={passwordForm.control}
                    name="newPassword"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white">New Password</FormLabel>
                        <FormControl>
                          <Input
                            type="password"
                            {...field}
                            className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus-visible:ring-fluxcloud-cyan"
                          />
                        </FormControl>
                        <FormDescription className="text-white/50">
                          Password must be at least 6 characters long.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={passwordForm.control}
                    name="confirmPassword"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white">Confirm New Password</FormLabel>
                        <FormControl>
                          <Input
                            type="password"
                            {...field}
                            className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus-visible:ring-fluxcloud-cyan"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <Button
                    type="submit"
                    className="bg-fluxcloud-cyan text-black hover:bg-fluxcloud-cyan/80"
                    disabled={isPasswordLoading}
                  >
                    {isPasswordLoading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Updating...
                      </>
                    ) : (
                      "Update Password"
                    )}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="billing">
          <Card className="glass-card border-white/10">
            <CardHeader>
              <CardTitle className="text-white">Billing Information</CardTitle>
              <CardDescription className="text-white/70">
                Manage your billing information and payment methods.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="rounded-lg border border-white/10 p-4">
                <div className="flex flex-col space-y-2">
                  <h3 className="text-lg font-medium text-white">Payment Methods</h3>
                  <p className="text-sm text-white/70">Manage your payment methods.</p>
                </div>
                <div className="mt-4 space-y-4">
                  <div className="flex items-center justify-between rounded-md border border-white/10 bg-white/5 p-4">
                    <div className="flex items-center space-x-4">
                      <div className="h-10 w-10 rounded-md bg-white/10 flex items-center justify-center">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="24"
                          height="24"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          className="text-fluxcloud-cyan"
                        >
                          <rect width="20" height="14" x="2" y="5" rx="2" />
                          <line x1="2" x2="22" y1="10" y2="10" />
                        </svg>
                      </div>
                      <div>
                        <p className="text-sm font-medium text-white">Visa ending in 4242</p>
                        <p className="text-xs text-white/70">Expires 12/2025</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        className="border-white/10 text-white hover:bg-white/10 hover:text-fluxcloud-cyan"
                      >
                        Edit
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="border-white/10 text-white hover:bg-white/10 hover:text-red-500"
                      >
                        Remove
                      </Button>
                    </div>
                  </div>
                  <Button
                    variant="outline"
                    className="border-white/10 text-white hover:bg-white/10 hover:text-fluxcloud-cyan"
                  >
                    Add Payment Method
                  </Button>
                </div>
              </div>

              <div className="rounded-lg border border-white/10 p-4">
                <div className="flex flex-col space-y-2">
                  <h3 className="text-lg font-medium text-white">Billing Address</h3>
                  <p className="text-sm text-white/70">Manage your billing address.</p>
                </div>
                <div className="mt-4 space-y-4">
                  <div className="rounded-md border border-white/10 bg-white/5 p-4">
                    <p className="text-sm text-white">Acme Inc</p>
                    <p className="text-sm text-white">123 Business Ave, Suite 100</p>
                    <p className="text-sm text-white">Tech City, TC 12345</p>
                    <p className="text-sm text-white">United States</p>
                  </div>
                  <Button
                    variant="outline"
                    className="border-white/10 text-white hover:bg-white/10 hover:text-fluxcloud-cyan"
                  >
                    Edit Billing Address
                  </Button>
                </div>
              </div>

              <div className="rounded-lg border border-white/10 p-4">
                <div className="flex flex-col space-y-2">
                  <h3 className="text-lg font-medium text-white">Billing History</h3>
                  <p className="text-sm text-white/70">View your billing history.</p>
                </div>
                <div className="mt-4 space-y-4">
                  <div className="rounded-md border border-white/10 bg-white/5 p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-white">Invoice #INV-001</p>
                        <p className="text-xs text-white/70">April 1, 2023</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium text-white">₹5,250</p>
                        <p className="text-xs text-green-500">Paid</p>
                      </div>
                    </div>
                  </div>
                  <div className="rounded-md border border-white/10 bg-white/5 p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-white">Invoice #INV-002</p>
                        <p className="text-xs text-white/70">March 1, 2023</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium text-white">₹5,250</p>
                        <p className="text-xs text-green-500">Paid</p>
                      </div>
                    </div>
                  </div>
                  <Button
                    variant="outline"
                    className="border-white/10 text-white hover:bg-white/10 hover:text-fluxcloud-cyan"
                  >
                    View All Invoices
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

