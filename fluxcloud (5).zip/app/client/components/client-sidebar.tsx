import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"
import { Menu } from "lucide-react"
import { SidebarMenu, SidebarMenuItem, SidebarMenuButton } from "./ui/sidebar"
import { Link } from "next/navigation"
import { Home, Users, Calendar, Settings, ShieldAlert } from "lucide-react"
import { useSession } from "next-auth/react"

const ClientSidebar = () => {
  const { data: session } = useSession()
  const user = session?.user

  return (
    <Sheet>
      <SheetTrigger asChild>
        <Menu className="md:hidden" />
      </SheetTrigger>
      <SheetContent side="left" className="w-full sm:max-w-xs p-0">
        <SheetHeader className="px-5 pt-5 pb-4">
          <SheetTitle>Menu</SheetTitle>
          <SheetDescription>Navigate your client dashboard.</SheetDescription>
        </SheetHeader>
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton asChild tooltip="Dashboard">
              <Link href="/client/dashboard" className="flex items-center">
                <Home className="h-4 w-4" />
                <span>Dashboard</span>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>
          <SidebarMenuItem>
            <SidebarMenuButton asChild tooltip="Clients">
              <Link href="/client/clients" className="flex items-center">
                <Users className="h-4 w-4" />
                <span>Clients</span>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>
          <SidebarMenuItem>
            <SidebarMenuButton asChild tooltip="Appointments">
              <Link href="/client/appointments" className="flex items-center">
                <Calendar className="h-4 w-4" />
                <span>Appointments</span>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>
          <SidebarMenuItem>
            <SidebarMenuButton asChild tooltip="Settings">
              <Link href="/client/settings" className="flex items-center">
                <Settings className="h-4 w-4" />
                <span>Settings</span>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>
          {user?.role === "ADMIN" && (
            <SidebarMenuItem>
              <SidebarMenuButton asChild tooltip="Admin Dashboard">
                <Link href="/admin/dashboard" className="flex items-center">
                  <ShieldAlert className="h-4 w-4 text-red-400" />
                  <span>Admin Area</span>
                </Link>
              </SidebarMenuButton>
            </SidebarMenuItem>
          )}
        </SidebarMenu>
      </SheetContent>
    </Sheet>
  )
}

export default ClientSidebar

