"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { AlertCircle, Plus } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Loader } from "@/components/loader"
import { useToast } from "@/components/ui/use-toast"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useAuth } from "@/components/auth-provider"

export default function ClientSupportPage() {
  const { user } = useAuth()
  const { toast } = useToast()
  const [tickets, setTickets] = useState([])
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState(null)
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false)
  const [currentTicket, setCurrentTicket] = useState(null)
  const [replyText, setReplyText] = useState("")
  const [formData, setFormData] = useState({
    subject: "",
    message: "",
    priority: "MEDIUM",
  })
  const apiUrl = process.env.NEXT_PUBLIC_API_URL || "/api"

  useEffect(() => {
    fetchTickets()
  }, [])

  const fetchTickets = async () => {
    try {
      const response = await fetch(`${apiUrl}/client/tickets`, {
        credentials: "include",
      })

      if (!response.ok) {
        if (response.status === 404) {
          // If no tickets found, just set empty array
          setTickets([])
          setLoading(false)
          return
        }
        throw new Error("Failed to fetch tickets")
      }

      const data = await response.json()
      setTickets(Array.isArray(data) ? data : [])
      setLoading(false)
    } catch (err) {
      console.error("Error fetching tickets:", err)
      setError("Failed to load tickets. Please try again.")
      setLoading(false)
      setTickets([])
    }
  }

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setFormData({
      ...formData,
      [name]: value,
    })
  }

  const handleSelectChange = (name, value) => {
    setFormData({
      ...formData,
      [name]: value,
    })
  }

  const handleAddTicket = async (e) => {
    e.preventDefault()
    setSubmitting(true)

    try {
      const response = await fetch(`${apiUrl}/client/tickets`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify({
          subject: formData.subject,
          message: formData.message,
          priority: formData.priority,
          userId: user?.id,
        }),
      })

      if (!response.ok) throw new Error("Failed to create ticket")

      toast({
        title: "Ticket created",
        description: "Your support ticket has been submitted successfully.",
      })

      // Reset form and close dialog
      setFormData({
        subject: "",
        message: "",
        priority: "MEDIUM",
      })
      setIsAddDialogOpen(false)

      // Refresh tickets
      await fetchTickets()
    } catch (err) {
      console.error("Error creating ticket:", err)
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to create ticket. Please try again.",
      })
    } finally {
      setSubmitting(false)
    }
  }

  const handleReplyToTicket = async (e) => {
    e.preventDefault()
    if (!replyText.trim()) return

    setSubmitting(true)

    try {
      const response = await fetch(`${apiUrl}/client/tickets/${currentTicket.id}/reply`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify({
          message: replyText,
          userId: user?.id,
        }),
      })

      if (!response.ok) throw new Error("Failed to reply to ticket")

      toast({
        title: "Reply sent",
        description: "Your reply has been sent successfully.",
      })

      // Reset form
      setReplyText("")

      // Refresh ticket details
      const ticketResponse = await fetch(`${apiUrl}/client/tickets/${currentTicket.id}`, {
        credentials: "include",
      })

      if (ticketResponse.ok) {
        const updatedTicket = await ticketResponse.json()
        setCurrentTicket(updatedTicket)

        // Also update in the tickets list
        setTickets(tickets.map((ticket) => (ticket.id === updatedTicket.id ? updatedTicket : ticket)))
      }
    } catch (err) {
      console.error("Error replying to ticket:", err)
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to send reply. Please try again.",
      })
    } finally {
      setSubmitting(false)
    }
  }

  const viewTicket = async (ticket) => {
    setCurrentTicket(ticket)
    setIsViewDialogOpen(true)

    // Fetch the latest ticket details
    try {
      const response = await fetch(`${apiUrl}/client/tickets/${ticket.id}`, {
        credentials: "include",
      })

      if (response.ok) {
        const updatedTicket = await response.json()
        setCurrentTicket(updatedTicket)
      }
    } catch (err) {
      console.error("Error fetching ticket details:", err)
    }
  }

  // Function to format date
  const formatDate = (dateString) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("en-IN", {
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  if (loading && tickets.length === 0) {
    return (
      <div className="flex items-center justify-center h-full w-full p-6">
        <Loader />
      </div>
    )
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-white neon-text-cyan">Support</h1>
          <p className="text-white/70">Get help with your FluxCloud services</p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-fluxcloud-cyan hover:bg-fluxcloud-cyan/80 text-black">
              <Plus className="mr-2 h-4 w-4" /> New Ticket
            </Button>
          </DialogTrigger>
          <DialogContent className="glass-card border-white/10">
            <DialogHeader>
              <DialogTitle className="text-white">Create Support Ticket</DialogTitle>
              <DialogDescription className="text-white/70">
                Describe your issue and we'll get back to you as soon as possible.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleAddTicket}>
              <div className="grid gap-4 py-4">
                <div className="grid gap-2">
                  <Label htmlFor="subject" className="text-white">
                    Subject
                  </Label>
                  <Input
                    id="subject"
                    name="subject"
                    value={formData.subject}
                    onChange={handleInputChange}
                    className="bg-white/5 border-white/10 text-white"
                    required
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="message" className="text-white">
                    Message
                  </Label>
                  <Textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleInputChange}
                    className="bg-white/5 border-white/10 text-white min-h-[150px]"
                    required
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="priority" className="text-white">
                    Priority
                  </Label>
                  <Select value={formData.priority} onValueChange={(value) => handleSelectChange("priority", value)}>
                    <SelectTrigger className="bg-white/5 border-white/10 text-white">
                      <SelectValue placeholder="Select priority" />
                    </SelectTrigger>
                    <SelectContent className="bg-fluxcloud-black border-white/10">
                      <SelectItem value="LOW" className="text-white hover:bg-white/10">
                        Low
                      </SelectItem>
                      <SelectItem value="MEDIUM" className="text-white hover:bg-white/10">
                        Medium
                      </SelectItem>
                      <SelectItem value="HIGH" className="text-white hover:bg-white/10">
                        High
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsAddDialogOpen(false)}
                  className="border-white/10 text-white hover:bg-white/10"
                  disabled={submitting}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  className="bg-fluxcloud-cyan hover:bg-fluxcloud-cyan/80 text-black"
                  disabled={submitting}
                >
                  {submitting ? "Submitting..." : "Submit Ticket"}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <Card className="glass-card border-white/10">
        <CardHeader>
          <CardTitle className="text-white">Your Support Tickets</CardTitle>
          <CardDescription className="text-white/70">View and manage your support requests</CardDescription>
        </CardHeader>
        <CardContent>
          {tickets.length > 0 ? (
            <Table>
              <TableHeader className="bg-white/5">
                <TableRow className="border-white/10 hover:bg-white/5">
                  <TableHead className="text-white">Ticket ID</TableHead>
                  <TableHead className="text-white">Subject</TableHead>
                  <TableHead className="text-white">Status</TableHead>
                  <TableHead className="text-white">Priority</TableHead>
                  <TableHead className="text-white">Created</TableHead>
                  <TableHead className="text-white">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {tickets.map((ticket) => (
                  <TableRow key={ticket.id} className="border-white/10 hover:bg-white/5">
                    <TableCell className="font-medium text-white">#{ticket.id.substring(0, 8)}</TableCell>
                    <TableCell className="text-white">{ticket.subject}</TableCell>
                    <TableCell>
                      {ticket.status === "OPEN" ? (
                        <Badge className="bg-green-500 text-black">Open</Badge>
                      ) : ticket.status === "PENDING" ? (
                        <Badge className="bg-yellow-500 text-black">Pending</Badge>
                      ) : (
                        <Badge className="bg-gray-500 text-black">Closed</Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      {ticket.priority === "HIGH" ? (
                        <Badge className="bg-red-500 text-black">High</Badge>
                      ) : ticket.priority === "MEDIUM" ? (
                        <Badge className="bg-yellow-500 text-black">Medium</Badge>
                      ) : (
                        <Badge className="bg-blue-500 text-black">Low</Badge>
                      )}
                    </TableCell>
                    <TableCell className="text-white/70">{formatDate(ticket.createdAt)}</TableCell>
                    <TableCell>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-white hover:bg-white/10 hover:text-fluxcloud-cyan"
                        onClick={() => viewTicket(ticket)}
                      >
                        View
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="text-center py-6 text-white/70">
              No support tickets found. Create your first ticket to get help.
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="glass-card border-white/10 max-w-3xl max-h-[80vh] overflow-y-auto">
          {currentTicket && (
            <>
              <DialogHeader>
                <div className="flex justify-between items-center">
                  <DialogTitle className="text-white">Ticket #{currentTicket.id.substring(0, 8)}</DialogTitle>
                  <div className="flex space-x-2">
                    {currentTicket.status === "OPEN" ? (
                      <Badge className="bg-green-500 text-black">Open</Badge>
                    ) : currentTicket.status === "PENDING" ? (
                      <Badge className="bg-yellow-500 text-black">Pending</Badge>
                    ) : (
                      <Badge className="bg-gray-500 text-black">Closed</Badge>
                    )}
                    {currentTicket.priority === "HIGH" ? (
                      <Badge className="bg-red-500 text-black">High Priority</Badge>
                    ) : currentTicket.priority === "MEDIUM" ? (
                      <Badge className="bg-yellow-500 text-black">Medium Priority</Badge>
                    ) : (
                      <Badge className="bg-blue-500 text-black">Low Priority</Badge>
                    )}
                  </div>
                </div>
                <DialogDescription className="text-white/70">{currentTicket.subject}</DialogDescription>
              </DialogHeader>
              <div className="py-4 space-y-4">
                <div className="bg-white/5 p-4 rounded-md">
                  <div className="flex justify-between items-start mb-2">
                    <div className="font-medium text-white">{currentTicket.userName || "You"}</div>
                    <div className="text-sm text-white/70">{formatDate(currentTicket.createdAt)}</div>
                  </div>
                  <p className="text-white whitespace-pre-wrap">{currentTicket.message}</p>
                </div>

                {currentTicket.replies &&
                  currentTicket.replies.map((reply, index) => (
                    <div
                      key={index}
                      className={`p-4 rounded-md ${reply.isAdmin ? "bg-fluxcloud-navy-blue/30" : "bg-white/5"}`}
                    >
                      <div className="flex justify-between items-start mb-2">
                        <div className="font-medium text-white">
                          {reply.isAdmin ? "Support Agent" : reply.userName || "You"}
                        </div>
                        <div className="text-sm text-white/70">{formatDate(reply.createdAt)}</div>
                      </div>
                      <p className="text-white whitespace-pre-wrap">{reply.message}</p>
                    </div>
                  ))}

                {currentTicket.status !== "CLOSED" && (
                  <form onSubmit={handleReplyToTicket} className="space-y-4">
                    <div className="grid gap-2">
                      <Label htmlFor="reply" className="text-white">
                        Reply
                      </Label>
                      <Textarea
                        id="reply"
                        value={replyText}
                        onChange={(e) => setReplyText(e.target.value)}
                        className="bg-white/5 border-white/10 text-white min-h-[100px]"
                        placeholder="Type your reply here..."
                        required
                      />
                    </div>
                    <div className="flex justify-end">
                      <Button
                        type="submit"
                        className="bg-fluxcloud-cyan hover:bg-fluxcloud-cyan/80 text-black"
                        disabled={submitting}
                      >
                        {submitting ? "Sending..." : "Send Reply"}
                      </Button>
                    </div>
                  </form>
                )}
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

