import type React from "react"
import { cookies } from "next/headers"
import { ClientSidebar } from "@/components/client/sidebar"
import { SidebarProvider, SidebarInset } from "@/components/ui/sidebar"
import { DashboardHeader } from "@/components/dashboard-header"

export default async function ClientLayout({
  children,
}: {
  children: React.ReactNode
}) {
  // Fix: Make cookies() awaitable
  const cookieStore = await cookies()
  const defaultOpen = cookieStore.get("sidebar:state")?.value === "true"

  return (
    <SidebarProvider defaultOpen={defaultOpen}>
      <div className="flex h-screen w-full bg-crystal-mountains bg-cover bg-center bg-no-repeat">
        <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/50 to-black/70 backdrop-blur-sm"></div>
        <div className="relative flex h-full w-full z-10">
          <ClientSidebar />
          <SidebarInset className="flex-1 w-full bg-transparent">
            <div className="flex h-full w-full flex-col">
              <DashboardHeader />
              <div className="flex-1 w-full overflow-auto">{children}</div>
            </div>
          </SidebarInset>
        </div>
      </div>
    </SidebarProvider>
  )
}

