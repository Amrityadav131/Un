"use client"

import { useState, useEffect } from "react"
import {
  Cloud,
  Plus,
  Server,
  Database,
  Mail,
  Globe,
  HardDrive,
  AlertCircle,
  Search,
  Filter,
  ArrowUpDown,
  MoreHorizontal,
  ExternalLink,
} from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { EmptyPlaceholder } from "@/components/empty-placeholder"
import { useAuth } from "@/components/auth-provider"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

// Define service types with their icons
const serviceTypes = {
  "Web Hosting": { icon: Globe, color: "text-fluxcloud-cyan" },
  Database: { icon: Database, color: "text-fluxcloud-navy-green" },
  Email: { icon: Mail, color: "text-fluxcloud-navy-yellow" },
  VPS: { icon: Server, color: "text-purple-500" },
  Storage: { icon: HardDrive, color: "text-pink-500" },
}

export default function ServicesPage() {
  const { user } = useAuth()
  const [services, setServices] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [sortBy, setSortBy] = useState("name")
  const [sortOrder, setSortOrder] = useState("asc")
  const apiUrl = process.env.NEXT_PUBLIC_API_URL || "/api"

  useEffect(() => {
    const fetchServices = async () => {
      try {
        // In a real app, this would fetch from the API
        const response = await fetch(`${apiUrl}/clients/services`, {
          credentials: "include",
        })

        if (response.ok) {
          const data = await response.json()
          setServices(data)
        } else {
          throw new Error("Failed to fetch services")
        }

        setLoading(false)
      } catch (err) {
        console.error("Error fetching services:", err)
        setError("Failed to load services. Please try again.")
        setLoading(false)
      }
    }

    fetchServices()
  }, [apiUrl])

  // Filter and sort services
  const filteredServices = services
    .filter((service) => {
      // Apply status filter
      if (statusFilter !== "all" && service.status !== statusFilter) {
        return false
      }

      // Apply search filter
      if (searchQuery) {
        const query = searchQuery.toLowerCase()
        return (
          service.name.toLowerCase().includes(query) ||
          service.description.toLowerCase().includes(query) ||
          service.type.toLowerCase().includes(query)
        )
      }

      return true
    })
    .sort((a, b) => {
      // Apply sorting
      const aValue = a[sortBy]
      const bValue = b[sortBy]

      if (typeof aValue === "string") {
        return sortOrder === "asc" ? aValue.localeCompare(bValue) : bValue.localeCompare(aValue)
      }

      return sortOrder === "asc" ? aValue - bValue : bValue - aValue
    })

  const toggleSort = (field) => {
    if (sortBy === field) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc")
    } else {
      setSortBy(field)
      setSortOrder("asc")
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full w-full p-6">
        <div className="h-12 w-12 rounded-full border-4 border-fluxcloud-cyan border-t-transparent animate-spin"></div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="p-6 space-y-4">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
        <Button onClick={() => window.location.reload()}>Try Again</Button>
      </div>
    )
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <h1 className="text-3xl font-bold tracking-tight text-white neon-text-cyan">Services</h1>
        <Button className="bg-fluxcloud-cyan text-black hover:bg-fluxcloud-cyan/80 shadow-neon-cyan btn-hover-effect">
          <Plus className="mr-2 h-4 w-4" />
          Request New Service
        </Button>
      </div>

      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/50" />
          <Input
            placeholder="Search services..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9 bg-white/5 border-white/10 text-white placeholder:text-white/50 focus-visible:ring-fluxcloud-cyan"
          />
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              variant="outline"
              className="border-white/10 text-white hover:bg-white/10 hover:text-fluxcloud-cyan"
            >
              <Filter className="mr-2 h-4 w-4" />
              Filter: {statusFilter === "all" ? "All" : statusFilter}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="bg-fluxcloud-black/90 border-white/10 backdrop-blur-md">
            <DropdownMenuLabel>Filter by Status</DropdownMenuLabel>
            <DropdownMenuSeparator className="bg-white/10" />
            <DropdownMenuItem
              onClick={() => setStatusFilter("all")}
              className={`${statusFilter === "all" ? "bg-white/10 text-fluxcloud-cyan" : "text-white/70"} hover:bg-white/10 hover:text-fluxcloud-cyan`}
            >
              All
            </DropdownMenuItem>
            <DropdownMenuItem
              onClick={() => setStatusFilter("ACTIVE")}
              className={`${statusFilter === "ACTIVE" ? "bg-white/10 text-fluxcloud-cyan" : "text-white/70"} hover:bg-white/10 hover:text-fluxcloud-cyan`}
            >
              Active
            </DropdownMenuItem>
            <DropdownMenuItem
              onClick={() => setStatusFilter("PENDING")}
              className={`${statusFilter === "PENDING" ? "bg-white/10 text-fluxcloud-cyan" : "text-white/70"} hover:bg-white/10 hover:text-fluxcloud-cyan`}
            >
              Pending
            </DropdownMenuItem>
            <DropdownMenuItem
              onClick={() => setStatusFilter("INACTIVE")}
              className={`${statusFilter === "INACTIVE" ? "bg-white/10 text-fluxcloud-cyan" : "text-white/70"} hover:bg-white/10 hover:text-fluxcloud-cyan`}
            >
              Inactive
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <Tabs defaultValue="grid" className="w-full">
        <TabsList className="bg-fluxcloud-black/40 border border-white/10 p-1">
          <TabsTrigger
            value="grid"
            className="data-[state=active]:bg-fluxcloud-cyan data-[state=active]:text-black rounded-md"
          >
            Grid View
          </TabsTrigger>
          <TabsTrigger
            value="table"
            className="data-[state=active]:bg-fluxcloud-cyan data-[state=active]:text-black rounded-md"
          >
            Table View
          </TabsTrigger>
        </TabsList>

        <TabsContent value="grid" className="mt-4">
          {filteredServices.length === 0 ? (
            <EmptyPlaceholder
              icon={Cloud}
              title="No services found"
              description={
                searchQuery ? "Try adjusting your search or filters" : "Request your first service to get started"
              }
              action={
                <Button className="bg-fluxcloud-cyan text-black hover:bg-fluxcloud-cyan/80 shadow-neon-cyan btn-hover-effect">
                  <Plus className="mr-2 h-4 w-4" />
                  Request Service
                </Button>
              }
            />
          ) : (
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {filteredServices.map((service) => {
                const ServiceIcon = serviceTypes[service.type]?.icon || Cloud
                const iconColor = serviceTypes[service.type]?.color || "text-fluxcloud-cyan"

                return (
                  <Card key={service.id} className="glass-card border-white/10 card-hover-lift overflow-hidden">
                    <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-fluxcloud-cyan via-fluxcloud-navy-green to-fluxcloud-navy-yellow"></div>
                    <CardHeader className="pb-2">
                      <div className="flex justify-between items-start">
                        <div className="flex items-center gap-3">
                          <div className={`p-2 rounded-full bg-white/5 ${iconColor}`}>
                            <ServiceIcon className="h-5 w-5" />
                          </div>
                          <div>
                            <CardTitle className="text-lg text-white">{service.name}</CardTitle>
                            <CardDescription className="text-white/70">{service.type}</CardDescription>
                          </div>
                        </div>
                        <Badge
                          variant={service.status === "ACTIVE" ? "default" : "secondary"}
                          className={
                            service.status === "ACTIVE"
                              ? "bg-green-500 text-black hover:bg-green-600"
                              : service.status === "PENDING"
                                ? "bg-yellow-500 text-black hover:bg-yellow-600"
                                : "bg-gray-500 text-black hover:bg-gray-600"
                          }
                        >
                          {service.status}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="pb-2">
                      <p className="text-sm text-white/70 mb-4">{service.description}</p>
                      <div className="grid grid-cols-2 gap-2 text-xs">
                        {Object.entries(service.specs || {}).map(([key, value]) => (
                          <div key={key} className="flex flex-col p-2 rounded-md bg-white/5">
                            <span className="text-white/50 capitalize">{key}</span>
                            <span className="text-white font-medium">{value}</span>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                    <CardFooter className="flex justify-between border-t border-white/10 pt-4">
                      <div className="text-sm">
                        <span className="text-white/50">Price:</span>
                        <span className="text-white font-bold ml-2">₹{service.price}/mo</span>
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        className="border-white/10 text-white hover:bg-white/10 hover:text-fluxcloud-cyan"
                      >
                        Manage
                      </Button>
                    </CardFooter>
                  </Card>
                )
              })}
            </div>
          )}
        </TabsContent>

        <TabsContent value="table" className="mt-4">
          <Card className="glass-card border-white/10">
            <CardContent className="p-0">
              {filteredServices.length === 0 ? (
                <div className="p-6">
                  <EmptyPlaceholder
                    icon={Cloud}
                    title="No services found"
                    description={
                      searchQuery ? "Try adjusting your search or filters" : "Request your first service to get started"
                    }
                    action={
                      <Button className="bg-fluxcloud-cyan text-black hover:bg-fluxcloud-cyan/80 shadow-neon-cyan btn-hover-effect">
                        <Plus className="mr-2 h-4 w-4" />
                        Request Service
                      </Button>
                    }
                  />
                </div>
              ) : (
                <Table>
                  <TableHeader className="bg-white/5">
                    <TableRow className="border-white/10 hover:bg-white/5">
                      <TableHead className="text-white">
                        <Button
                          variant="ghost"
                          className="p-0 font-medium text-white hover:text-fluxcloud-cyan hover:bg-transparent"
                          onClick={() => toggleSort("name")}
                        >
                          Service
                          <ArrowUpDown className={`ml-2 h-4 w-4 ${sortBy === "name" ? "opacity-100" : "opacity-50"}`} />
                        </Button>
                      </TableHead>
                      <TableHead className="text-white">Type</TableHead>
                      <TableHead className="text-white">Status</TableHead>
                      <TableHead className="text-white">
                        <Button
                          variant="ghost"
                          className="p-0 font-medium text-white hover:text-fluxcloud-cyan hover:bg-transparent"
                          onClick={() => toggleSort("price")}
                        >
                          Price
                          <ArrowUpDown
                            className={`ml-2 h-4 w-4 ${sortBy === "price" ? "opacity-100" : "opacity-50"}`}
                          />
                        </Button>
                      </TableHead>
                      <TableHead className="text-white">
                        <Button
                          variant="ghost"
                          className="p-0 font-medium text-white hover:text-fluxcloud-cyan hover:bg-transparent"
                          onClick={() => toggleSort("nextBillingDate")}
                        >
                          Next Billing
                          <ArrowUpDown
                            className={`ml-2 h-4 w-4 ${sortBy === "nextBillingDate" ? "opacity-100" : "opacity-50"}`}
                          />
                        </Button>
                      </TableHead>
                      <TableHead className="text-right text-white">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredServices.map((service) => {
                      const ServiceIcon = serviceTypes[service.type]?.icon || Cloud
                      const iconColor = serviceTypes[service.type]?.color || "text-fluxcloud-cyan"

                      return (
                        <TableRow key={service.id} className="border-white/10 hover:bg-white/5">
                          <TableCell className="font-medium text-white">
                            <div className="flex items-center gap-2">
                              <ServiceIcon className={`h-4 w-4 ${iconColor}`} />
                              <span>{service.name}</span>
                            </div>
                          </TableCell>
                          <TableCell className="text-white/70">{service.type}</TableCell>
                          <TableCell>
                            <Badge
                              variant={service.status === "ACTIVE" ? "default" : "secondary"}
                              className={
                                service.status === "ACTIVE"
                                  ? "bg-green-500 text-black hover:bg-green-600"
                                  : service.status === "PENDING"
                                    ? "bg-yellow-500 text-black hover:bg-yellow-600"
                                    : "bg-gray-500 text-black hover:bg-gray-600"
                              }
                            >
                              {service.status}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-white">₹{service.price}/mo</TableCell>
                          <TableCell className="text-white/70">
                            {service.nextBillingDate ? new Date(service.nextBillingDate).toLocaleDateString() : "N/A"}
                          </TableCell>
                          <TableCell className="text-right">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" className="h-8 w-8 p-0 text-white hover:bg-white/10">
                                  <span className="sr-only">Open menu</span>
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent
                                align="end"
                                className="bg-fluxcloud-black/90 border-white/10 backdrop-blur-md"
                              >
                                <DropdownMenuLabel className="text-white">Actions</DropdownMenuLabel>
                                <DropdownMenuSeparator className="bg-white/10" />
                                <DropdownMenuItem className="text-white/70 hover:bg-white/10 hover:text-fluxcloud-cyan">
                                  View details
                                </DropdownMenuItem>
                                <DropdownMenuItem className="text-white/70 hover:bg-white/10 hover:text-fluxcloud-cyan">
                                  Manage service
                                </DropdownMenuItem>
                                <DropdownMenuItem className="text-white/70 hover:bg-white/10 hover:text-fluxcloud-cyan">
                                  View invoices
                                </DropdownMenuItem>
                                <DropdownMenuSeparator className="bg-white/10" />
                                <DropdownMenuItem className="text-red-500 hover:bg-white/10 hover:text-red-400">
                                  Cancel service
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      )
                    })}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="mt-8">
        <Card className="glass-card border-white/10">
          <CardHeader>
            <CardTitle className="text-xl text-white">Need a Custom Solution?</CardTitle>
            <CardDescription className="text-white/70">
              We offer tailored cloud solutions to meet your specific requirements
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col md:flex-row gap-6 items-center">
              <div className="flex-1 space-y-4">
                <p className="text-white/70">
                  Our team of experts can help you design and implement custom cloud infrastructure tailored to your
                  business needs. From high-performance computing to specialized storage solutions, we've got you
                  covered.
                </p>
                <div className="flex flex-wrap gap-3">
                  <Badge variant="outline" className="bg-white/5 text-white border-white/10">
                    High Performance
                  </Badge>
                  <Badge variant="outline" className="bg-white/5 text-white border-white/10">
                    Scalable
                  </Badge>
                  <Badge variant="outline" className="bg-white/5 text-white border-white/10">
                    Secure
                  </Badge>
                  <Badge variant="outline" className="bg-white/5 text-white border-white/10">
                    24/7 Support
                  </Badge>
                </div>
              </div>
              <Button className="bg-fluxcloud-cyan text-black hover:bg-fluxcloud-cyan/80 shadow-neon-cyan btn-hover-effect">
                Request Consultation
                <ExternalLink className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

