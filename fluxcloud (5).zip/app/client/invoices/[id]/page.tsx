"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { format } from "date-fns"
import { ArrowLeft, CreditCard } from "lucide-react"
import { toast } from "sonner"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Loader } from "@/components/loader"

interface Invoice {
  id: string
  clientEmail: string
  description: string
  services: string
  amount: number
  status: "paid" | "pending" | "overdue"
  dueDate: string
  repaymentDate?: string
  createdAt: string
  updatedAt: string
}

export default function ClientInvoiceDetailPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const [invoice, setInvoice] = useState<Invoice | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isProcessing, setIsProcessing] = useState(false)

  useEffect(() => {
    async function fetchInvoice() {
      try {
        setIsLoading(true)
        const response = await fetch(`/api/client/invoices/${params.id}`)

        if (!response.ok) {
          throw new Error("Failed to fetch invoice")
        }

        const data = await response.json()
        setInvoice(data)
      } catch (error) {
        console.error("Error fetching invoice:", error)
        toast.error("Failed to fetch invoice details")
      } finally {
        setIsLoading(false)
      }
    }

    fetchInvoice()
  }, [params.id])

  const handlePayment = async () => {
    try {
      setIsProcessing(true)
      const response = await fetch(`/api/client/invoices/${params.id}/pay`, {
        method: "POST",
      })

      if (!response.ok) {
        throw new Error("Failed to process payment")
      }

      toast.success("Payment processed successfully")

      // Refresh the invoice data
      const updatedInvoice = await response.json()
      setInvoice(updatedInvoice)
    } catch (error) {
      console.error("Error processing payment:", error)
      toast.error("Failed to process payment")
    } finally {
      setIsProcessing(false)
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "paid":
        return <Badge className="bg-green-500">Paid</Badge>
      case "pending":
        return <Badge className="bg-yellow-500">Pending</Badge>
      case "overdue":
        return <Badge className="bg-red-500">Overdue</Badge>
      default:
        return <Badge>{status}</Badge>
    }
  }

  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <Loader />
      </div>
    )
  }

  if (!invoice) {
    return (
      <div className="container mx-auto py-10">
        <Card>
          <CardHeader>
            <CardTitle>Invoice Not Found</CardTitle>
            <CardDescription>The requested invoice could not be found.</CardDescription>
          </CardHeader>
          <CardFooter>
            <Button variant="outline" onClick={() => router.push("/client/invoices")}>
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Invoices
            </Button>
          </CardFooter>
        </Card>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-10">
      <div className="flex justify-between items-center mb-6">
        <Button variant="outline" onClick={() => router.push("/client/invoices")}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Invoices
        </Button>
        {invoice.status !== "paid" && (
          <Button onClick={handlePayment} disabled={isProcessing}>
            <CreditCard className="mr-2 h-4 w-4" />
            {isProcessing ? "Processing..." : "Pay Now"}
          </Button>
        )}
      </div>

      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle className="text-2xl">Invoice #{invoice.id}</CardTitle>
              <CardDescription>Created on {format(new Date(invoice.createdAt), "PPP")}</CardDescription>
            </div>
            <div>{getStatusBadge(invoice.status)}</div>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-lg font-semibold mb-2">Invoice Details</h3>
              <div className="space-y-2">
                <p>
                  <span className="font-medium">Amount:</span> ${invoice.amount.toFixed(2)}
                </p>
                <p>
                  <span className="font-medium">Due Date:</span> {format(new Date(invoice.dueDate), "PPP")}
                </p>
                {invoice.repaymentDate && (
                  <p>
                    <span className="font-medium">Repayment Date:</span>{" "}
                    {format(new Date(invoice.repaymentDate), "PPP")}
                  </p>
                )}
              </div>
            </div>
          </div>

          <Separator />

          <div>
            <h3 className="text-lg font-semibold mb-2">Services</h3>
            <p>{invoice.services}</p>
          </div>

          <Separator />

          <div>
            <h3 className="text-lg font-semibold mb-2">Description</h3>
            <p className="whitespace-pre-line">{invoice.description}</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

