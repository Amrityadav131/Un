"use client"

import { useState } from "react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { Loader2, Bell, Globe, Shield, Key } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel } from "@/components/ui/form"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { useToast } from "@/components/ui/use-toast"
import { useAuth } from "@/components/auth-provider"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

const notificationFormSchema = z.object({
  emailNotifications: z.boolean().default(true),
  marketingEmails: z.boolean().default(false),
  serviceUpdates: z.boolean().default(true),
  securityAlerts: z.boolean().default(true),
  billingAlerts: z.boolean().default(true),
})

const securityFormSchema = z.object({
  twoFactorAuth: z.boolean().default(false),
  sessionTimeout: z.string().default("30"),
  loginNotifications: z.boolean().default(true),
})

const appearanceFormSchema = z.object({
  theme: z.string().default("dark"),
  language: z.string().default("en"),
  timezone: z.string().default("UTC"),
  dateFormat: z.string().default("MM/DD/YYYY"),
})

export default function SettingsPage() {
  const { user } = useAuth()
  const { toast } = useToast()
  const [isNotificationLoading, setIsNotificationLoading] = useState(false)
  const [isSecurityLoading, setIsSecurityLoading] = useState(false)
  const [isAppearanceLoading, setIsAppearanceLoading] = useState(false)

  const notificationForm = useForm<z.infer<typeof notificationFormSchema>>({
    resolver: zodResolver(notificationFormSchema),
    defaultValues: {
      emailNotifications: true,
      marketingEmails: false,
      serviceUpdates: true,
      securityAlerts: true,
      billingAlerts: true,
    },
  })

  const securityForm = useForm<z.infer<typeof securityFormSchema>>({
    resolver: zodResolver(securityFormSchema),
    defaultValues: {
      twoFactorAuth: false,
      sessionTimeout: "30",
      loginNotifications: true,
    },
  })

  const appearanceForm = useForm<z.infer<typeof appearanceFormSchema>>({
    resolver: zodResolver(appearanceFormSchema),
    defaultValues: {
      theme: "dark",
      language: "en",
      timezone: "UTC",
      dateFormat: "MM/DD/YYYY",
    },
  })

  async function onNotificationSubmit(values: z.infer<typeof notificationFormSchema>) {
    setIsNotificationLoading(true)
    try {
      // In a real app, this would call an API endpoint
      await new Promise((resolve) => setTimeout(resolve, 1000))
      toast({
        title: "Notification settings updated",
        description: "Your notification preferences have been saved.",
      })
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to update notification settings. Please try again.",
      })
    } finally {
      setIsNotificationLoading(false)
    }
  }

  async function onSecuritySubmit(values: z.infer<typeof securityFormSchema>) {
    setIsSecurityLoading(true)
    try {
      // In a real app, this would call an API endpoint
      await new Promise((resolve) => setTimeout(resolve, 1000))
      toast({
        title: "Security settings updated",
        description: "Your security preferences have been saved.",
      })
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to update security settings. Please try again.",
      })
    } finally {
      setIsSecurityLoading(false)
    }
  }

  async function onAppearanceSubmit(values: z.infer<typeof appearanceFormSchema>) {
    setIsAppearanceLoading(true)
    try {
      // In a real app, this would call an API endpoint
      await new Promise((resolve) => setTimeout(resolve, 1000))
      toast({
        title: "Appearance settings updated",
        description: "Your appearance preferences have been saved.",
      })
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to update appearance settings. Please try again.",
      })
    } finally {
      setIsAppearanceLoading(false)
    }
  }

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-white neon-text-cyan">Settings</h1>
        <p className="text-white/70">Manage your account settings and preferences.</p>
      </div>

      <Tabs defaultValue="notifications" className="space-y-6">
        <TabsList className="bg-fluxcloud-black/40 border border-white/10 p-1">
          <TabsTrigger
            value="notifications"
            className="data-[state=active]:bg-fluxcloud-cyan data-[state=active]:text-black rounded-md"
          >
            Notifications
          </TabsTrigger>
          <TabsTrigger
            value="security"
            className="data-[state=active]:bg-fluxcloud-cyan data-[state=active]:text-black rounded-md"
          >
            Security
          </TabsTrigger>
          <TabsTrigger
            value="appearance"
            className="data-[state=active]:bg-fluxcloud-cyan data-[state=active]:text-black rounded-md"
          >
            Appearance
          </TabsTrigger>
        </TabsList>

        <TabsContent value="notifications">
          <Card className="glass-card border-white/10">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Bell className="h-5 w-5 text-fluxcloud-cyan" />
                Notification Settings
              </CardTitle>
              <CardDescription className="text-white/70">
                Configure how you receive notifications and alerts
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...notificationForm}>
                <form onSubmit={notificationForm.handleSubmit(onNotificationSubmit)} className="space-y-6">
                  <div className="space-y-4">
                    <FormField
                      control={notificationForm.control}
                      name="emailNotifications"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border border-white/10 p-4">
                          <div className="space-y-0.5">
                            <FormLabel className="text-white">Email Notifications</FormLabel>
                            <FormDescription className="text-white/50">
                              Receive email notifications for important updates
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                              className="data-[state=checked]:bg-fluxcloud-cyan"
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={notificationForm.control}
                      name="marketingEmails"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border border-white/10 p-4">
                          <div className="space-y-0.5">
                            <FormLabel className="text-white">Marketing Emails</FormLabel>
                            <FormDescription className="text-white/50">
                              Receive emails about new features and promotions
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                              className="data-[state=checked]:bg-fluxcloud-cyan"
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={notificationForm.control}
                      name="serviceUpdates"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border border-white/10 p-4">
                          <div className="space-y-0.5">
                            <FormLabel className="text-white">Service Updates</FormLabel>
                            <FormDescription className="text-white/50">
                              Receive notifications about your service status and updates
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                              className="data-[state=checked]:bg-fluxcloud-cyan"
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={notificationForm.control}
                      name="securityAlerts"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border border-white/10 p-4">
                          <div className="space-y-0.5">
                            <FormLabel className="text-white">Security Alerts</FormLabel>
                            <FormDescription className="text-white/50">
                              Receive notifications about security events
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                              className="data-[state=checked]:bg-fluxcloud-cyan"
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={notificationForm.control}
                      name="billingAlerts"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border border-white/10 p-4">
                          <div className="space-y-0.5">
                            <FormLabel className="text-white">Billing Alerts</FormLabel>
                            <FormDescription className="text-white/50">
                              Receive notifications about billing and payments
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                              className="data-[state=checked]:bg-fluxcloud-cyan"
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                  </div>
                  <Button
                    type="submit"
                    className="bg-fluxcloud-cyan text-black hover:bg-fluxcloud-cyan/80 shadow-neon-cyan btn-hover-effect"
                    disabled={isNotificationLoading}
                  >
                    {isNotificationLoading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Saving...
                      </>
                    ) : (
                      "Save Changes"
                    )}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="security">
          <Card className="glass-card border-white/10">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Shield className="h-5 w-5 text-fluxcloud-navy-green" />
                Security Settings
              </CardTitle>
              <CardDescription className="text-white/70">
                Manage your account security and authentication
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...securityForm}>
                <form onSubmit={securityForm.handleSubmit(onSecuritySubmit)} className="space-y-6">
                  <div className="space-y-4">
                    <FormField
                      control={securityForm.control}
                      name="twoFactorAuth"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border border-white/10 p-4">
                          <div className="space-y-0.5">
                            <FormLabel className="text-white">Two-Factor Authentication</FormLabel>
                            <FormDescription className="text-white/50">
                              Add an extra layer of security to your account
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                              className="data-[state=checked]:bg-fluxcloud-navy-green"
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={securityForm.control}
                      name="sessionTimeout"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border border-white/10 p-4">
                          <div className="space-y-0.5">
                            <FormLabel className="text-white">Session Timeout (minutes)</FormLabel>
                            <FormDescription className="text-white/50">
                              Automatically log out after a period of inactivity
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Select value={field.value} onValueChange={field.onChange}>
                              <SelectTrigger className="w-[100px] bg-white/5 border-white/10 text-white">
                                <SelectValue placeholder="Select" />
                              </SelectTrigger>
                              <SelectContent className="bg-fluxcloud-black/95 border-white/10 text-white">
                                <SelectItem value="15">15</SelectItem>
                                <SelectItem value="30">30</SelectItem>
                                <SelectItem value="60">60</SelectItem>
                                <SelectItem value="120">120</SelectItem>
                                <SelectItem value="never">Never</SelectItem>
                              </SelectContent>
                            </Select>
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={securityForm.control}
                      name="loginNotifications"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border border-white/10 p-4">
                          <div className="space-y-0.5">
                            <FormLabel className="text-white">Login Notifications</FormLabel>
                            <FormDescription className="text-white/50">
                              Receive notifications when someone logs into your account
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                              className="data-[state=checked]:bg-fluxcloud-navy-green"
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    <div className="rounded-lg border border-white/10 p-4">
                      <h3 className="text-sm font-medium text-white mb-2 flex items-center gap-2">
                        <Key className="h-4 w-4 text-fluxcloud-navy-yellow" />
                        Change Password
                      </h3>
                      <p className="text-white/50 text-sm mb-4">Change your account password to maintain security</p>
                      <Button
                        variant="outline"
                        className="border-white/10 text-white hover:bg-white/10 hover:text-fluxcloud-cyan"
                      >
                        Change Password
                      </Button>
                    </div>
                  </div>
                  <Button
                    type="submit"
                    className="bg-fluxcloud-navy-green text-black hover:bg-fluxcloud-navy-green/80 shadow-neon-green btn-hover-effect"
                    disabled={isSecurityLoading}
                  >
                    {isSecurityLoading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Saving...
                      </>
                    ) : (
                      "Save Changes"
                    )}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="appearance">
          <Card className="glass-card border-white/10">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Globe className="h-5 w-5 text-fluxcloud-navy-yellow" />
                Appearance Settings
              </CardTitle>
              <CardDescription className="text-white/70">
                Customize your dashboard appearance and localization
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...appearanceForm}>
                <form onSubmit={appearanceForm.handleSubmit(onAppearanceSubmit)} className="space-y-6">
                  <div className="space-y-4">
                    <FormField
                      control={appearanceForm.control}
                      name="theme"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-white">Theme</FormLabel>
                          <FormControl>
                            <Select value={field.value} onValueChange={field.onChange}>
                              <SelectTrigger className="bg-white/5 border-white/10 text-white">
                                <SelectValue placeholder="Select theme" />
                              </SelectTrigger>
                              <SelectContent className="bg-fluxcloud-black/95 border-white/10 text-white">
                                <SelectItem value="dark">Dark</SelectItem>
                                <SelectItem value="light">Light</SelectItem>
                                <SelectItem value="system">System</SelectItem>
                              </SelectContent>
                            </Select>
                          </FormControl>
                          <FormDescription className="text-white/50">Choose your preferred theme</FormDescription>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={appearanceForm.control}
                      name="language"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-white">Language</FormLabel>
                          <FormControl>
                            <Select value={field.value} onValueChange={field.onChange}>
                              <SelectTrigger className="bg-white/5 border-white/10 text-white">
                                <SelectValue placeholder="Select language" />
                              </SelectTrigger>
                              <SelectContent className="bg-fluxcloud-black/95 border-white/10 text-white">
                                <SelectItem value="en">English</SelectItem>
                                <SelectItem value="es">Spanish</SelectItem>
                                <SelectItem value="fr">French</SelectItem>
                                <SelectItem value="de">German</SelectItem>
                                <SelectItem value="ja">Japanese</SelectItem>
                                <SelectItem value="zh">Chinese</SelectItem>
                              </SelectContent>
                            </Select>
                          </FormControl>
                          <FormDescription className="text-white/50">Choose your preferred language</FormDescription>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={appearanceForm.control}
                      name="timezone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-white">Timezone</FormLabel>
                          <FormControl>
                            <Select value={field.value} onValueChange={field.onChange}>
                              <SelectTrigger className="bg-white/5 border-white/10 text-white">
                                <SelectValue placeholder="Select timezone" />
                              </SelectTrigger>
                              <SelectContent className="bg-fluxcloud-black/95 border-white/10 text-white">
                                <SelectItem value="UTC">UTC</SelectItem>
                                <SelectItem value="EST">Eastern Time (EST)</SelectItem>
                                <SelectItem value="CST">Central Time (CST)</SelectItem>
                                <SelectItem value="MST">Mountain Time (MST)</SelectItem>
                                <SelectItem value="PST">Pacific Time (PST)</SelectItem>
                                <SelectItem value="IST">India Standard Time (IST)</SelectItem>
                              </SelectContent>
                            </Select>
                          </FormControl>
                          <FormDescription className="text-white/50">
                            Choose your timezone for accurate time display
                          </FormDescription>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={appearanceForm.control}
                      name="dateFormat"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-white">Date Format</FormLabel>
                          <FormControl>
                            <Select value={field.value} onValueChange={field.onChange}>
                              <SelectTrigger className="bg-white/5 border-white/10 text-white">
                                <SelectValue placeholder="Select date format" />
                              </SelectTrigger>
                              <SelectContent className="bg-fluxcloud-black/95 border-white/10 text-white">
                                <SelectItem value="MM/DD/YYYY">MM/DD/YYYY</SelectItem>
                                <SelectItem value="DD/MM/YYYY">DD/MM/YYYY</SelectItem>
                                <SelectItem value="YYYY-MM-DD">YYYY-MM-DD</SelectItem>
                              </SelectContent>
                            </Select>
                          </FormControl>
                          <FormDescription className="text-white/50">Choose your preferred date format</FormDescription>
                        </FormItem>
                      )}
                    />
                  </div>
                  <Button
                    type="submit"
                    className="bg-fluxcloud-navy-yellow text-black hover:bg-fluxcloud-navy-yellow/80 shadow-neon-yellow btn-hover-effect"
                    disabled={isAppearanceLoading}
                  >
                    {isAppearanceLoading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Saving...
                      </>
                    ) : (
                      "Save Changes"
                    )}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

