"use client"

import { useState } from "react"
import { useAuth } from "@/components/auth-provider"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { AlertCircle } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { useRouter } from "next/navigation"

export default function LoginPage() {
  const { login, user } = useAuth()
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)
  const router = useRouter()

  // If already logged in, redirect to the appropriate dashboard
  if (user) {
    if (user.role === "ADMIN") {
      router.push("/admin/dashboard")
    } else {
      router.push("/client/dashboard")
    }
  }

  const handleLogin = async (role: "ADMIN" | "CLIENT") => {
    setLoading(true)
    setError("")

    try {
      const success = await login(role)

      if (!success) {
        setError("Login failed. Please try again.")
      }
    } catch (err) {
      console.error("Login error:", err)
      setError("An unexpected error occurred. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-gray-900 to-gray-800 p-4">
      <Card className="w-full max-w-md border-gray-700 bg-gray-800 text-white shadow-xl">
        <CardHeader className="space-y-1">
          <CardTitle className="text-2xl font-bold text-center">FluxCloud Dashboard</CardTitle>
          <CardDescription className="text-gray-400 text-center">Select a role to continue</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {error && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <div className="space-y-2">
            <Button
              className="w-full bg-blue-600 hover:bg-blue-700"
              onClick={() => handleLogin("ADMIN")}
              disabled={loading}
            >
              {loading ? "Logging in..." : "Login as Admin"}
            </Button>

            <Button
              className="w-full bg-green-600 hover:bg-green-700"
              onClick={() => handleLogin("CLIENT")}
              disabled={loading}
            >
              {loading ? "Logging in..." : "Login as Client"}
            </Button>
          </div>
        </CardContent>
        <CardFooter className="text-center text-sm text-gray-400">
          <p className="w-full">This is a demo application. Choose a role to explore the dashboard.</p>
        </CardFooter>
      </Card>
    </div>
  )
}

