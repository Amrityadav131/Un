"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { useAuth } from "@/components/auth-provider"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertCircle, ArrowRight, ArrowUpRight, FileText, Users, Server, DollarSign, Clock, Ticket } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Loader } from "@/components/loader"

export default function AdminDashboard() {
  const { user } = useAuth()
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [stats, setStats] = useState({
    totalUsers: 0,
    activeUsers: 0,
    totalInvoices: 0,
    pendingInvoices: 0,
    totalRevenue: 0,
    paidRevenue: 0,
    monthlyRevenue: 0,
    recentInvoices: [],
    recentUsers: [],
    openTickets: 0,
  })
  const apiUrl = process.env.NEXT_PUBLIC_API_URL || "/api"

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        // Fetch users
        const usersResponse = await fetch(`${apiUrl}/admin/users`, {
          credentials: "include",
        })

        if (!usersResponse.ok) throw new Error("Failed to fetch users")
        const usersData = await usersResponse.json()

        // Fetch invoices
        const invoicesResponse = await fetch(`${apiUrl}/admin/invoices`, {
          credentials: "include",
        })

        if (!invoicesResponse.ok) throw new Error("Failed to fetch invoices")
        const invoicesData = await invoicesResponse.json()

        // Fetch tickets
        let ticketsData = []
        try {
          const ticketsResponse = await fetch(`${apiUrl}/admin/tickets`, {
            credentials: "include",
          })
          if (ticketsResponse.ok) {
            ticketsData = await ticketsResponse.json()
          }
        } catch (err) {
          console.error("Error fetching tickets:", err)
        }

        // Calculate stats
        const activeUsers = usersData.filter((user) => user.status === "ACTIVE" && user.role === "CLIENT").length
        const pendingInvoices = invoicesData.filter((invoice) => invoice.status === "PENDING").length
        const totalRevenue = invoicesData.reduce((sum, invoice) => sum + (invoice.total || invoice.amount || 0), 0)
        const paidRevenue = invoicesData
          .filter((invoice) => invoice.status === "PAID")
          .reduce((sum, invoice) => sum + (invoice.total || invoice.amount || 0), 0)

        // Calculate monthly revenue (last 30 days)
        const thirtyDaysAgo = new Date()
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30)

        const monthlyRevenue = invoicesData
          .filter((invoice) => new Date(invoice.createdAt) >= thirtyDaysAgo && invoice.status === "PAID")
          .reduce((sum, invoice) => sum + (invoice.total || invoice.amount || 0), 0)

        // Get recent invoices and users
        const recentInvoices = invoicesData
          .sort((a, b) => new Date(b.createdAt || Date.now()).getTime() - new Date(a.createdAt || Date.now()).getTime())
          .slice(0, 5)

        const recentUsers = usersData
          .filter((user) => user.role === "CLIENT")
          .sort((a, b) => new Date(b.createdAt || Date.now()).getTime() - new Date(a.createdAt || Date.now()).getTime())
          .slice(0, 5)

        setStats({
          totalUsers: usersData.filter((user) => user.role === "CLIENT").length,
          activeUsers,
          totalInvoices: invoicesData.length,
          pendingInvoices,
          totalRevenue,
          paidRevenue,
          monthlyRevenue,
          recentInvoices,
          recentUsers,
          openTickets: ticketsData.filter((ticket) => ticket.status === "OPEN").length || 0,
        })

        setLoading(false)
      } catch (err) {
        console.error("Error fetching dashboard data:", err)
        setError("Failed to load dashboard data. Please try again.")
        setLoading(false)
      }
    }

    fetchDashboardData()
  }, [apiUrl])

  // Function to format currency
  const formatCurrency = (amount) => {
    return `₹${(amount || 0).toFixed(2)}`
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full w-full p-6">
        <Loader />
      </div>
    )
  }

  if (error) {
    return (
      <div className="p-6 space-y-4">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
        <Button onClick={() => window.location.reload()}>Try Again</Button>
      </div>
    )
  }

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-white neon-text-cyan">Admin Dashboard</h1>
        <p className="text-white/70">
          Welcome back, {user?.name || "Admin"}. Here's what's happening with your platform.
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="glass-card border-white/10">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-white">Total Clients</CardTitle>
            <Users className="h-4 w-4 text-fluxcloud-cyan" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{stats.totalUsers}</div>
            <p className="text-xs text-white/70">{stats.activeUsers} active clients</p>
          </CardContent>
        </Card>
        <Card className="glass-card border-white/10">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-white">Total Invoices</CardTitle>
            <FileText className="h-4 w-4 text-fluxcloud-navy-green" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{stats.totalInvoices}</div>
            <p className="text-xs text-white/70">{stats.pendingInvoices} pending invoices</p>
          </CardContent>
        </Card>
        <Card className="glass-card border-white/10">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-white">Total Revenue</CardTitle>
            <DollarSign className="h-4 w-4 text-fluxcloud-navy-yellow" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{formatCurrency(stats.totalRevenue)}</div>
            <p className="text-xs text-white/70">{formatCurrency(stats.paidRevenue)} paid</p>
          </CardContent>
        </Card>
        <Card className="glass-card border-white/10">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-white">Open Tickets</CardTitle>
            <Ticket className="h-4 w-4 text-purple-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{stats.openTickets}</div>
            <p className="text-xs text-white/70 flex items-center">
              <Clock className="h-3 w-3 mr-1 text-yellow-500" />
              <span className="text-yellow-500">Awaiting response</span>
            </p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="invoices" className="w-full">
        <TabsList className="bg-fluxcloud-black/40 border border-white/10 p-1">
          <TabsTrigger
            value="invoices"
            className="data-[state=active]:bg-fluxcloud-cyan data-[state=active]:text-black rounded-md"
          >
            Recent Invoices
          </TabsTrigger>
          <TabsTrigger
            value="clients"
            className="data-[state=active]:bg-fluxcloud-cyan data-[state=active]:text-black rounded-md"
          >
            Recent Clients
          </TabsTrigger>
        </TabsList>

        <TabsContent value="invoices" className="mt-4">
          <Card className="glass-card border-white/10">
            <CardHeader>
              <CardTitle className="text-white">Recent Invoices</CardTitle>
              <CardDescription className="text-white/70">Latest invoices created in the system</CardDescription>
            </CardHeader>
            <CardContent>
              {stats.recentInvoices.length > 0 ? (
                <Table>
                  <TableHeader className="bg-white/5">
                    <TableRow className="border-white/10 hover:bg-white/5">
                      <TableHead className="text-white">Invoice #</TableHead>
                      <TableHead className="text-white">Client</TableHead>
                      <TableHead className="text-white">Status</TableHead>
                      <TableHead className="text-white">Amount</TableHead>
                      <TableHead className="text-white">Date</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {stats.recentInvoices.map((invoice) => (
                      <TableRow key={invoice.id} className="border-white/10 hover:bg-white/5">
                        <TableCell className="font-medium text-white">{invoice.invoiceNumber}</TableCell>
                        <TableCell className="text-white">{invoice.userName || "N/A"}</TableCell>
                        <TableCell>
                          {invoice.status === "PAID" ? (
                            <Badge className="bg-green-500 text-black">Paid</Badge>
                          ) : invoice.status === "PENDING" ? (
                            <Badge className="bg-yellow-500 text-black">Pending</Badge>
                          ) : invoice.status === "OVERDUE" ? (
                            <Badge className="bg-red-500 text-black">Overdue</Badge>
                          ) : (
                            <Badge className="bg-gray-500 text-black">Cancelled</Badge>
                          )}
                        </TableCell>
                        <TableCell className="text-white">{formatCurrency(invoice.total || invoice.amount)}</TableCell>
                        <TableCell className="text-white/70">
                          {new Date(invoice.createdAt || Date.now()).toLocaleDateString()}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="text-center py-6 text-white/70">
                  No invoices found. Create your first invoice to get started.
                </div>
              )}
            </CardContent>
            <CardFooter>
              <Button
                variant="outline"
                className="w-full border-white/10 text-white hover:bg-white/10 hover:text-fluxcloud-cyan"
                onClick={() => (window.location.href = "/admin/invoices")}
              >
                View All Invoices
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="clients" className="mt-4">
          <Card className="glass-card border-white/10">
            <CardHeader>
              <CardTitle className="text-white">Recent Clients</CardTitle>
              <CardDescription className="text-white/70">Latest clients registered in the system</CardDescription>
            </CardHeader>
            <CardContent>
              {stats.recentUsers.length > 0 ? (
                <Table>
                  <TableHeader className="bg-white/5">
                    <TableRow className="border-white/10 hover:bg-white/5">
                      <TableHead className="text-white">Name</TableHead>
                      <TableHead className="text-white">Email</TableHead>
                      <TableHead className="text-white">Status</TableHead>
                      <TableHead className="text-white">Company</TableHead>
                      <TableHead className="text-white">Joined</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {stats.recentUsers.map((user) => (
                      <TableRow key={user.id} className="border-white/10 hover:bg-white/5">
                        <TableCell className="font-medium text-white">{user.name}</TableCell>
                        <TableCell className="text-white">{user.email}</TableCell>
                        <TableCell>
                          {user.status === "ACTIVE" ? (
                            <Badge className="bg-green-500 text-black">Active</Badge>
                          ) : (
                            <Badge className="bg-gray-500 text-black">Inactive</Badge>
                          )}
                        </TableCell>
                        <TableCell className="text-white">{user.company || "N/A"}</TableCell>
                        <TableCell className="text-white/70">
                          {new Date(user.createdAt || Date.now()).toLocaleDateString()}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="text-center py-6 text-white/70">
                  No clients found. Add your first client to get started.
                </div>
              )}
            </CardContent>
            <CardFooter>
              <Button
                variant="outline"
                className="w-full border-white/10 text-white hover:bg-white/10 hover:text-fluxcloud-cyan"
                onClick={() => (window.location.href = "/admin/users")}
              >
                View All Clients
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="grid gap-4 md:grid-cols-2">
        <Card className="glass-card border-white/10">
          <CardHeader>
            <CardTitle className="text-white">Quick Actions</CardTitle>
            <CardDescription className="text-white/70">Common administrative tasks</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            <Button
              variant="outline"
              className="w-full justify-between border-white/10 text-white hover:bg-white/10 hover:text-fluxcloud-cyan"
              onClick={() => (window.location.href = "/admin/invoices/create")}
            >
              <span className="flex items-center">
                <FileText className="mr-2 h-4 w-4" />
                Create New Invoice
              </span>
              <ArrowUpRight className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              className="w-full justify-between border-white/10 text-white hover:bg-white/10 hover:text-fluxcloud-cyan"
              onClick={() => (window.location.href = "/admin/users/create")}
            >
              <span className="flex items-center">
                <Users className="mr-2 h-4 w-4" />
                Add New Client
              </span>
              <ArrowUpRight className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              className="w-full justify-between border-white/10 text-white hover:bg-white/10 hover:text-fluxcloud-cyan"
              onClick={() => (window.location.href = "/admin/services")}
            >
              <span className="flex items-center">
                <Server className="mr-2 h-4 w-4" />
                Manage Services
              </span>
              <ArrowUpRight className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              className="w-full justify-between border-white/10 text-white hover:bg-white/10 hover:text-fluxcloud-cyan"
              onClick={() => (window.location.href = "/admin/expenses")}
            >
              <span className="flex items-center">
                <DollarSign className="mr-2 h-4 w-4" />
                Manage Expenses
              </span>
              <ArrowUpRight className="h-4 w-4" />
            </Button>
          </CardContent>
        </Card>

        <Card className="glass-card border-white/10">
          <CardHeader>
            <CardTitle className="text-white">Pending Tasks</CardTitle>
            <CardDescription className="text-white/70">Items that require your attention</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between p-3 bg-white/5 rounded-md">
              <div className="flex items-center">
                <Clock className="h-4 w-4 text-yellow-500 mr-2" />
                <span className="text-white">{stats.pendingInvoices} Pending Invoices</span>
              </div>
              <Button
                variant="ghost"
                size="sm"
                className="text-white hover:bg-white/10 hover:text-fluxcloud-cyan"
                onClick={() => (window.location.href = "/admin/invoices?status=PENDING")}
              >
                View
              </Button>
            </div>
            <div className="flex items-center justify-between p-3 bg-white/5 rounded-md">
              <div className="flex items-center">
                <AlertCircle className="h-4 w-4 text-red-500 mr-2" />
                <span className="text-white">Overdue Invoices</span>
              </div>
              <Button
                variant="ghost"
                size="sm"
                className="text-white hover:bg-white/10 hover:text-fluxcloud-cyan"
                onClick={() => (window.location.href = "/admin/invoices?status=OVERDUE")}
              >
                View
              </Button>
            </div>
            <div className="flex items-center justify-between p-3 bg-white/5 rounded-md">
              <div className="flex items-center">
                <Ticket className="h-4 w-4 text-purple-500 mr-2" />
                <span className="text-white">{stats.openTickets} Open Support Tickets</span>
              </div>
              <Button
                variant="ghost"
                size="sm"
                className="text-white hover:bg-white/10 hover:text-fluxcloud-cyan"
                onClick={() => (window.location.href = "/admin/support")}
              >
                View
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

