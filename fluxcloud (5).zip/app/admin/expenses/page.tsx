"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { AlertCircle, Plus, Edit, Trash2, DollarSign } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Loader } from "@/components/loader"
import { useToast } from "@/components/ui/use-toast"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function AdminExpensesPage() {
  const { toast } = useToast()
  const [expenses, setExpenses] = useState([])
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState(null)
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [currentExpense, setCurrentExpense] = useState(null)
  const [formData, setFormData] = useState({
    description: "",
    amount: "",
    category: "",
    date: new Date().toISOString().split("T")[0],
  })
  const apiUrl = process.env.NEXT_PUBLIC_API_URL || "/api"

  const categories = [
    "Office Supplies",
    "Utilities",
    "Rent",
    "Salaries",
    "Marketing",
    "Software",
    "Hardware",
    "Travel",
    "Miscellaneous",
  ]

  useEffect(() => {
    fetchExpenses()
  }, [])

  const fetchExpenses = async () => {
    try {
      const response = await fetch(`${apiUrl}/admin/expenses`, {
        credentials: "include",
      })

      if (!response.ok) {
        if (response.status === 404) {
          // If no expenses found, just set empty array
          setExpenses([])
          setLoading(false)
          return
        }
        throw new Error("Failed to fetch expenses")
      }

      const data = await response.json()
      setExpenses(Array.isArray(data) ? data : [])
      setLoading(false)
    } catch (err) {
      console.error("Error fetching expenses:", err)
      setError("Failed to load expenses. Please try again.")
      setLoading(false)
      setExpenses([])
    }
  }

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setFormData({
      ...formData,
      [name]: value,
    })
  }

  const handleSelectChange = (name, value) => {
    setFormData({
      ...formData,
      [name]: value,
    })
  }

  const handleAddExpense = async (e) => {
    e.preventDefault()
    setSubmitting(true)

    try {
      const response = await fetch(`${apiUrl}/admin/expenses`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify({
          description: formData.description,
          amount: Number.parseFloat(formData.amount),
          category: formData.category,
          date: formData.date,
        }),
      })

      if (!response.ok) throw new Error("Failed to add expense")

      toast({
        title: "Expense added",
        description: "The expense has been added successfully.",
      })

      // Reset form and close dialog
      setFormData({
        description: "",
        amount: "",
        category: "",
        date: new Date().toISOString().split("T")[0],
      })
      setIsAddDialogOpen(false)

      // Refresh expenses
      await fetchExpenses()
    } catch (err) {
      console.error("Error adding expense:", err)
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to add expense. Please try again.",
      })
    } finally {
      setSubmitting(false)
    }
  }

  const handleEditExpense = async (e) => {
    e.preventDefault()
    setSubmitting(true)

    try {
      const response = await fetch(`${apiUrl}/admin/expenses/${currentExpense.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify({
          description: formData.description,
          amount: Number.parseFloat(formData.amount),
          category: formData.category,
          date: formData.date,
        }),
      })

      if (!response.ok) throw new Error("Failed to update expense")

      toast({
        title: "Expense updated",
        description: "The expense has been updated successfully.",
      })

      // Reset form and close dialog
      setFormData({
        description: "",
        amount: "",
        category: "",
        date: new Date().toISOString().split("T")[0],
      })
      setCurrentExpense(null)
      setIsEditDialogOpen(false)

      // Refresh expenses
      await fetchExpenses()
    } catch (err) {
      console.error("Error updating expense:", err)
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to update expense. Please try again.",
      })
    } finally {
      setSubmitting(false)
    }
  }

  const handleDeleteExpense = async (id) => {
    if (!confirm("Are you sure you want to delete this expense?")) return

    setLoading(true)

    try {
      const response = await fetch(`${apiUrl}/admin/expenses/${id}`, {
        method: "DELETE",
        credentials: "include",
      })

      if (!response.ok) throw new Error("Failed to delete expense")

      toast({
        title: "Expense deleted",
        description: "The expense has been deleted successfully.",
      })

      // Refresh expenses
      await fetchExpenses()
    } catch (err) {
      console.error("Error deleting expense:", err)
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to delete expense. Please try again.",
      })
      setLoading(false)
    }
  }

  const openEditDialog = (expense) => {
    setCurrentExpense(expense)
    setFormData({
      description: expense.description,
      amount: expense.amount.toString(),
      category: expense.category,
      date: new Date(expense.date).toISOString().split("T")[0],
    })
    setIsEditDialogOpen(true)
  }

  // Function to format currency
  const formatCurrency = (amount) => {
    return `₹${Number.parseFloat(amount).toFixed(2)}`
  }

  // Function to format date
  const formatDate = (dateString) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("en-IN", {
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  // Calculate total expenses
  const totalExpenses = expenses.reduce((sum, expense) => sum + Number.parseFloat(expense.amount), 0)

  // Group expenses by month
  const expensesByMonth = expenses.reduce((acc, expense) => {
    const date = new Date(expense.date)
    const monthYear = `${date.getMonth() + 1}-${date.getFullYear()}`

    if (!acc[monthYear]) {
      acc[monthYear] = {
        month: date.toLocaleDateString("en-IN", { month: "long", year: "numeric" }),
        total: 0,
        expenses: [],
      }
    }

    acc[monthYear].total += Number.parseFloat(expense.amount)
    acc[monthYear].expenses.push(expense)

    return acc
  }, {})

  if (loading && expenses.length === 0) {
    return (
      <div className="flex items-center justify-center h-full w-full p-6">
        <Loader />
      </div>
    )
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-white neon-text-cyan">Expense Management</h1>
          <p className="text-white/70">Track and manage your business expenses</p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-fluxcloud-cyan hover:bg-fluxcloud-cyan/80 text-black">
              <Plus className="mr-2 h-4 w-4" /> Add Expense
            </Button>
          </DialogTrigger>
          <DialogContent className="glass-card border-white/10">
            <DialogHeader>
              <DialogTitle className="text-white">Add New Expense</DialogTitle>
              <DialogDescription className="text-white/70">
                Fill in the details to add a new expense record.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleAddExpense}>
              <div className="grid gap-4 py-4">
                <div className="grid gap-2">
                  <Label htmlFor="description" className="text-white">
                    Description
                  </Label>
                  <Textarea
                    id="description"
                    name="description"
                    value={formData.description}
                    onChange={handleInputChange}
                    className="bg-white/5 border-white/10 text-white"
                    required
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="amount" className="text-white">
                      Amount (₹)
                    </Label>
                    <Input
                      id="amount"
                      name="amount"
                      type="number"
                      step="0.01"
                      min="0"
                      value={formData.amount}
                      onChange={handleInputChange}
                      className="bg-white/5 border-white/10 text-white"
                      required
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="date" className="text-white">
                      Date
                    </Label>
                    <Input
                      id="date"
                      name="date"
                      type="date"
                      value={formData.date}
                      onChange={handleInputChange}
                      className="bg-white/5 border-white/10 text-white"
                      required
                    />
                  </div>
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="category" className="text-white">
                    Category
                  </Label>
                  <Select
                    value={formData.category}
                    onValueChange={(value) => handleSelectChange("category", value)}
                    required
                  >
                    <SelectTrigger className="bg-white/5 border-white/10 text-white">
                      <SelectValue placeholder="Select a category" />
                    </SelectTrigger>
                    <SelectContent className="bg-fluxcloud-black border-white/10">
                      {categories.map((category) => (
                        <SelectItem key={category} value={category} className="text-white hover:bg-white/10">
                          {category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsAddDialogOpen(false)}
                  className="border-white/10 text-white hover:bg-white/10"
                  disabled={submitting}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  className="bg-fluxcloud-cyan hover:bg-fluxcloud-cyan/80 text-black"
                  disabled={submitting}
                >
                  {submitting ? "Adding..." : "Add Expense"}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="glass-card border-white/10">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-white">Total Expenses</CardTitle>
            <DollarSign className="h-4 w-4 text-fluxcloud-navy-yellow" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{formatCurrency(totalExpenses)}</div>
            <p className="text-xs text-white/70">All time expenses</p>
          </CardContent>
        </Card>
      </div>

      {Object.keys(expensesByMonth).length > 0 ? (
        <div className="space-y-6">
          {Object.values(expensesByMonth)
            .sort((a, b) => {
              const dateA = new Date(a.expenses[0].date)
              const dateB = new Date(b.expenses[0].date)
              return dateB - dateA // Sort by most recent month first
            })
            .map((monthData, index) => (
              <Card key={index} className="glass-card border-white/10">
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <CardTitle className="text-white">{monthData.month}</CardTitle>
                    <div className="text-lg font-semibold text-fluxcloud-cyan">{formatCurrency(monthData.total)}</div>
                  </div>
                  <CardDescription className="text-white/70">Expenses for this month</CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader className="bg-white/5">
                      <TableRow className="border-white/10 hover:bg-white/5">
                        <TableHead className="text-white">Date</TableHead>
                        <TableHead className="text-white">Description</TableHead>
                        <TableHead className="text-white">Category</TableHead>
                        <TableHead className="text-white">Amount</TableHead>
                        <TableHead className="text-white">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {monthData.expenses
                        .sort((a, b) => new Date(b.date) - new Date(a.date))
                        .map((expense) => (
                          <TableRow key={expense.id} className="border-white/10 hover:bg-white/5">
                            <TableCell className="text-white">{formatDate(expense.date)}</TableCell>
                            <TableCell className="font-medium text-white">{expense.description}</TableCell>
                            <TableCell className="text-white">{expense.category}</TableCell>
                            <TableCell className="text-white">{formatCurrency(expense.amount)}</TableCell>
                            <TableCell className="flex space-x-2">
                              <Button
                                variant="ghost"
                                size="icon"
                                className="text-white hover:bg-white/10 hover:text-fluxcloud-cyan"
                                onClick={() => openEditDialog(expense)}
                              >
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="text-white hover:bg-white/10 hover:text-red-500"
                                onClick={() => handleDeleteExpense(expense.id)}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            ))}
        </div>
      ) : (
        <Card className="glass-card border-white/10">
          <CardContent className="text-center py-6 text-white/70">
            No expenses found. Add your first expense to get started.
          </CardContent>
        </Card>
      )}

      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="glass-card border-white/10">
          <DialogHeader>
            <DialogTitle className="text-white">Edit Expense</DialogTitle>
            <DialogDescription className="text-white/70">Update the details of this expense.</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleEditExpense}>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="edit-description" className="text-white">
                  Description
                </Label>
                <Textarea
                  id="edit-description"
                  name="description"
                  value={formData.description}
                  onChange={handleInputChange}
                  className="bg-white/5 border-white/10 text-white"
                  required
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="edit-amount" className="text-white">
                    Amount (₹)
                  </Label>
                  <Input
                    id="edit-amount"
                    name="amount"
                    type="number"
                    step="0.01"
                    min="0"
                    value={formData.amount}
                    onChange={handleInputChange}
                    className="bg-white/5 border-white/10 text-white"
                    required
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="edit-date" className="text-white">
                    Date
                  </Label>
                  <Input
                    id="edit-date"
                    name="date"
                    type="date"
                    value={formData.date}
                    onChange={handleInputChange}
                    className="bg-white/5 border-white/10 text-white"
                    required
                  />
                </div>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-category" className="text-white">
                  Category
                </Label>
                <Select
                  value={formData.category}
                  onValueChange={(value) => handleSelectChange("category", value)}
                  required
                >
                  <SelectTrigger className="bg-white/5 border-white/10 text-white">
                    <SelectValue placeholder="Select a category" />
                  </SelectTrigger>
                  <SelectContent className="bg-fluxcloud-black border-white/10">
                    {categories.map((category) => (
                      <SelectItem key={category} value={category} className="text-white hover:bg-white/10">
                        {category}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setIsEditDialogOpen(false)}
                className="border-white/10 text-white hover:bg-white/10"
                disabled={submitting}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                className="bg-fluxcloud-cyan hover:bg-fluxcloud-cyan/80 text-black"
                disabled={submitting}
              >
                {submitting ? "Updating..." : "Update Expense"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  )
}

