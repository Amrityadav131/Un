"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { toast } from "@/components/ui/use-toast"
import { Loader } from "@/components/loader"
import { ArrowLeft, Edit, Trash2 } from "lucide-react"

interface Invoice {
  id: string
  description: string
  amount: number
  status: "paid" | "pending" | "overdue"
  dueDate: string
  createdAt: string
}

interface Client {
  id: string
  name: string
  email: string
  discordId?: string
  phone?: string
  address?: string
  createdAt: string
  updatedAt: string
  invoices: Invoice[]
}

export default function ClientDetailPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const [client, setClient] = useState<Client | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const fetchClient = async () => {
      try {
        const response = await fetch(`/api/admin/clients/${params.id}`)
        if (!response.ok) {
          if (response.status === 404) {
            toast({
              title: "Client not found",
              description: "The requested client does not exist",
              variant: "destructive",
            })
            router.push("/admin/clients")
            return
          }
          throw new Error("Failed to fetch client")
        }
        const data = await response.json()
        setClient(data)
      } catch (error) {
        console.error("Error fetching client:", error)
        toast({
          title: "Error",
          description: "Failed to load client details",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    fetchClient()
  }, [params.id, router])

  const handleDelete = async () => {
    if (!client) return

    if (!confirm(`Are you sure you want to delete client "${client.name}"?`)) {
      return
    }

    try {
      const response = await fetch(`/api/admin/clients/${client.id}`, {
        method: "DELETE",
      })

      if (!response.ok) {
        throw new Error("Failed to delete client")
      }

      toast({
        title: "Success",
        description: `Client "${client.name}" deleted successfully`,
      })
      router.push("/admin/clients")
    } catch (error) {
      console.error("Error deleting client:", error)
      toast({
        title: "Error",
        description: "Failed to delete client",
        variant: "destructive",
      })
    }
  }

  if (isLoading) {
    return (
      <div className="container mx-auto py-10 flex justify-center">
        <Loader size="lg" />
      </div>
    )
  }

  if (!client) {
    return (
      <div className="container mx-auto py-10">
        <Card>
          <CardContent className="pt-6 text-center">
            <p>Client not found</p>
            <Button variant="link" onClick={() => router.push("/admin/clients")} className="mt-2">
              Back to clients
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-10">
      <div className="mb-6">
        <Button variant="outline" onClick={() => router.back()}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back
        </Button>
      </div>

      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">{client.name}</h1>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => router.push(`/admin/clients/${client.id}/edit`)}>
            <Edit className="mr-2 h-4 w-4" />
            Edit
          </Button>
          <Button variant="destructive" onClick={handleDelete}>
            <Trash2 className="mr-2 h-4 w-4" />
            Delete
          </Button>
        </div>
      </div>

      <Tabs defaultValue="details">
        <TabsList>
          <TabsTrigger value="details">Details</TabsTrigger>
          <TabsTrigger value="invoices">Invoices</TabsTrigger>
        </TabsList>

        <TabsContent value="details">
          <Card>
            <CardHeader>
              <CardTitle>Client Information</CardTitle>
              <CardDescription>View client details</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Email</h3>
                  <p>{client.email}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Discord ID</h3>
                  <p>{client.discordId || "-"}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Phone</h3>
                  <p>{client.phone || "-"}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Created</h3>
                  <p>{new Date(client.createdAt).toLocaleDateString()}</p>
                </div>
              </div>

              {client.address && (
                <div className="mt-4">
                  <h3 className="text-sm font-medium text-muted-foreground">Address</h3>
                  <p className="whitespace-pre-line">{client.address}</p>
                </div>
              )}

              <div className="mt-6">
                <Button onClick={() => router.push(`/admin/invoices/create?clientId=${client.id}`)}>
                  Create Invoice
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="invoices">
          <Card>
            <CardHeader>
              <CardTitle>Client Invoices</CardTitle>
              <CardDescription>View and manage invoices for this client</CardDescription>
            </CardHeader>
            <CardContent>
              {client.invoices.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <p>No invoices found for this client</p>
                  <Button
                    variant="link"
                    onClick={() => router.push(`/admin/invoices/create?clientId=${client.id}`)}
                    className="mt-2"
                  >
                    Create an invoice
                  </Button>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="py-2 text-left">Description</th>
                        <th className="py-2 text-left">Amount</th>
                        <th className="py-2 text-left">Status</th>
                        <th className="py-2 text-left">Due Date</th>
                        <th className="py-2 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {client.invoices.map((invoice) => (
                        <tr key={invoice.id} className="border-b">
                          <td className="py-2">{invoice.description}</td>
                          <td className="py-2">${invoice.amount.toFixed(2)}</td>
                          <td className="py-2">
                            <span
                              className={`px-2 py-1 rounded-full text-xs ${
                                invoice.status === "paid"
                                  ? "bg-green-100 text-green-800"
                                  : invoice.status === "pending"
                                    ? "bg-yellow-100 text-yellow-800"
                                    : "bg-red-100 text-red-800"
                              }`}
                            >
                              {invoice.status.charAt(0).toUpperCase() + invoice.status.slice(1)}
                            </span>
                          </td>
                          <td className="py-2">{new Date(invoice.dueDate).toLocaleDateString()}</td>
                          <td className="py-2 text-right">
                            <Button variant="link" onClick={() => router.push(`/admin/invoices/${invoice.id}`)}>
                              View
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

