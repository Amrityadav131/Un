"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { format } from "date-fns"
import { ArrowLeft, Edit, Trash2, Send, AlertCircle } from "lucide-react"
import { toast } from "sonner"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Loader } from "@/components/loader"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

interface Invoice {
  id: string
  clientId?: string
  clientName?: string
  email: string
  discordId?: string
  description: string
  services?: string
  amount: number
  status: "paid" | "pending" | "overdue"
  dueDate: string
  repaymentDate?: string
  items?: Array<{ description: string; amount: number }>
  createdAt: string
  updatedAt: string
}

export default function InvoiceDetailPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const [invoice, setInvoice] = useState<Invoice | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isDeleting, setIsDeleting] = useState(false)
  const [isSendingWebhook, setIsSendingWebhook] = useState(false)
  const [webhookSent, setWebhookSent] = useState(false)
  const [openDialog, setOpenDialog] = useState(false)

  useEffect(() => {
    async function fetchInvoice() {
      try {
        setIsLoading(true)
        const response = await fetch(`/api/admin/invoices/${params.id}`)

        if (!response.ok) {
          throw new Error("Failed to fetch invoice")
        }

        const data = await response.json()
        setInvoice(data)
      } catch (error) {
        console.error("Error fetching invoice:", error)
        toast.error("Failed to fetch invoice details")
      } finally {
        setIsLoading(false)
      }
    }

    fetchInvoice()
  }, [params.id])

  const handleDelete = async () => {
    try {
      setIsDeleting(true)
      const response = await fetch(`/api/admin/invoices/${params.id}`, {
        method: "DELETE",
      })

      if (!response.ok) {
        throw new Error("Failed to delete invoice")
      }

      toast.success("Invoice deleted successfully")
      router.push("/admin/invoices")
      router.refresh()
    } catch (error) {
      console.error("Error deleting invoice:", error)
      toast.error("Failed to delete invoice")
    } finally {
      setIsDeleting(false)
      setOpenDialog(false)
    }
  }

  const handleSendWebhook = async () => {
    try {
      setIsSendingWebhook(true)
      const response = await fetch(`/api/admin/invoices/${params.id}/webhook`, {
        method: "POST",
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.message || "Failed to send webhook notification")
      }

      const data = await response.json()

      if (data.success) {
        setWebhookSent(true)
        toast.success("Discord notification sent successfully")
      } else {
        throw new Error("Failed to send Discord notification")
      }
    } catch (error) {
      console.error("Error sending webhook:", error)
      toast.error("Failed to send Discord notification")
    } finally {
      setIsSendingWebhook(false)
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "paid":
        return <Badge className="bg-green-500">Paid</Badge>
      case "pending":
        return <Badge className="bg-yellow-500">Pending</Badge>
      case "overdue":
        return <Badge className="bg-red-500">Overdue</Badge>
      default:
        return <Badge>{status}</Badge>
    }
  }

  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <Loader />
      </div>
    )
  }

  if (!invoice) {
    return (
      <div className="container mx-auto py-10">
        <Card>
          <CardHeader>
            <CardTitle>Invoice Not Found</CardTitle>
            <CardDescription>The requested invoice could not be found.</CardDescription>
          </CardHeader>
          <CardFooter>
            <Button variant="outline" onClick={() => router.push("/admin/invoices")}>
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Invoices
            </Button>
          </CardFooter>
        </Card>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-10">
      <div className="flex justify-between items-center mb-6">
        <Button variant="outline" onClick={() => router.push("/admin/invoices")}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Invoices
        </Button>
        <div className="flex space-x-2">
          <Button variant={webhookSent ? "outline" : "default"} onClick={handleSendWebhook} disabled={isSendingWebhook}>
            <Send className="mr-2 h-4 w-4" />
            {isSendingWebhook ? "Sending..." : webhookSent ? "Notification Sent" : "Send Discord Notification"}
          </Button>
          <Button variant="outline" onClick={() => router.push(`/admin/invoices/${params.id}/edit`)}>
            <Edit className="mr-2 h-4 w-4" />
            Edit
          </Button>
          <Dialog open={openDialog} onOpenChange={setOpenDialog}>
            <DialogTrigger asChild>
              <Button variant="destructive">
                <Trash2 className="mr-2 h-4 w-4" />
                Delete
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Are you sure you want to delete this invoice?</DialogTitle>
                <DialogDescription>
                  This action cannot be undone. This will permanently delete the invoice.
                </DialogDescription>
              </DialogHeader>
              <DialogFooter>
                <Button variant="outline" onClick={() => setOpenDialog(false)}>
                  Cancel
                </Button>
                <Button variant="destructive" onClick={handleDelete} disabled={isDeleting}>
                  {isDeleting ? "Deleting..." : "Delete"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {invoice.discordId && (
        <Alert className="mb-6">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Discord Notification Available</AlertTitle>
          <AlertDescription>
            This invoice is linked to Discord user ID: {invoice.discordId}. You can send a notification to this user via
            Discord.
          </AlertDescription>
        </Alert>
      )}

      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle className="text-2xl">Invoice #{invoice.id}</CardTitle>
              <CardDescription>Created on {format(new Date(invoice.createdAt), "PPP")}</CardDescription>
            </div>
            <div>{getStatusBadge(invoice.status)}</div>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-lg font-semibold mb-2">Client Information</h3>
              <div className="space-y-2">
                <p>
                  <span className="font-medium">Email:</span> {invoice.email}
                </p>
                {invoice.discordId && (
                  <p>
                    <span className="font-medium">Discord ID:</span> {invoice.discordId}
                  </p>
                )}
                {invoice.clientName && (
                  <p>
                    <span className="font-medium">Client Name:</span> {invoice.clientName}
                  </p>
                )}
              </div>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-2">Invoice Details</h3>
              <div className="space-y-2">
                <p>
                  <span className="font-medium">Amount:</span> ${invoice.amount.toFixed(2)}
                </p>
                <p>
                  <span className="font-medium">Due Date:</span> {format(new Date(invoice.dueDate), "PPP")}
                </p>
                {invoice.repaymentDate && (
                  <p>
                    <span className="font-medium">Repayment Date:</span>{" "}
                    {format(new Date(invoice.repaymentDate), "PPP")}
                  </p>
                )}
              </div>
            </div>
          </div>

          <Separator />

          {invoice.services && (
            <>
              <div>
                <h3 className="text-lg font-semibold mb-2">Services</h3>
                <p>{invoice.services}</p>
              </div>
              <Separator />
            </>
          )}

          <div>
            <h3 className="text-lg font-semibold mb-2">Description</h3>
            <p className="whitespace-pre-line">{invoice.description}</p>
          </div>

          {invoice.items && invoice.items.length > 0 && (
            <>
              <Separator />
              <div>
                <h3 className="text-lg font-semibold mb-2">Items</h3>
                <div className="space-y-4">
                  {invoice.items.map((item, index) => (
                    <div key={index} className="flex justify-between">
                      <span>{item.description}</span>
                      <span className="font-medium">${Number.parseFloat(item.amount.toString()).toFixed(2)}</span>
                    </div>
                  ))}
                  <div className="flex justify-between pt-2 border-t font-semibold">
                    <span>Total</span>
                    <span>${invoice.amount.toFixed(2)}</span>
                  </div>
                </div>
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

