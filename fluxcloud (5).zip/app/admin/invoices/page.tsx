"use client"

import { useState, useEffect } from "react"
import {
  FileText,
  Plus,
  Search,
  Filter,
  ArrowUpDown,
  AlertCircle,
  Calendar,
  Clock,
  Download,
  Trash,
  Edit,
  Eye,
  CheckCircle,
  XCircle,
  AlertTriangle,
} from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { EmptyPlaceholder } from "@/components/empty-placeholder"
import { useAuth } from "@/components/auth-provider"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/components/ui/use-toast"
import { Separator } from "@/components/ui/separator"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"

const invoiceFormSchema = z.object({
  userId: z.string({
    required_error: "Please select a client",
  }),
  description: z.string().min(5, {
    message: "Description must be at least 5 characters.",
  }),
  amount: z.coerce.number().positive({
    message: "Amount must be a positive number.",
  }),
  tax: z.coerce.number().min(0, {
    message: "Tax must be a non-negative number.",
  }),
  dueDate: z.string({
    required_error: "Please select a due date",
  }),
  status: z.enum(["PENDING", "PAID", "OVERDUE", "CANCELLED"], {
    required_error: "Please select a status",
  }),
  items: z
    .array(
      z.object({
        name: z.string().min(1, { message: "Item name is required" }),
        description: z.string().optional(),
        quantity: z.coerce.number().positive({ message: "Quantity must be positive" }),
        unitPrice: z.coerce.number().positive({ message: "Unit price must be positive" }),
      }),
    )
    .min(1, { message: "At least one item is required" }),
})

export default function AdminInvoicesPage() {
  const { user } = useAuth()
  const { toast } = useToast()
  const [invoices, setInvoices] = useState([])
  const [users, setUsers] = useState([])
  const [services, setServices] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [sortBy, setSortBy] = useState("createdAt")
  const [sortOrder, setSortOrder] = useState("desc")
  const [selectedInvoice, setSelectedInvoice] = useState(null)
  const [createDialogOpen, setCreateDialogOpen] = useState(false)
  const [editDialogOpen, setEditDialogOpen] = useState(false)
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [viewDialogOpen, setViewDialogOpen] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const apiUrl = process.env.NEXT_PUBLIC_API_URL || "/api"

  const form = useForm<z.infer<typeof invoiceFormSchema>>({
    resolver: zodResolver(invoiceFormSchema),
    defaultValues: {
      description: "",
      amount: 0,
      tax: 0,
      status: "PENDING",
      items: [{ name: "", description: "", quantity: 1, unitPrice: 0 }],
    },
  })

  const editForm = useForm<z.infer<typeof invoiceFormSchema>>({
    resolver: zodResolver(invoiceFormSchema),
    defaultValues: {
      description: "",
      amount: 0,
      tax: 0,
      status: "PENDING",
      items: [{ name: "", description: "", quantity: 1, unitPrice: 0 }],
    },
  })

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Fetch invoices
        const invoicesResponse = await fetch(`${apiUrl}/clients/invoices`, {
          credentials: "include",
        })

        if (!invoicesResponse.ok) throw new Error("Failed to fetch invoices")
        const invoicesData = await invoicesResponse.json()
        setInvoices(invoicesData)

        // Fetch users
        const usersResponse = await fetch(`${apiUrl}/admin/users`, {
          credentials: "include",
        })

        if (!usersResponse.ok) throw new Error("Failed to fetch users")
        const usersData = await usersResponse.json()
        setUsers(usersData)

        // Fetch services
        const servicesResponse = await fetch(`${apiUrl}/admin/services`, {
          credentials: "include",
        })

        if (!servicesResponse.ok) throw new Error("Failed to fetch services")
        const servicesData = await servicesResponse.json()
        setServices(servicesData)

        setLoading(false)
      } catch (err) {
        console.error("Error fetching data:", err)
        setError("Failed to load data. Please try again.")
        setLoading(false)
      }
    }

    fetchData()
  }, [apiUrl])

  // Filter and sort invoices
  const filteredInvoices = invoices
    .filter((invoice) => {
      // Apply status filter
      if (statusFilter !== "all" && invoice.status !== statusFilter) {
        return false
      }

      // Apply search filter
      if (searchQuery) {
        const query = searchQuery.toLowerCase()
        return (
          invoice.invoiceNumber.toLowerCase().includes(query) ||
          invoice.userName?.toLowerCase().includes(query) ||
          invoice.userEmail?.toLowerCase().includes(query) ||
          (invoice.description && invoice.description.toLowerCase().includes(query))
        )
      }

      return true
    })
    .sort((a, b) => {
      // Apply sorting
      const aValue = a[sortBy]
      const bValue = b[sortBy]

      if (sortBy === "dueDate" || sortBy === "createdAt" || sortBy === "paidDate") {
        return sortOrder === "asc"
          ? new Date(aValue || 0).getTime() - new Date(bValue || 0).getTime()
          : new Date(bValue || 0).getTime() - new Date(aValue || 0).getTime()
      }

      if (typeof aValue === "string") {
        return sortOrder === "asc" ? aValue.localeCompare(bValue) : bValue.localeCompare(aValue)
      }

      return sortOrder === "asc" ? aValue - bValue : bValue - aValue
    })

  const toggleSort = (field) => {
    if (sortBy === field) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc")
    } else {
      setSortBy(field)
      setSortOrder("desc")
    }
  }

  const getStatusBadge = (status) => {
    switch (status) {
      case "PAID":
        return (
          <Badge className="bg-green-500 text-black hover:bg-green-600 flex items-center gap-1">
            <CheckCircle className="h-3 w-3" />
            Paid
          </Badge>
        )
      case "PENDING":
        return (
          <Badge className="bg-yellow-500 text-black hover:bg-yellow-600 flex items-center gap-1">
            <Clock className="h-3 w-3" />
            Pending
          </Badge>
        )
      case "OVERDUE":
        return (
          <Badge className="bg-red-500 text-black hover:bg-red-600 flex items-center gap-1">
            <AlertTriangle className="h-3 w-3" />
            Overdue
          </Badge>
        )
      case "CANCELLED":
        return (
          <Badge className="bg-gray-500 text-black hover:bg-gray-600 flex items-center gap-1">
            <XCircle className="h-3 w-3" />
            Cancelled
          </Badge>
        )
      default:
        return <Badge>{status}</Badge>
    }
  }

  // Function to format currency
  const formatCurrency = (amount) => {
    return `₹${amount.toFixed(2)}`
  }

  const handleCreateInvoice = async (data) => {
    setIsSubmitting(true)

    try {
      // Calculate total for each item
      const itemsWithTotal = data.items.map((item) => ({
        ...item,
        total: item.quantity * item.unitPrice,
      }))

      // Calculate total amount if not provided
      const calculatedAmount = itemsWithTotal.reduce((sum, item) => sum + item.total, 0)
      const amount = data.amount || calculatedAmount

      // Calculate total with tax
      const total = amount + data.tax

      // Find the user to get their name and email
      const selectedUser = users.find((user) => user.id === data.userId)

      const invoiceData = {
        ...data,
        amount,
        total,
        items: itemsWithTotal,
        userName: selectedUser?.name,
        userEmail: selectedUser?.email,
      }

      // In a real app, this would call an API endpoint
      const response = await fetch(`${apiUrl}/clients/invoices`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(invoiceData),
        credentials: "include",
      })

      if (!response.ok) throw new Error("Failed to create invoice")

      const newInvoice = await response.json()

      // Update the local state
      setInvoices([newInvoice, ...invoices])

      toast({
        title: "Invoice Created",
        description: `Invoice ${newInvoice.invoiceNumber} has been created successfully.`,
      })

      setCreateDialogOpen(false)
      form.reset()
    } catch (error) {
      console.error("Error creating invoice:", error)
      toast({
        title: "Error",
        description: "Failed to create invoice. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleEditInvoice = async (data) => {
    if (!selectedInvoice) return

    setIsSubmitting(true)

    try {
      // Calculate total for each item
      const itemsWithTotal = data.items.map((item) => ({
        ...item,
        total: item.quantity * item.unitPrice,
      }))

      // Calculate total amount if not provided
      const calculatedAmount = itemsWithTotal.reduce((sum, item) => sum + item.total, 0)
      const amount = data.amount || calculatedAmount

      // Calculate total with tax
      const total = amount + data.tax

      // Find the user to get their name and email
      const selectedUser = users.find((user) => user.id === data.userId)

      const invoiceData = {
        ...data,
        amount,
        total,
        items: itemsWithTotal,
        userName: selectedUser?.name,
        userEmail: selectedUser?.email,
      }

      // In a real app, this would call an API endpoint
      const response = await fetch(`${apiUrl}/clients/invoices/${selectedInvoice.id}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(invoiceData),
        credentials: "include",
      })

      if (!response.ok) throw new Error("Failed to update invoice")

      const updatedInvoice = await response.json()

      // Update the local state
      setInvoices(invoices.map((inv) => (inv.id === selectedInvoice.id ? updatedInvoice : inv)))

      toast({
        title: "Invoice Updated",
        description: `Invoice ${updatedInvoice.invoiceNumber} has been updated successfully.`,
      })

      setEditDialogOpen(false)
      setSelectedInvoice(null)
    } catch (error) {
      console.error("Error updating invoice:", error)
      toast({
        title: "Error",
        description: "Failed to update invoice. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleDeleteInvoice = async () => {
    if (!selectedInvoice) return

    try {
      // In a real app, this would call an API endpoint
      const response = await fetch(`${apiUrl}/clients/invoices/${selectedInvoice.id}`, {
        method: "DELETE",
        credentials: "include",
      })

      if (!response.ok) throw new Error("Failed to delete invoice")

      // Update the local state
      setInvoices(invoices.filter((inv) => inv.id !== selectedInvoice.id))

      toast({
        title: "Invoice Deleted",
        description: `Invoice ${selectedInvoice.invoiceNumber} has been deleted successfully.`,
      })

      setDeleteDialogOpen(false)
      setSelectedInvoice(null)
    } catch (error) {
      console.error("Error deleting invoice:", error)
      toast({
        title: "Error",
        description: "Failed to delete invoice. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleViewInvoice = (invoice) => {
    setSelectedInvoice(invoice)
    setViewDialogOpen(true)
  }

  const handleEditClick = (invoice) => {
    setSelectedInvoice(invoice)

    // Set form values
    editForm.reset({
      userId: invoice.userId,
      description: invoice.description,
      amount: invoice.amount,
      tax: invoice.tax || 0,
      dueDate: new Date(invoice.dueDate).toISOString().split("T")[0],
      status: invoice.status,
      items: invoice.items || [{ name: "", description: "", quantity: 1, unitPrice: 0 }],
    })

    setEditDialogOpen(true)
  }

  const handleDeleteClick = (invoice) => {
    setSelectedInvoice(invoice)
    setDeleteDialogOpen(true)
  }

  // Function to add a new item field
  const addItemField = () => {
    const items = form.getValues("items") || []
    form.setValue("items", [...items, { name: "", description: "", quantity: 1, unitPrice: 0 }])
  }

  // Function to remove an item field
  const removeItemField = (index) => {
    const items = form.getValues("items")
    if (items.length <= 1) return // Keep at least one item

    form.setValue(
      "items",
      items.filter((_, i) => i !== index),
    )
  }

  // Function to add a new item field in edit form
  const addEditItemField = () => {
    const items = editForm.getValues("items") || []
    editForm.setValue("items", [...items, { name: "", description: "", quantity: 1, unitPrice: 0 }])
  }

  // Function to remove an item field in edit form
  const removeEditItemField = (index) => {
    const items = editForm.getValues("items")
    if (items.length <= 1) return // Keep at least one item

    editForm.setValue(
      "items",
      items.filter((_, i) => i !== index),
    )
  }

  // Function to calculate total amount based on items
  const calculateTotal = (items) => {
    return items.reduce((sum, item) => sum + item.quantity * item.unitPrice, 0)
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full w-full p-6">
        <div className="h-12 w-12 rounded-full border-4 border-fluxcloud-cyan border-t-transparent animate-spin"></div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="p-6 space-y-4">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
        <Button onClick={() => window.location.reload()}>Try Again</Button>
      </div>
    )
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <h1 className="text-3xl font-bold tracking-tight text-white neon-text-cyan">Invoice Management</h1>
        <div className="flex gap-2">
          <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-fluxcloud-cyan text-black hover:bg-fluxcloud-cyan/80 shadow-neon-cyan btn-hover-effect">
                <Plus className="mr-2 h-4 w-4" />
                Create Invoice
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-fluxcloud-black/95 border-white/10 text-white backdrop-blur-md max-w-4xl">
              <DialogHeader>
                <DialogTitle className="text-xl">Create New Invoice</DialogTitle>
                <DialogDescription className="text-white/70">
                  Fill out the form below to create a new invoice for a client.
                </DialogDescription>
              </DialogHeader>

              <Form {...form}>
                <form onSubmit={form.handleSubmit(handleCreateInvoice)} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="userId"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-white">Client</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger className="bg-white/5 border-white/10 text-white">
                                <SelectValue placeholder="Select a client" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent className="bg-fluxcloud-black/95 border-white/10 text-white">
                              {users
                                .filter((user) => user.role === "CLIENT")
                                .map((user) => (
                                  <SelectItem key={user.id} value={user.id}>
                                    {user.name} ({user.email})
                                  </SelectItem>
                                ))}
                            </SelectContent>
                          </Select>
                          <FormMessage className="text-red-400" />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="dueDate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-white">Due Date</FormLabel>
                          <FormControl>
                            <Input type="date" className="bg-white/5 border-white/10 text-white" {...field} />
                          </FormControl>
                          <FormMessage className="text-red-400" />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="status"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-white">Status</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger className="bg-white/5 border-white/10 text-white">
                                <SelectValue placeholder="Select status" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent className="bg-fluxcloud-black/95 border-white/10 text-white">
                              <SelectItem value="PENDING">Pending</SelectItem>
                              <SelectItem value="PAID">Paid</SelectItem>
                              <SelectItem value="OVERDUE">Overdue</SelectItem>
                              <SelectItem value="CANCELLED">Cancelled</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage className="text-red-400" />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-white">Description</FormLabel>
                          <FormControl>
                            <Input
                              className="bg-white/5 border-white/10 text-white"
                              placeholder="Invoice description"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage className="text-red-400" />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div>
                    <h3 className="text-white font-medium mb-2">Invoice Items</h3>
                    <div className="space-y-4">
                      {form.watch("items")?.map((item, index) => (
                        <div key={index} className="grid grid-cols-12 gap-2 items-start">
                          <div className="col-span-4">
                            <Label htmlFor={`items.${index}.name`} className="text-white/70 text-xs">
                              Item Name
                            </Label>
                            <Input
                              id={`items.${index}.name`}
                              className="bg-white/5 border-white/10 text-white mt-1"
                              placeholder="Item name"
                              {...form.register(`items.${index}.name`)}
                            />
                            {form.formState.errors.items?.[index]?.name && (
                              <p className="text-red-400 text-xs mt-1">
                                {form.formState.errors.items[index].name.message}
                              </p>
                            )}
                          </div>
                          <div className="col-span-3">
                            <Label htmlFor={`items.${index}.description`} className="text-white/70 text-xs">
                              Description
                            </Label>
                            <Input
                              id={`items.${index}.description`}
                              className="bg-white/5 border-white/10 text-white mt-1"
                              placeholder="Description"
                              {...form.register(`items.${index}.description`)}
                            />
                          </div>
                          <div className="col-span-2">
                            <Label htmlFor={`items.${index}.quantity`} className="text-white/70 text-xs">
                              Quantity
                            </Label>
                            <Input
                              id={`items.${index}.quantity`}
                              type="number"
                              className="bg-white/5 border-white/10 text-white mt-1"
                              min="1"
                              {...form.register(`items.${index}.quantity`)}
                            />
                            {form.formState.errors.items?.[index]?.quantity && (
                              <p className="text-red-400 text-xs mt-1">
                                {form.formState.errors.items[index].quantity.message}
                              </p>
                            )}
                          </div>
                          <div className="col-span-2">
                            <Label htmlFor={`items.${index}.unitPrice`} className="text-white/70 text-xs">
                              Unit Price
                            </Label>
                            <Input
                              id={`items.${index}.unitPrice`}
                              type="number"
                              className="bg-white/5 border-white/10 text-white mt-1"
                              min="0"
                              step="0.01"
                              {...form.register(`items.${index}.unitPrice`)}
                            />
                            {form.formState.errors.items?.[index]?.unitPrice && (
                              <p className="text-red-400 text-xs mt-1">
                                {form.formState.errors.items[index].unitPrice.message}
                              </p>
                            )}
                          </div>
                          <div className="col-span-1 pt-6">
                            <Button
                              type="button"
                              variant="ghost"
                              size="sm"
                              className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
                              onClick={() => removeItemField(index)}
                            >
                              <Trash className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      ))}

                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        className="border-white/10 text-white hover:bg-white/10 hover:text-fluxcloud-cyan"
                        onClick={addItemField}
                      >
                        <Plus className="h-4 w-4 mr-2" />
                        Add Item
                      </Button>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="amount"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-white">Amount (₹)</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              className="bg-white/5 border-white/10 text-white"
                              min="0"
                              step="0.01"
                              {...field}
                            />
                          </FormControl>
                          <FormDescription className="text-white/50 text-xs">
                            Leave empty to auto-calculate from items
                          </FormDescription>
                          <FormMessage className="text-red-400" />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="tax"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-white">Tax Amount (₹)</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              className="bg-white/5 border-white/10 text-white"
                              min="0"
                              step="0.01"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage className="text-red-400" />
                        </FormItem>
                      )}
                    />
                  </div>

                  <DialogFooter>
                    <Button
                      type="button"
                      variant="outline"
                      className="border-white/10 text-white hover:bg-white/10 hover:text-fluxcloud-cyan"
                      onClick={() => setCreateDialogOpen(false)}
                      disabled={isSubmitting}
                    >
                      Cancel
                    </Button>
                    <Button
                      type="submit"
                      className="bg-fluxcloud-cyan text-black hover:bg-fluxcloud-cyan/80 shadow-neon-cyan btn-hover-effect"
                      disabled={isSubmitting}
                    >
                      {isSubmitting ? (
                        <>
                          <div className="h-4 w-4 rounded-full border-2 border-black border-t-transparent animate-spin mr-2"></div>
                          Creating...
                        </>
                      ) : (
                        "Create Invoice"
                      )}
                    </Button>
                  </DialogFooter>
                </form>
              </Form>
            </DialogContent>
          </Dialog>

          <Button variant="outline" className="border-white/10 text-white hover:bg-white/10 hover:text-fluxcloud-cyan">
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/50" />
          <Input
            placeholder="Search invoices..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9 bg-white/5 border-white/10 text-white placeholder:text-white/50 focus-visible:ring-fluxcloud-cyan"
          />
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              variant="outline"
              className="border-white/10 text-white hover:bg-white/10 hover:text-fluxcloud-cyan"
            >
              <Filter className="mr-2 h-4 w-4" />
              Filter: {statusFilter === "all" ? "All" : statusFilter}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="bg-fluxcloud-black/90 border-white/10 backdrop-blur-md">
            <DropdownMenuLabel>Filter by Status</DropdownMenuLabel>
            <DropdownMenuSeparator className="bg-white/10" />
            <DropdownMenuItem
              onClick={() => setStatusFilter("all")}
              className={`${statusFilter === "all" ? "bg-white/10 text-fluxcloud-cyan" : "text-white/70"} hover:bg-white/10 hover:text-fluxcloud-cyan`}
            >
              All
            </DropdownMenuItem>
            <DropdownMenuItem
              onClick={() => setStatusFilter("PAID")}
              className={`${statusFilter === "PAID" ? "bg-white/10 text-fluxcloud-cyan" : "text-white/70"} hover:bg-white/10 hover:text-fluxcloud-cyan`}
            >
              Paid
            </DropdownMenuItem>
            <DropdownMenuItem
              onClick={() => setStatusFilter("PENDING")}
              className={`${statusFilter === "PENDING" ? "bg-white/10 text-fluxcloud-cyan" : "text-white/70"} hover:bg-white/10 hover:text-fluxcloud-cyan`}
            >
              Pending
            </DropdownMenuItem>
            <DropdownMenuItem
              onClick={() => setStatusFilter("OVERDUE")}
              className={`${statusFilter === "OVERDUE" ? "bg-white/10 text-fluxcloud-cyan" : "text-white/70"} hover:bg-white/10 hover:text-fluxcloud-cyan`}
            >
              Overdue
            </DropdownMenuItem>
            <DropdownMenuItem
              onClick={() => setStatusFilter("CANCELLED")}
              className={`${statusFilter === "CANCELLED" ? "bg-white/10 text-fluxcloud-cyan" : "text-white/70"} hover:bg-white/10 hover:text-fluxcloud-cyan`}
            >
              Cancelled
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <Tabs defaultValue="all" className="w-full">
        <TabsList className="bg-fluxcloud-black/40 border border-white/10 p-1">
          <TabsTrigger
            value="all"
            className="data-[state=active]:bg-fluxcloud-cyan data-[state=active]:text-black rounded-md"
          >
            All Invoices
          </TabsTrigger>
          <TabsTrigger
            value="pending"
            className="data-[state=active]:bg-fluxcloud-cyan data-[state=active]:text-black rounded-md"
          >
            Pending
          </TabsTrigger>
          <TabsTrigger
            value="paid"
            className="data-[state=active]:bg-fluxcloud-cyan data-[state=active]:text-black rounded-md"
          >
            Paid
          </TabsTrigger>
          <TabsTrigger
            value="overdue"
            className="data-[state=active]:bg-fluxcloud-cyan data-[state=active]:text-black rounded-md"
          >
            Overdue
          </TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="mt-4">
          <InvoiceTable
            invoices={filteredInvoices}
            sortBy={sortBy}
            sortOrder={sortOrder}
            toggleSort={toggleSort}
            getStatusBadge={getStatusBadge}
            formatCurrency={formatCurrency}
            handleViewInvoice={handleViewInvoice}
            handleEditClick={handleEditClick}
            handleDeleteClick={handleDeleteClick}
          />
        </TabsContent>

        <TabsContent value="pending" className="mt-4">
          <InvoiceTable
            invoices={filteredInvoices.filter((invoice) => invoice.status === "PENDING")}
            sortBy={sortBy}
            sortOrder={sortOrder}
            toggleSort={toggleSort}
            getStatusBadge={getStatusBadge}
            formatCurrency={formatCurrency}
            handleViewInvoice={handleViewInvoice}
            handleEditClick={handleEditClick}
            handleDeleteClick={handleDeleteClick}
          />
        </TabsContent>

        <TabsContent value="paid" className="mt-4">
          <InvoiceTable
            invoices={filteredInvoices.filter((invoice) => invoice.status === "PAID")}
            sortBy={sortBy}
            sortOrder={sortOrder}
            toggleSort={toggleSort}
            getStatusBadge={getStatusBadge}
            formatCurrency={formatCurrency}
            handleViewInvoice={handleViewInvoice}
            handleEditClick={handleEditClick}
            handleDeleteClick={handleDeleteClick}
          />
        </TabsContent>

        <TabsContent value="overdue" className="mt-4">
          <InvoiceTable
            invoices={filteredInvoices.filter((invoice) => invoice.status === "OVERDUE")}
            sortBy={sortBy}
            sortOrder={sortOrder}
            toggleSort={toggleSort}
            getStatusBadge={getStatusBadge}
            formatCurrency={formatCurrency}
            handleViewInvoice={handleViewInvoice}
            handleEditClick={handleEditClick}
            handleDeleteClick={handleDeleteClick}
          />
        </TabsContent>
      </Tabs>

      {/* Edit Invoice Dialog */}
      {selectedInvoice && (
        <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
          <DialogContent className="bg-fluxcloud-black/95 border-white/10 text-white backdrop-blur-md max-w-4xl">
            <DialogHeader>
              <DialogTitle className="text-xl">Edit Invoice</DialogTitle>
              <DialogDescription className="text-white/70">
                Update the invoice details for {selectedInvoice.invoiceNumber}.
              </DialogDescription>
            </DialogHeader>

            <Form {...editForm}>
              <form onSubmit={editForm.handleSubmit(handleEditInvoice)} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={editForm.control}
                    name="userId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white">Client</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger className="bg-white/5 border-white/10 text-white">
                              <SelectValue placeholder="Select a client" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent className="bg-fluxcloud-black/95 border-white/10 text-white">
                            {users
                              .filter((user) => user.role === "CLIENT")
                              .map((user) => (
                                <SelectItem key={user.id} value={user.id}>
                                  {user.name} ({user.email})
                                </SelectItem>
                              ))}
                          </SelectContent>
                        </Select>
                        <FormMessage className="text-red-400" />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={editForm.control}
                    name="dueDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white">Due Date</FormLabel>
                        <FormControl>
                          <Input type="date" className="bg-white/5 border-white/10 text-white" {...field} />
                        </FormControl>
                        <FormMessage className="text-red-400" />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={editForm.control}
                    name="status"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white">Status</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger className="bg-white/5 border-white/10 text-white">
                              <SelectValue placeholder="Select status" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent className="bg-fluxcloud-black/95 border-white/10 text-white">
                            <SelectItem value="PENDING">Pending</SelectItem>
                            <SelectItem value="PAID">Paid</SelectItem>
                            <SelectItem value="OVERDUE">Overdue</SelectItem>
                            <SelectItem value="CANCELLED">Cancelled</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage className="text-red-400" />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={editForm.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white">Description</FormLabel>
                        <FormControl>
                          <Input
                            className="bg-white/5 border-white/10 text-white"
                            placeholder="Invoice description"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage className="text-red-400" />
                      </FormItem>
                    )}
                  />
                </div>

                <div>
                  <h3 className="text-white font-medium mb-2">Invoice Items</h3>
                  <div className="space-y-4">
                    {editForm.watch("items")?.map((item, index) => (
                      <div key={index} className="grid grid-cols-12 gap-2 items-start">
                        <div className="col-span-4">
                          <Label htmlFor={`items.${index}.name`} className="text-white/70 text-xs">
                            Item Name
                          </Label>
                          <Input
                            id={`items.${index}.name`}
                            className="bg-white/5 border-white/10 text-white mt-1"
                            placeholder="Item name"
                            {...editForm.register(`items.${index}.name`)}
                          />
                          {editForm.formState.errors.items?.[index]?.name && (
                            <p className="text-red-400 text-xs mt-1">
                              {editForm.formState.errors.items[index].name.message}
                            </p>
                          )}
                        </div>
                        <div className="col-span-3">
                          <Label htmlFor={`items.${index}.description`} className="text-white/70 text-xs">
                            Description
                          </Label>
                          <Input
                            id={`items.${index}.description`}
                            className="bg-white/5 border-white/10 text-white mt-1"
                            placeholder="Description"
                            {...editForm.register(`items.${index}.description`)}
                          />
                        </div>
                        <div className="col-span-2">
                          <Label htmlFor={`items.${index}.quantity`} className="text-white/70 text-xs">
                            Quantity
                          </Label>
                          <Input
                            id={`items.${index}.quantity`}
                            type="number"
                            className="bg-white/5 border-white/10 text-white mt-1"
                            min="1"
                            {...editForm.register(`items.${index}.quantity`)}
                          />
                          {editForm.formState.errors.items?.[index]?.quantity && (
                            <p className="text-red-400 text-xs mt-1">
                              {editForm.formState.errors.items[index].quantity.message}
                            </p>
                          )}
                        </div>
                        <div className="col-span-2">
                          <Label htmlFor={`items.${index}.unitPrice`} className="text-white/70 text-xs">
                            Unit Price
                          </Label>
                          <Input
                            id={`items.${index}.unitPrice`}
                            type="number"
                            className="bg-white/5 border-white/10 text-white mt-1"
                            min="0"
                            step="0.01"
                            {...editForm.register(`items.${index}.unitPrice`)}
                          />
                          {editForm.formState.errors.items?.[index]?.unitPrice && (
                            <p className="text-red-400 text-xs mt-1">
                              {editForm.formState.errors.items[index].unitPrice.message}
                            </p>
                          )}
                        </div>
                        <div className="col-span-1 pt-6">
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
                            onClick={() => removeEditItemField(index)}
                          >
                            <Trash className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}

                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      className="border-white/10 text-white hover:bg-white/10 hover:text-fluxcloud-cyan"
                      onClick={addEditItemField}
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      Add Item
                    </Button>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={editForm.control}
                    name="amount"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white">Amount (₹)</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            className="bg-white/5 border-white/10 text-white"
                            min="0"
                            step="0.01"
                            {...field}
                          />
                        </FormControl>
                        <FormDescription className="text-white/50 text-xs">
                          Leave empty to auto-calculate from items
                        </FormDescription>
                        <FormMessage className="text-red-400" />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={editForm.control}
                    name="tax"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white">Tax Amount (₹)</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            className="bg-white/5 border-white/10 text-white"
                            min="0"
                            step="0.01"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage className="text-red-400" />
                      </FormItem>
                    )}
                  />
                </div>

                <DialogFooter>
                  <Button
                    type="button"
                    variant="outline"
                    className="border-white/10 text-white hover:bg-white/10 hover:text-fluxcloud-cyan"
                    onClick={() => setEditDialogOpen(false)}
                    disabled={isSubmitting}
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    className="bg-fluxcloud-cyan text-black hover:bg-fluxcloud-cyan/80 shadow-neon-cyan btn-hover-effect"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? (
                      <>
                        <div className="h-4 w-4 rounded-full border-2 border-black border-t-transparent animate-spin mr-2"></div>
                        Updating...
                      </>
                    ) : (
                      "Update Invoice"
                    )}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      )}

      {/* Delete Confirmation Dialog */}
      {selectedInvoice && (
        <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
          <DialogContent className="bg-fluxcloud-black/95 border-white/10 text-white backdrop-blur-md">
            <DialogHeader>
              <DialogTitle className="text-xl">Delete Invoice</DialogTitle>
              <DialogDescription className="text-white/70">
                Are you sure you want to delete invoice {selectedInvoice.invoiceNumber}? This action cannot be undone.
              </DialogDescription>
            </DialogHeader>

            <DialogFooter>
              <Button
                variant="outline"
                className="border-white/10 text-white hover:bg-white/10 hover:text-fluxcloud-cyan"
                onClick={() => setDeleteDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button
                variant="destructive"
                className="bg-red-500 text-white hover:bg-red-600"
                onClick={handleDeleteInvoice}
              >
                Delete
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* View Invoice Dialog */}
      {selectedInvoice && (
        <Dialog open={viewDialogOpen} onOpenChange={setViewDialogOpen}>
          <DialogContent className="bg-fluxcloud-black/95 border-white/10 text-white backdrop-blur-md max-w-3xl">
            <DialogHeader>
              <div className="flex justify-between items-center">
                <DialogTitle className="text-xl flex items-center gap-2">
                  <FileText className="h-5 w-5 text-fluxcloud-cyan" />
                  Invoice {selectedInvoice.invoiceNumber}
                </DialogTitle>
                {getStatusBadge(selectedInvoice.status)}
              </div>
              <DialogDescription className="text-white/70">
                Issued on {new Date(selectedInvoice.createdAt).toLocaleDateString()}
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-6">
              {/* Invoice Header */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h3 className="text-sm font-medium text-white/70">From</h3>
                  <p className="text-white font-medium">FluxCloud Technologies</p>
                  <p className="text-white/70 text-sm">123 Tech Street</p>
                  <p className="text-white/70 text-sm">Bangalore, Karnataka 560001</p>
                  <p className="text-white/70 text-sm">India</p>
                  <p className="text-white/70 text-sm">GST: 29ABCDE1234F1Z5</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-white/70">To</h3>
                  <p className="text-white font-medium">{selectedInvoice.userName}</p>
                  <p className="text-white/70 text-sm">{selectedInvoice.userEmail}</p>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div className="bg-white/5 p-3 rounded-md">
                  <h3 className="text-sm font-medium text-white/70">Invoice Number</h3>
                  <p className="text-white font-medium">{selectedInvoice.invoiceNumber}</p>
                </div>
                <div className="bg-white/5 p-3 rounded-md">
                  <h3 className="text-sm font-medium text-white/70">Issue Date</h3>
                  <p className="text-white font-medium">{new Date(selectedInvoice.createdAt).toLocaleDateString()}</p>
                </div>
                <div className="bg-white/5 p-3 rounded-md">
                  <h3 className="text-sm font-medium text-white/70">Due Date</h3>
                  <p className="text-white font-medium">{new Date(selectedInvoice.dueDate).toLocaleDateString()}</p>
                </div>
              </div>

              {/* Invoice Items */}
              <div>
                <h3 className="text-sm font-medium text-white mb-2">Invoice Items</h3>
                <Table>
                  <TableHeader className="bg-white/5">
                    <TableRow className="border-white/10">
                      <TableHead className="text-white">Item</TableHead>
                      <TableHead className="text-white">Description</TableHead>
                      <TableHead className="text-white text-right">Quantity</TableHead>
                      <TableHead className="text-white text-right">Unit Price</TableHead>
                      <TableHead className="text-white text-right">Total</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {selectedInvoice.items &&
                      selectedInvoice.items.map((item, index) => (
                        <TableRow key={index} className="border-white/10">
                          <TableCell className="text-white">{item.name}</TableCell>
                          <TableCell className="text-white/70">{item.description}</TableCell>
                          <TableCell className="text-white text-right">{item.quantity}</TableCell>
                          <TableCell className="text-white text-right">{formatCurrency(item.unitPrice)}</TableCell>
                          <TableCell className="text-white text-right">{formatCurrency(item.total)}</TableCell>
                        </TableRow>
                      ))}
                  </TableBody>
                </Table>
              </div>

              {/* Invoice Summary */}
              <div className="flex justify-end">
                <div className="w-64 space-y-2">
                  <div className="flex justify-between">
                    <span className="text-white/70">Subtotal:</span>
                    <span className="text-white">{formatCurrency(selectedInvoice.amount)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/70">Tax:</span>
                    <span className="text-white">{formatCurrency(selectedInvoice.tax || 0)}</span>
                  </div>
                  <Separator className="bg-white/10 my-2" />
                  <div className="flex justify-between font-bold">
                    <span className="text-white">Total:</span>
                    <span className="text-fluxcloud-cyan">
                      {formatCurrency(selectedInvoice.total || selectedInvoice.amount)}
                    </span>
                  </div>
                  {selectedInvoice.status === "PAID" && (
                    <div className="flex justify-between text-green-500">
                      <span>Paid on:</span>
                      <span>{new Date(selectedInvoice.paidDate).toLocaleDateString()}</span>
                    </div>
                  )}
                </div>
              </div>
            </div>

            <DialogFooter className="flex gap-2">
              <Button
                variant="outline"
                className="border-white/10 text-white hover:bg-white/10 hover:text-fluxcloud-cyan"
                onClick={() => setViewDialogOpen(false)}
              >
                Close
              </Button>
              <Button
                variant="outline"
                className="border-white/10 text-white hover:bg-white/10 hover:text-fluxcloud-cyan"
              >
                <Download className="mr-2 h-4 w-4" />
                Download PDF
              </Button>
              <Button
                className="bg-fluxcloud-cyan text-black hover:bg-fluxcloud-cyan/80 shadow-neon-cyan btn-hover-effect"
                onClick={() => {
                  setViewDialogOpen(false)
                  handleEditClick(selectedInvoice)
                }}
              >
                <Edit className="mr-2 h-4 w-4" />
                Edit
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  )
}

function InvoiceTable({
  invoices,
  sortBy,
  sortOrder,
  toggleSort,
  getStatusBadge,
  formatCurrency,
  handleViewInvoice,
  handleEditClick,
  handleDeleteClick,
}) {
  if (invoices.length === 0) {
    return (
      <EmptyPlaceholder icon={FileText} title="No invoices found" description="Create a new invoice to get started" />
    )
  }

  return (
    <Card className="glass-card border-white/10">
      <CardContent className="p-0">
        <Table>
          <TableHeader className="bg-white/5">
            <TableRow className="border-white/10 hover:bg-white/5">
              <TableHead className="text-white">
                <Button
                  variant="ghost"
                  className="p-0 font-medium text-white hover:text-fluxcloud-cyan hover:bg-transparent"
                  onClick={() => toggleSort("invoiceNumber")}
                >
                  Invoice #
                  <ArrowUpDown
                    className={`ml-2 h-4 w-4 ${sortBy === "invoiceNumber" ? "opacity-100" : "opacity-50"}`}
                  />
                </Button>
              </TableHead>
              <TableHead className="text-white">Client</TableHead>
              <TableHead className="text-white">
                <Button
                  variant="ghost"
                  className="p-0 font-medium text-white hover:text-fluxcloud-cyan hover:bg-transparent"
                  onClick={() => toggleSort("dueDate")}
                >
                  Due Date
                  <ArrowUpDown className={`ml-2 h-4 w-4 ${sortBy === "dueDate" ? "opacity-100" : "opacity-50"}`} />
                </Button>
              </TableHead>
              <TableHead className="text-white">Status</TableHead>
              <TableHead className="text-white">
                <Button
                  variant="ghost"
                  className="p-0 font-medium text-white hover:text-fluxcloud-cyan hover:bg-transparent"
                  onClick={() => toggleSort("amount")}
                >
                  Amount
                  <ArrowUpDown className={`ml-2 h-4 w-4 ${sortBy === "amount" ? "opacity-100" : "opacity-50"}`} />
                </Button>
              </TableHead>
              <TableHead className="text-right text-white">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {invoices.map((invoice) => (
              <TableRow key={invoice.id} className="border-white/10 hover:bg-white/5">
                <TableCell className="font-medium text-white">
                  <div className="flex items-center gap-2">
                    <FileText className="h-4 w-4 text-fluxcloud-cyan" />
                    <span>{invoice.invoiceNumber}</span>
                  </div>
                </TableCell>
                <TableCell className="text-white">
                  <div>
                    <div>{invoice.userName || "N/A"}</div>
                    <div className="text-sm text-white/70">{invoice.userEmail}</div>
                  </div>
                </TableCell>
                <TableCell className="text-white/70">
                  <div className="flex items-center gap-1">
                    <Calendar className="h-3 w-3 text-white/50" />
                    <span>{new Date(invoice.dueDate).toLocaleDateString()}</span>
                  </div>
                </TableCell>
                <TableCell>{getStatusBadge(invoice.status)}</TableCell>
                <TableCell className="text-white font-medium">
                  {formatCurrency(invoice.total || invoice.amount)}
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-white hover:bg-white/10 hover:text-fluxcloud-cyan"
                      onClick={() => handleViewInvoice(invoice)}
                    >
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-white hover:bg-white/10 hover:text-fluxcloud-cyan"
                      onClick={() => handleEditClick(invoice)}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-red-400 hover:bg-red-500/10 hover:text-red-300"
                      onClick={() => handleDeleteClick(invoice)}
                    >
                      <Trash className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}

