"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { AlertCircle, Plus, Edit, Trash2 } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Loader } from "@/components/loader"
import { useToast } from "@/components/ui/use-toast"

export default function AdminServicesPage() {
  const { toast } = useToast()
  const [services, setServices] = useState([])
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState(null)
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [currentService, setCurrentService] = useState(null)
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    price: "",
    category: "",
  })
  const apiUrl = process.env.NEXT_PUBLIC_API_URL || "/api"

  useEffect(() => {
    fetchServices()
  }, [])

  const fetchServices = async () => {
    try {
      const response = await fetch(`${apiUrl}/admin/services`, {
        credentials: "include",
      })

      if (!response.ok) {
        if (response.status === 404) {
          // If no services found, just set empty array
          setServices([])
          setLoading(false)
          return
        }
        throw new Error("Failed to fetch services")
      }

      const data = await response.json()
      setServices(Array.isArray(data) ? data : [])
      setLoading(false)
    } catch (err) {
      console.error("Error fetching services:", err)
      setError("Failed to load services. Please try again.")
      setLoading(false)
      setServices([])
    }
  }

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setFormData({
      ...formData,
      [name]: value,
    })
  }

  const handleAddService = async (e) => {
    e.preventDefault()
    setSubmitting(true)

    try {
      const response = await fetch(`${apiUrl}/admin/services`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify({
          name: formData.name,
          description: formData.description,
          price: Number.parseFloat(formData.price),
          category: formData.category,
        }),
      })

      if (!response.ok) throw new Error("Failed to add service")

      toast({
        title: "Service added",
        description: "The service has been added successfully.",
      })

      // Reset form and close dialog
      setFormData({
        name: "",
        description: "",
        price: "",
        category: "",
      })
      setIsAddDialogOpen(false)

      // Refresh services
      await fetchServices()
    } catch (err) {
      console.error("Error adding service:", err)
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to add service. Please try again.",
      })
    } finally {
      setSubmitting(false)
    }
  }

  const handleEditService = async (e) => {
    e.preventDefault()
    setSubmitting(true)

    try {
      const response = await fetch(`${apiUrl}/admin/services/${currentService.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify({
          name: formData.name,
          description: formData.description,
          price: Number.parseFloat(formData.price),
          category: formData.category,
        }),
      })

      if (!response.ok) throw new Error("Failed to update service")

      toast({
        title: "Service updated",
        description: "The service has been updated successfully.",
      })

      // Reset form and close dialog
      setFormData({
        name: "",
        description: "",
        price: "",
        category: "",
      })
      setCurrentService(null)
      setIsEditDialogOpen(false)

      // Refresh services
      await fetchServices()
    } catch (err) {
      console.error("Error updating service:", err)
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to update service. Please try again.",
      })
    } finally {
      setSubmitting(false)
    }
  }

  const handleDeleteService = async (id) => {
    if (!confirm("Are you sure you want to delete this service?")) return

    setLoading(true)

    try {
      const response = await fetch(`${apiUrl}/admin/services/${id}`, {
        method: "DELETE",
        credentials: "include",
      })

      if (!response.ok) throw new Error("Failed to delete service")

      toast({
        title: "Service deleted",
        description: "The service has been deleted successfully.",
      })

      // Refresh services
      await fetchServices()
    } catch (err) {
      console.error("Error deleting service:", err)
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to delete service. Please try again.",
      })
      setLoading(false)
    }
  }

  const openEditDialog = (service) => {
    setCurrentService(service)
    setFormData({
      name: service.name,
      description: service.description,
      price: service.price.toString(),
      category: service.category,
    })
    setIsEditDialogOpen(true)
  }

  // Function to format currency
  const formatCurrency = (amount) => {
    return `₹${Number.parseFloat(amount).toFixed(2)}`
  }

  if (loading && services.length === 0) {
    return (
      <div className="flex items-center justify-center h-full w-full p-6">
        <Loader />
      </div>
    )
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-white neon-text-cyan">Services Management</h1>
          <p className="text-white/70">Manage your service offerings and pricing</p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-fluxcloud-cyan hover:bg-fluxcloud-cyan/80 text-black">
              <Plus className="mr-2 h-4 w-4" /> Add Service
            </Button>
          </DialogTrigger>
          <DialogContent className="glass-card border-white/10">
            <DialogHeader>
              <DialogTitle className="text-white">Add New Service</DialogTitle>
              <DialogDescription className="text-white/70">
                Fill in the details to add a new service to your offerings.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleAddService}>
              <div className="grid gap-4 py-4">
                <div className="grid gap-2">
                  <Label htmlFor="name" className="text-white">
                    Service Name
                  </Label>
                  <Input
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    className="bg-white/5 border-white/10 text-white"
                    required
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="description" className="text-white">
                    Description
                  </Label>
                  <Textarea
                    id="description"
                    name="description"
                    value={formData.description}
                    onChange={handleInputChange}
                    className="bg-white/5 border-white/10 text-white"
                    required
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="price" className="text-white">
                      Price (₹)
                    </Label>
                    <Input
                      id="price"
                      name="price"
                      type="number"
                      step="0.01"
                      min="0"
                      value={formData.price}
                      onChange={handleInputChange}
                      className="bg-white/5 border-white/10 text-white"
                      required
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="category" className="text-white">
                      Category
                    </Label>
                    <Input
                      id="category"
                      name="category"
                      value={formData.category}
                      onChange={handleInputChange}
                      className="bg-white/5 border-white/10 text-white"
                      required
                    />
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsAddDialogOpen(false)}
                  className="border-white/10 text-white hover:bg-white/10"
                  disabled={submitting}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  className="bg-fluxcloud-cyan hover:bg-fluxcloud-cyan/80 text-black"
                  disabled={submitting}
                >
                  {submitting ? "Adding..." : "Add Service"}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <Card className="glass-card border-white/10">
        <CardHeader>
          <CardTitle className="text-white">Available Services</CardTitle>
          <CardDescription className="text-white/70">All services currently offered to clients</CardDescription>
        </CardHeader>
        <CardContent>
          {services.length > 0 ? (
            <Table>
              <TableHeader className="bg-white/5">
                <TableRow className="border-white/10 hover:bg-white/5">
                  <TableHead className="text-white">Name</TableHead>
                  <TableHead className="text-white">Description</TableHead>
                  <TableHead className="text-white">Category</TableHead>
                  <TableHead className="text-white">Price</TableHead>
                  <TableHead className="text-white">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {services.map((service) => (
                  <TableRow key={service.id} className="border-white/10 hover:bg-white/5">
                    <TableCell className="font-medium text-white">{service.name}</TableCell>
                    <TableCell className="text-white">{service.description}</TableCell>
                    <TableCell className="text-white">{service.category}</TableCell>
                    <TableCell className="text-white">{formatCurrency(service.price)}</TableCell>
                    <TableCell className="flex space-x-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="text-white hover:bg-white/10 hover:text-fluxcloud-cyan"
                        onClick={() => openEditDialog(service)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="text-white hover:bg-white/10 hover:text-red-500"
                        onClick={() => handleDeleteService(service.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="text-center py-6 text-white/70">
              No services found. Add your first service to get started.
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="glass-card border-white/10">
          <DialogHeader>
            <DialogTitle className="text-white">Edit Service</DialogTitle>
            <DialogDescription className="text-white/70">Update the details of this service.</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleEditService}>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="edit-name" className="text-white">
                  Service Name
                </Label>
                <Input
                  id="edit-name"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  className="bg-white/5 border-white/10 text-white"
                  required
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-description" className="text-white">
                  Description
                </Label>
                <Textarea
                  id="edit-description"
                  name="description"
                  value={formData.description}
                  onChange={handleInputChange}
                  className="bg-white/5 border-white/10 text-white"
                  required
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="edit-price" className="text-white">
                    Price (₹)
                  </Label>
                  <Input
                    id="edit-price"
                    name="price"
                    type="number"
                    step="0.01"
                    min="0"
                    value={formData.price}
                    onChange={handleInputChange}
                    className="bg-white/5 border-white/10 text-white"
                    required
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="edit-category" className="text-white">
                    Category
                  </Label>
                  <Input
                    id="edit-category"
                    name="category"
                    value={formData.category}
                    onChange={handleInputChange}
                    className="bg-white/5 border-white/10 text-white"
                    required
                  />
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setIsEditDialogOpen(false)}
                className="border-white/10 text-white hover:bg-white/10"
                disabled={submitting}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                className="bg-fluxcloud-cyan hover:bg-fluxcloud-cyan/80 text-black"
                disabled={submitting}
              >
                {submitting ? "Updating..." : "Update Service"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  )
}

