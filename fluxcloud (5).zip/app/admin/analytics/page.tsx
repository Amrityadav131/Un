"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { CalendarIcon } from "lucide-react"
import { format } from "date-fns"

// Sample data for charts
const revenueData = [
  { name: "Jan", revenue: 4000, expenses: 2400 },
  { name: "Feb", revenue: 3000, expenses: 1398 },
  { name: "Mar", revenue: 5000, expenses: 3000 },
  { name: "Apr", revenue: 4000, expenses: 2780 },
  { name: "May", revenue: 7000, expenses: 3908 },
  { name: "Jun", revenue: 5000, expenses: 3800 },
  { name: "Jul", revenue: 6000, expenses: 4300 },
  { name: "Aug", revenue: 8000, expenses: 5000 },
  { name: "Sep", revenue: 7000, expenses: 4500 },
  { name: "Oct", revenue: 9000, expenses: 5500 },
  { name: "Nov", revenue: 8000, expenses: 4900 },
  { name: "Dec", revenue: 10000, expenses: 6000 },
]

const clientData = [
  { name: "Active", value: 65 },
  { name: "Inactive", value: 10 },
  { name: "Pending", value: 25 },
]

const serviceData = [
  { name: "Web Hosting", value: 35 },
  { name: "Database", value: 25 },
  { name: "Email", value: 15 },
  { name: "CDN", value: 15 },
  { name: "Storage", value: 10 },
]

const COLORS = ["#00BFFF", "#2E8B57", "#FFD700", "#FF6347", "#9370DB"]

export default function AnalyticsPage() {
  const [date, setDate] = useState<Date | undefined>(new Date())
  const [period, setPeriod] = useState("yearly")

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-white">Analytics</h2>
          <p className="text-white/70">View detailed analytics and reports for your business.</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                className="border-white/10 text-white hover:bg-white/10 hover:text-fluxcloud-cyan"
              >
                <CalendarIcon className="mr-2 h-4 w-4" />
                {date ? format(date, "PPP") : "Pick a date"}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0 bg-fluxcloud-black border border-white/10">
              <Calendar
                mode="single"
                selected={date}
                onSelect={setDate}
                initialFocus
                className="bg-fluxcloud-black text-white"
              />
            </PopoverContent>
          </Popover>
          <Select value={period} onValueChange={setPeriod}>
            <SelectTrigger className="w-[180px] bg-white/10 border-white/10 text-white focus:ring-fluxcloud-cyan">
              <SelectValue placeholder="Select period" />
            </SelectTrigger>
            <SelectContent className="bg-fluxcloud-black border border-white/10">
              <SelectItem value="daily" className="text-white focus:bg-white/10 focus:text-fluxcloud-cyan">
                Daily
              </SelectItem>
              <SelectItem value="weekly" className="text-white focus:bg-white/10 focus:text-fluxcloud-cyan">
                Weekly
              </SelectItem>
              <SelectItem value="monthly" className="text-white focus:bg-white/10 focus:text-fluxcloud-cyan">
                Monthly
              </SelectItem>
              <SelectItem value="quarterly" className="text-white focus:bg-white/10 focus:text-fluxcloud-cyan">
                Quarterly
              </SelectItem>
              <SelectItem value="yearly" className="text-white focus:bg-white/10 focus:text-fluxcloud-cyan">
                Yearly
              </SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="bg-white/10">
          <TabsTrigger
            value="overview"
            className="data-[state=active]:bg-fluxcloud-cyan data-[state=active]:text-black"
          >
            Overview
          </TabsTrigger>
          <TabsTrigger value="revenue" className="data-[state=active]:bg-fluxcloud-cyan data-[state=active]:text-black">
            Revenue
          </TabsTrigger>
          <TabsTrigger value="clients" className="data-[state=active]:bg-fluxcloud-cyan data-[state=active]:text-black">
            Clients
          </TabsTrigger>
          <TabsTrigger
            value="services"
            className="data-[state=active]:bg-fluxcloud-cyan data-[state=active]:text-black"
          >
            Services
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <Card className="glass-card border-white/10 col-span-3">
              <CardHeader>
                <CardTitle className="text-white">Revenue vs Expenses</CardTitle>
                <CardDescription className="text-white/70">
                  Monthly revenue and expenses for the current year
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={400}>
                  <BarChart
                    data={revenueData}
                    margin={{
                      top: 20,
                      right: 30,
                      left: 20,
                      bottom: 5,
                    }}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255, 255, 255, 0.1)" />
                    <XAxis dataKey="name" stroke="#888888" />
                    <YAxis stroke="#888888" />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "rgba(0, 0, 0, 0.8)",
                        border: "1px solid rgba(255, 255, 255, 0.1)",
                        color: "white",
                      }}
                    />
                    <Legend />
                    <Bar dataKey="revenue" name="Revenue" fill="#00BFFF" />
                    <Bar dataKey="expenses" name="Expenses" fill="#2E8B57" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card className="glass-card border-white/10">
              <CardHeader>
                <CardTitle className="text-white">Client Status</CardTitle>
                <CardDescription className="text-white/70">Distribution of clients by status</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={clientData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    >
                      {clientData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "rgba(0, 0, 0, 0.8)",
                        border: "1px solid rgba(255, 255, 255, 0.1)",
                        color: "white",
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card className="glass-card border-white/10 md:col-span-2 lg:col-span-1">
              <CardHeader>
                <CardTitle className="text-white">Service Distribution</CardTitle>
                <CardDescription className="text-white/70">Distribution of services by type</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={serviceData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    >
                      {serviceData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "rgba(0, 0, 0, 0.8)",
                        border: "1px solid rgba(255, 255, 255, 0.1)",
                        color: "white",
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card className="glass-card border-white/10 col-span-3">
              <CardHeader>
                <CardTitle className="text-white">Revenue Trend</CardTitle>
                <CardDescription className="text-white/70">Monthly revenue trend for the current year</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={400}>
                  <LineChart
                    data={revenueData}
                    margin={{
                      top: 20,
                      right: 30,
                      left: 20,
                      bottom: 5,
                    }}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255, 255, 255, 0.1)" />
                    <XAxis dataKey="name" stroke="#888888" />
                    <YAxis stroke="#888888" />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "rgba(0, 0, 0, 0.8)",
                        border: "1px solid rgba(255, 255, 255, 0.1)",
                        color: "white",
                      }}
                    />
                    <Legend />
                    <Line type="monotone" dataKey="revenue" name="Revenue" stroke="#00BFFF" activeDot={{ r: 8 }} />
                    <Line type="monotone" dataKey="expenses" name="Expenses" stroke="#2E8B57" />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="revenue">
          <Card className="glass-card border-white/10">
            <CardHeader>
              <CardTitle className="text-white">Revenue Analysis</CardTitle>
              <CardDescription className="text-white/70">Detailed revenue analysis and projections</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[600px] flex items-center justify-center">
                <p className="text-white/50">Detailed revenue analysis will be displayed here</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="clients">
          <Card className="glass-card border-white/10">
            <CardHeader>
              <CardTitle className="text-white">Client Analytics</CardTitle>
              <CardDescription className="text-white/70">Client acquisition and retention metrics</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[600px] flex items-center justify-center">
                <p className="text-white/50">Client analytics will be displayed here</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="services">
          <Card className="glass-card border-white/10">
            <CardHeader>
              <CardTitle className="text-white">Service Analytics</CardTitle>
              <CardDescription className="text-white/70">Service usage and performance metrics</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[600px] flex items-center justify-center">
                <p className="text-white/50">Service analytics will be displayed here</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

