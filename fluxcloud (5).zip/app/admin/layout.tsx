import type React from "react"
import { cookies } from "next/headers"
import { AdminSidebar } from "@/components/admin/sidebar"
import { SidebarProvider, SidebarInset } from "@/components/ui/sidebar"
import { DashboardHeader } from "@/components/dashboard-header"

export default async function AdminLayout({
  children,
}: {
  children: React.ReactNode
}) {
  // Fix: Make cookies() awaitable
  const cookieStore = await cookies()
  const defaultOpen = cookieStore.get("sidebar:state")?.value === "true"

  return (
    <SidebarProvider defaultOpen={defaultOpen}>
      <div className="flex h-screen w-full bg-gradient-to-br from-fluxcloud-black to-gray-900">
        <AdminSidebar />
        <SidebarInset className="flex-1 w-full">
          <div className="flex h-full w-full flex-col">
            <DashboardHeader />
            <div className="flex-1 w-full overflow-auto">{children}</div>
          </div>
        </SidebarInset>
      </div>
    </SidebarProvider>
  )
}

