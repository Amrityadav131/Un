"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { AlertCircle, MessageSquare, User, Calendar, Clock } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Loader } from "@/components/loader"

export default function AdminSupportPage() {
  const [tickets, setTickets] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [currentTicket, setCurrentTicket] = useState(null)
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false)
  const [replyText, setReplyText] = useState("")
  const [activeTab, setActiveTab] = useState("open")
  const apiUrl = process.env.NEXT_PUBLIC_API_URL || "/api"

  useEffect(() => {
    const fetchTickets = async () => {
      try {
        const response = await fetch(`${apiUrl}/tickets`, {
          credentials: "include",
        })

        if (!response.ok) throw new Error("Failed to fetch tickets")
        const data = await response.json()
        setTickets(data)
        setLoading(false)
      } catch (err) {
        console.error("Error fetching tickets:", err)
        setError("Failed to load tickets. Please try again.")
        setLoading(false)
      }
    }

    fetchTickets()
  }, [apiUrl])

  const handleReplySubmit = async (e) => {
    e.preventDefault()
    if (!replyText.trim()) return

    setLoading(true)

    try {
      const response = await fetch(`${apiUrl}/tickets/${currentTicket.id}/reply`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify({
          message: replyText,
        }),
      })

      if (!response.ok) throw new Error("Failed to reply to ticket")

      // Refresh tickets
      const ticketsResponse = await fetch(`${apiUrl}/tickets`, {
        credentials: "include",
      })

      if (!ticketsResponse.ok) throw new Error("Failed to fetch tickets")
      const data = await ticketsResponse.json()
      setTickets(data)

      // Reset form and close dialog
      setReplyText("")
      setIsViewDialogOpen(false)
      setCurrentTicket(null)
      setLoading(false)
    } catch (err) {
      console.error("Error replying to ticket:", err)
      setError("Failed to reply to ticket. Please try again.")
      setLoading(false)
    }
  }

  const handleCloseTicket = async (id) => {
    setLoading(true)

    try {
      const response = await fetch(`${apiUrl}/tickets/${id}/close`, {
        method: "PUT",
        credentials: "include",
      })

      if (!response.ok) throw new Error("Failed to close ticket")

      // Refresh tickets
      const ticketsResponse = await fetch(`${apiUrl}/tickets`, {
        credentials: "include",
      })

      if (!ticketsResponse.ok) throw new Error("Failed to fetch tickets")
      const data = await ticketsResponse.json()
      setTickets(data)

      // Close dialog if open
      if (currentTicket && currentTicket.id === id) {
        setIsViewDialogOpen(false)
        setCurrentTicket(null)
      }

      setLoading(false)
    } catch (err) {
      console.error("Error closing ticket:", err)
      setError("Failed to close ticket. Please try again.")
      setLoading(false)
    }
  }

  const viewTicket = (ticket) => {
    setCurrentTicket(ticket)
    setIsViewDialogOpen(true)
  }

  const filteredTickets = tickets.filter((ticket) => {
    if (activeTab === "open") return ticket.status === "OPEN"
    if (activeTab === "closed") return ticket.status === "CLOSED"
    return true // All tickets
  })

  if (loading && tickets.length === 0) {
    return (
      <div className="flex items-center justify-center h-full w-full p-6">
        <Loader />
      </div>
    )
  }

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-white neon-text-cyan">Support Tickets</h1>
        <p className="text-white/70">Manage and respond to client support requests</p>
      </div>

      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <Tabs defaultValue="open" onValueChange={setActiveTab} className="w-full">
        <TabsList className="bg-fluxcloud-black/40 border border-white/10 p-1">
          <TabsTrigger
            value="open"
            className="data-[state=active]:bg-fluxcloud-cyan data-[state=active]:text-black rounded-md"
          >
            Open Tickets
          </TabsTrigger>
          <TabsTrigger
            value="closed"
            className="data-[state=active]:bg-fluxcloud-cyan data-[state=active]:text-black rounded-md"
          >
            Closed Tickets
          </TabsTrigger>
          <TabsTrigger
            value="all"
            className="data-[state=active]:bg-fluxcloud-cyan data-[state=active]:text-black rounded-md"
          >
            All Tickets
          </TabsTrigger>
        </TabsList>

        <TabsContent value={activeTab} className="mt-4">
          <Card className="glass-card border-white/10">
            <CardHeader>
              <CardTitle className="text-white">
                {activeTab === "open" ? "Open Tickets" : activeTab === "closed" ? "Closed Tickets" : "All Tickets"}
              </CardTitle>
              <CardDescription className="text-white/70">
                {activeTab === "open"
                  ? "Tickets awaiting response"
                  : activeTab === "closed"
                    ? "Resolved tickets"
                    : "All support tickets"}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {filteredTickets.length > 0 ? (
                <Table>
                  <TableHeader className="bg-white/5">
                    <TableRow className="border-white/10 hover:bg-white/5">
                      <TableHead className="text-white">ID</TableHead>
                      <TableHead className="text-white">Subject</TableHead>
                      <TableHead className="text-white">Client</TableHead>
                      <TableHead className="text-white">Status</TableHead>
                      <TableHead className="text-white">Created</TableHead>
                      <TableHead className="text-white">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredTickets.map((ticket) => (
                      <TableRow key={ticket.id} className="border-white/10 hover:bg-white/5">
                        <TableCell className="font-medium text-white">#{ticket.id}</TableCell>
                        <TableCell className="text-white">{ticket.subject}</TableCell>
                        <TableCell className="text-white">{ticket.userName || "Anonymous"}</TableCell>
                        <TableCell>
                          {ticket.status === "OPEN" ? (
                            <Badge className="bg-green-500 text-black">Open</Badge>
                          ) : (
                            <Badge className="bg-gray-500 text-black">Closed</Badge>
                          )}
                        </TableCell>
                        <TableCell className="text-white/70">
                          {new Date(ticket.createdAt || Date.now()).toLocaleDateString()}
                        </TableCell>
                        <TableCell>
                          <Button
                            variant="outline"
                            size="sm"
                            className="border-white/10 text-white hover:bg-white/10 hover:text-fluxcloud-cyan"
                            onClick={() => viewTicket(ticket)}
                          >
                            View
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="text-center py-6 text-white/70">
                  No {activeTab === "open" ? "open" : activeTab === "closed" ? "closed" : ""} tickets found.
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="glass-card border-white/10 max-w-3xl">
          {currentTicket && (
            <>
              <DialogHeader>
                <DialogTitle className="text-white">
                  Ticket #{currentTicket.id}: {currentTicket.subject}
                </DialogTitle>
                <DialogDescription className="text-white/70 flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <span className="flex items-center">
                      <User className="h-4 w-4 mr-1" />
                      {currentTicket.userName || "Anonymous"}
                    </span>
                    <span className="flex items-center">
                      <Calendar className="h-4 w-4 mr-1" />
                      {new Date(currentTicket.createdAt || Date.now()).toLocaleDateString()}
                    </span>
                  </div>
                  <Badge
                    className={currentTicket.status === "OPEN" ? "bg-green-500 text-black" : "bg-gray-500 text-black"}
                  >
                    {currentTicket.status}
                  </Badge>
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="bg-white/5 p-4 rounded-md">
                  <div className="text-white/70 text-sm mb-2">Original Message:</div>
                  <div className="text-white whitespace-pre-wrap">{currentTicket.message}</div>
                </div>

                {currentTicket.replies && currentTicket.replies.length > 0 && (
                  <div className="space-y-3">
                    <div className="text-white/70 text-sm">Replies:</div>
                    {currentTicket.replies.map((reply, index) => (
                      <div key={index} className="bg-white/5 p-4 rounded-md">
                        <div className="flex justify-between text-white/70 text-sm mb-2">
                          <span className="flex items-center">
                            <User className="h-4 w-4 mr-1" />
                            {reply.userName || "Staff"}
                          </span>
                          <span className="flex items-center">
                            <Clock className="h-4 w-4 mr-1" />
                            {new Date(reply.createdAt || Date.now()).toLocaleString()}
                          </span>
                        </div>
                        <div className="text-white whitespace-pre-wrap">{reply.message}</div>
                      </div>
                    ))}
                  </div>
                )}

                {currentTicket.status === "OPEN" && (
                  <form onSubmit={handleReplySubmit}>
                    <div className="space-y-2">
                      <div className="flex items-center">
                        <MessageSquare className="h-4 w-4 mr-2 text-fluxcloud-cyan" />
                        <span className="text-white">Reply to this ticket</span>
                      </div>
                      <Textarea
                        value={replyText}
                        onChange={(e) => setReplyText(e.target.value)}
                        placeholder="Type your response here..."
                        className="bg-white/5 border-white/10 text-white min-h-[100px]"
                        required
                      />
                    </div>
                    <div className="flex justify-between mt-4">
                      <Button
                        type="button"
                        variant="outline"
                        className="border-white/10 text-white hover:bg-white/10 hover:text-red-500"
                        onClick={() => handleCloseTicket(currentTicket.id)}
                      >
                        Close Ticket
                      </Button>
                      <Button
                        type="submit"
                        className="bg-fluxcloud-cyan hover:bg-fluxcloud-cyan/80 text-black"
                        disabled={loading || !replyText.trim()}
                      >
                        {loading ? "Sending..." : "Send Reply"}
                      </Button>
                    </div>
                  </form>
                )}
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

