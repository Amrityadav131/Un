"use client"

import { useState } from "react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { Loader2 } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { useToast } from "@/components/ui/use-toast"

const generalFormSchema = z.object({
  companyName: z.string().min(2, {
    message: "Company name must be at least 2 characters.",
  }),
  companyEmail: z.string().email({
    message: "Please enter a valid email address.",
  }),
  companyPhone: z.string().min(5, {
    message: "Phone number must be at least 5 characters.",
  }),
  companyAddress: z.string().min(5, {
    message: "Address must be at least 5 characters.",
  }),
})

const emailFormSchema = z.object({
  smtpServer: z.string().min(2, {
    message: "SMTP server must be at least 2 characters.",
  }),
  smtpPort: z.string().min(1, {
    message: "SMTP port is required.",
  }),
  smtpUsername: z.string().min(2, {
    message: "SMTP username must be at least 2 characters.",
  }),
  smtpPassword: z.string().min(2, {
    message: "SMTP password must be at least 2 characters.",
  }),
  emailFrom: z.string().email({
    message: "Please enter a valid email address.",
  }),
})

const integrationFormSchema = z.object({
  discordWebhook: z
    .string()
    .url({
      message: "Please enter a valid URL.",
    })
    .optional()
    .or(z.literal("")),
  enableDiscord: z.boolean().default(false),
  slackWebhook: z
    .string()
    .url({
      message: "Please enter a valid URL.",
    })
    .optional()
    .or(z.literal("")),
  enableSlack: z.boolean().default(false),
})

export default function SettingsPage() {
  const { toast } = useToast()
  const [isGeneralLoading, setIsGeneralLoading] = useState(false)
  const [isEmailLoading, setIsEmailLoading] = useState(false)
  const [isIntegrationLoading, setIsIntegrationLoading] = useState(false)

  const generalForm = useForm<z.infer<typeof generalFormSchema>>({
    resolver: zodResolver(generalFormSchema),
    defaultValues: {
      companyName: "FluxCloud Inc.",
      companyEmail: "info@fluxcloud.com",
      companyPhone: "+1 (555) 123-4567",
      companyAddress: "123 Cloud Street, Tech City, TC 12345",
    },
  })

  const emailForm = useForm<z.infer<typeof emailFormSchema>>({
    resolver: zodResolver(emailFormSchema),
    defaultValues: {
      smtpServer: "smtp.fluxcloud.com",
      smtpPort: "587",
      smtpUsername: "notifications@fluxcloud.com",
      smtpPassword: "••••••••••••",
      emailFrom: "notifications@fluxcloud.com",
    },
  })

  const integrationForm = useForm<z.infer<typeof integrationFormSchema>>({
    resolver: zodResolver(integrationFormSchema),
    defaultValues: {
      discordWebhook: process.env.DISCORD_WEBHOOK_URL || "",
      enableDiscord: true,
      slackWebhook: "",
      enableSlack: false,
    },
  })

  async function onGeneralSubmit(values: z.infer<typeof generalFormSchema>) {
    setIsGeneralLoading(true)
    try {
      // In a real app, this would call an API endpoint
      await new Promise((resolve) => setTimeout(resolve, 1000))
      toast({
        title: "Settings updated",
        description: "Your company settings have been updated successfully.",
      })
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to update settings. Please try again.",
      })
    } finally {
      setIsGeneralLoading(false)
    }
  }

  async function onEmailSubmit(values: z.infer<typeof emailFormSchema>) {
    setIsEmailLoading(true)
    try {
      // In a real app, this would call an API endpoint
      await new Promise((resolve) => setTimeout(resolve, 1000))
      toast({
        title: "Email settings updated",
        description: "Your email settings have been updated successfully.",
      })
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to update email settings. Please try again.",
      })
    } finally {
      setIsEmailLoading(false)
    }
  }

  async function onIntegrationSubmit(values: z.infer<typeof integrationFormSchema>) {
    setIsIntegrationLoading(true)
    try {
      // In a real app, this would call an API endpoint
      await new Promise((resolve) => setTimeout(resolve, 1000))
      toast({
        title: "Integration settings updated",
        description: "Your integration settings have been updated successfully.",
      })
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to update integration settings. Please try again.",
      })
    } finally {
      setIsIntegrationLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight text-white">Settings</h2>
        <p className="text-white/70">Manage your application settings and preferences.</p>
      </div>

      <Tabs defaultValue="general" className="space-y-4">
        <TabsList className="bg-white/10">
          <TabsTrigger value="general" className="data-[state=active]:bg-fluxcloud-cyan data-[state=active]:text-black">
            General
          </TabsTrigger>
          <TabsTrigger value="email" className="data-[state=active]:bg-fluxcloud-cyan data-[state=active]:text-black">
            Email
          </TabsTrigger>
          <TabsTrigger
            value="integrations"
            className="data-[state=active]:bg-fluxcloud-cyan data-[state=active]:text-black"
          >
            Integrations
          </TabsTrigger>
          <TabsTrigger value="backup" className="data-[state=active]:bg-fluxcloud-cyan data-[state=active]:text-black">
            Backup
          </TabsTrigger>
        </TabsList>

        <TabsContent value="general">
          <Card className="glass-card border-white/10">
            <CardHeader>
              <CardTitle className="text-white">General Settings</CardTitle>
              <CardDescription className="text-white/70">
                Manage your company information and general settings.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...generalForm}>
                <form onSubmit={generalForm.handleSubmit(onGeneralSubmit)} className="space-y-4">
                  <FormField
                    control={generalForm.control}
                    name="companyName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white">Company Name</FormLabel>
                        <FormControl>
                          <Input
                            {...field}
                            className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus-visible:ring-fluxcloud-cyan"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={generalForm.control}
                    name="companyEmail"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white">Company Email</FormLabel>
                        <FormControl>
                          <Input
                            {...field}
                            className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus-visible:ring-fluxcloud-cyan"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={generalForm.control}
                    name="companyPhone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white">Company Phone</FormLabel>
                        <FormControl>
                          <Input
                            {...field}
                            className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus-visible:ring-fluxcloud-cyan"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={generalForm.control}
                    name="companyAddress"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white">Company Address</FormLabel>
                        <FormControl>
                          <Textarea
                            {...field}
                            className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus-visible:ring-fluxcloud-cyan"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <Button
                    type="submit"
                    className="bg-fluxcloud-cyan text-black hover:bg-fluxcloud-cyan/80"
                    disabled={isGeneralLoading}
                  >
                    {isGeneralLoading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Saving...
                      </>
                    ) : (
                      "Save Changes"
                    )}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="email">
          <Card className="glass-card border-white/10">
            <CardHeader>
              <CardTitle className="text-white">Email Settings</CardTitle>
              <CardDescription className="text-white/70">
                Configure your email server settings for notifications.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...emailForm}>
                <form onSubmit={emailForm.handleSubmit(onEmailSubmit)} className="space-y-4">
                  <FormField
                    control={emailForm.control}
                    name="smtpServer"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white">SMTP Server</FormLabel>
                        <FormControl>
                          <Input
                            {...field}
                            className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus-visible:ring-fluxcloud-cyan"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={emailForm.control}
                    name="smtpPort"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white">SMTP Port</FormLabel>
                        <FormControl>
                          <Input
                            {...field}
                            className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus-visible:ring-fluxcloud-cyan"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={emailForm.control}
                    name="smtpUsername"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white">SMTP Username</FormLabel>
                        <FormControl>
                          <Input
                            {...field}
                            className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus-visible:ring-fluxcloud-cyan"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={emailForm.control}
                    name="smtpPassword"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white">SMTP Password</FormLabel>
                        <FormControl>
                          <Input
                            type="password"
                            {...field}
                            className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus-visible:ring-fluxcloud-cyan"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={emailForm.control}
                    name="emailFrom"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white">From Email</FormLabel>
                        <FormControl>
                          <Input
                            {...field}
                            className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus-visible:ring-fluxcloud-cyan"
                          />
                        </FormControl>
                        <FormDescription className="text-white/50">
                          This email will be used as the sender for all outgoing emails.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <Button
                    type="submit"
                    className="bg-fluxcloud-cyan text-black hover:bg-fluxcloud-cyan/80"
                    disabled={isEmailLoading}
                  >
                    {isEmailLoading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Saving...
                      </>
                    ) : (
                      "Save Changes"
                    )}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="integrations">
          <Card className="glass-card border-white/10">
            <CardHeader>
              <CardTitle className="text-white">Integration Settings</CardTitle>
              <CardDescription className="text-white/70">
                Configure third-party integrations for notifications and alerts.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...integrationForm}>
                <form onSubmit={integrationForm.handleSubmit(onIntegrationSubmit)} className="space-y-4">
                  <div className="space-y-4">
                    <div className="flex flex-col space-y-2">
                      <h3 className="text-lg font-medium text-white">Discord Integration</h3>
                      <p className="text-sm text-white/70">
                        Configure Discord webhook for sending notifications and alerts.
                      </p>
                    </div>

                    <FormField
                      control={integrationForm.control}
                      name="enableDiscord"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border border-white/10 p-4">
                          <div className="space-y-0.5">
                            <FormLabel className="text-white">Enable Discord Integration</FormLabel>
                            <FormDescription className="text-white/50">
                              Receive notifications and alerts via Discord.
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                              className="data-[state=checked]:bg-fluxcloud-cyan"
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={integrationForm.control}
                      name="discordWebhook"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-white">Discord Webhook URL</FormLabel>
                          <FormControl>
                            <Input
                              {...field}
                              className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus-visible:ring-fluxcloud-cyan"
                            />
                          </FormControl>
                          <FormDescription className="text-white/50">
                            Enter the Discord webhook URL to send notifications to.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="space-y-4 pt-4 border-t border-white/10">
                    <div className="flex flex-col space-y-2">
                      <h3 className="text-lg font-medium text-white">Slack Integration</h3>
                      <p className="text-sm text-white/70">
                        Configure Slack webhook for sending notifications and alerts.
                      </p>
                    </div>

                    <FormField
                      control={integrationForm.control}
                      name="enableSlack"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border border-white/10 p-4">
                          <div className="space-y-0.5">
                            <FormLabel className="text-white">Enable Slack Integration</FormLabel>
                            <FormDescription className="text-white/50">
                              Receive notifications and alerts via Slack.
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                              className="data-[state=checked]:bg-fluxcloud-cyan"
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={integrationForm.control}
                      name="slackWebhook"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-white">Slack Webhook URL</FormLabel>
                          <FormControl>
                            <Input
                              {...field}
                              className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus-visible:ring-fluxcloud-cyan"
                            />
                          </FormControl>
                          <FormDescription className="text-white/50">
                            Enter the Slack webhook URL to send notifications to.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <Button
                    type="submit"
                    className="bg-fluxcloud-cyan text-black hover:bg-fluxcloud-cyan/80"
                    disabled={isIntegrationLoading}
                  >
                    {isIntegrationLoading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Saving...
                      </>
                    ) : (
                      "Save Changes"
                    )}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="backup">
          <Card className="glass-card border-white/10">
            <CardHeader>
              <CardTitle className="text-white">Backup & Restore</CardTitle>
              <CardDescription className="text-white/70">Manage database backups and restore points.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="rounded-lg border border-white/10 p-4">
                <div className="flex flex-col space-y-2">
                  <h3 className="text-lg font-medium text-white">Automatic Backups</h3>
                  <p className="text-sm text-white/70">Configure automatic database backups.</p>
                  <div className="flex items-center space-x-2 mt-2">
                    <Switch id="auto-backup" className="data-[state=checked]:bg-fluxcloud-cyan" />
                    <label htmlFor="auto-backup" className="text-sm text-white cursor-pointer">
                      Enable automatic backups
                    </label>
                  </div>
                </div>
                <div className="mt-4 grid gap-4 sm:grid-cols-2">
                  <div>
                    <label className="text-sm font-medium text-white">Backup Frequency</label>
                    <select className="mt-1 w-full rounded-md bg-white/10 border-white/20 text-white focus:ring-fluxcloud-cyan">
                      <option>Daily</option>
                      <option>Weekly</option>
                      <option>Monthly</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-white">Retention Period</label>
                    <select className="mt-1 w-full rounded-md bg-white/10 border-white/20 text-white focus:ring-fluxcloud-cyan">
                      <option>7 days</option>
                      <option>30 days</option>
                      <option>90 days</option>
                      <option>1 year</option>
                    </select>
                  </div>
                </div>
              </div>

              <div className="rounded-lg border border-white/10 p-4">
                <div className="flex flex-col space-y-2">
                  <h3 className="text-lg font-medium text-white">Manual Backup</h3>
                  <p className="text-sm text-white/70">Create a manual backup of your database.</p>
                </div>
                <div className="mt-4">
                  <Button className="bg-fluxcloud-cyan text-black hover:bg-fluxcloud-cyan/80">Create Backup</Button>
                </div>
              </div>

              <div className="rounded-lg border border-white/10 p-4">
                <div className="flex flex-col space-y-2">
                  <h3 className="text-lg font-medium text-white">Restore Database</h3>
                  <p className="text-sm text-white/70">Restore your database from a previous backup.</p>
                </div>
                <div className="mt-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-white">Select Backup</label>
                    <select className="w-full rounded-md bg-white/10 border-white/20 text-white focus:ring-fluxcloud-cyan">
                      <option>Backup - 2023-04-15 (10:30 AM)</option>
                      <option>Backup - 2023-04-14 (10:30 AM)</option>
                      <option>Backup - 2023-04-13 (10:30 AM)</option>
                    </select>
                  </div>
                  <div className="mt-4">
                    <Button
                      variant="outline"
                      className="border-white/10 text-white hover:bg-white/10 hover:text-fluxcloud-cyan"
                    >
                      Restore Database
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

