"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { AlertCircle, Plus, Edit, Trash2, User, Mail, Building, FileText } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { useRouter } from "next/navigation"
import { Loader } from "@/components/loader"

export default function AdminUsersPage() {
  const router = useRouter()
  const [users, setUsers] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false)
  const [currentUser, setCurrentUser] = useState(null)
  const apiUrl = process.env.NEXT_PUBLIC_API_URL || "/api"

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await fetch(`${apiUrl}/admin/users`, {
          credentials: "include",
        })

        if (!response.ok) throw new Error("Failed to fetch users")
        const data = await response.json()
        setUsers(data)
        setLoading(false)
      } catch (err) {
        console.error("Error fetching users:", err)
        setError("Failed to load users. Please try again.")
        setLoading(false)
      }
    }

    fetchUsers()
  }, [apiUrl])

  const handleDeleteUser = async (id) => {
    if (!confirm("Are you sure you want to delete this user? This action cannot be undone.")) return

    setLoading(true)

    try {
      const response = await fetch(`${apiUrl}/admin/users/${id}`, {
        method: "DELETE",
        credentials: "include",
      })

      if (!response.ok) throw new Error("Failed to delete user")

      // Refresh users
      const usersResponse = await fetch(`${apiUrl}/admin/users`, {
        credentials: "include",
      })

      if (!usersResponse.ok) throw new Error("Failed to fetch users")
      const data = await usersResponse.json()
      setUsers(data)
      setLoading(false)
    } catch (err) {
      console.error("Error deleting user:", err)
      setError("Failed to delete user. Please try again.")
      setLoading(false)
    }
  }

  const viewUser = (user) => {
    setCurrentUser(user)
    setIsViewDialogOpen(true)
  }

  if (loading && users.length === 0) {
    return (
      <div className="flex items-center justify-center h-full w-full p-6">
        <Loader />
      </div>
    )
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-white neon-text-cyan">Client Management</h1>
          <p className="text-white/70">Manage your client accounts</p>
        </div>
        <Button
          className="bg-fluxcloud-cyan hover:bg-fluxcloud-cyan/80 text-black"
          onClick={() => router.push("/admin/users/create")}
        >
          <Plus className="mr-2 h-4 w-4" /> Add Client
        </Button>
      </div>

      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <Card className="glass-card border-white/10">
        <CardHeader>
          <CardTitle className="text-white">Clients</CardTitle>
          <CardDescription className="text-white/70">All registered clients on your platform</CardDescription>
        </CardHeader>
        <CardContent>
          {users.length > 0 ? (
            <Table>
              <TableHeader className="bg-white/5">
                <TableRow className="border-white/10 hover:bg-white/5">
                  <TableHead className="text-white">Name</TableHead>
                  <TableHead className="text-white">Email</TableHead>
                  <TableHead className="text-white">Company</TableHead>
                  <TableHead className="text-white">Status</TableHead>
                  <TableHead className="text-white">Joined</TableHead>
                  <TableHead className="text-white">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {users
                  .filter((user) => user.role === "CLIENT")
                  .map((user) => (
                    <TableRow key={user.id} className="border-white/10 hover:bg-white/5">
                      <TableCell className="font-medium text-white">{user.name}</TableCell>
                      <TableCell className="text-white">{user.email}</TableCell>
                      <TableCell className="text-white">{user.company || "N/A"}</TableCell>
                      <TableCell>
                        {user.status === "ACTIVE" ? (
                          <Badge className="bg-green-500 text-black">Active</Badge>
                        ) : (
                          <Badge className="bg-gray-500 text-black">Inactive</Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-white/70">
                        {new Date(user.createdAt || Date.now()).toLocaleDateString()}
                      </TableCell>
                      <TableCell className="flex space-x-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="text-white hover:bg-white/10 hover:text-fluxcloud-cyan"
                          onClick={() => viewUser(user)}
                        >
                          <FileText className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="text-white hover:bg-white/10 hover:text-fluxcloud-cyan"
                          onClick={() => router.push(`/admin/users/edit/${user.id}`)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="text-white hover:bg-white/10 hover:text-red-500"
                          onClick={() => handleDeleteUser(user.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
              </TableBody>
            </Table>
          ) : (
            <div className="text-center py-6 text-white/70">
              No clients found. Add your first client to get started.
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="glass-card border-white/10 max-w-md">
          {currentUser && (
            <>
              <DialogHeader>
                <DialogTitle className="text-white">Client Details</DialogTitle>
                <DialogDescription className="text-white/70">Detailed information about this client</DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="flex items-center space-x-3">
                  <User className="h-5 w-5 text-fluxcloud-cyan" />
                  <div>
                    <p className="text-sm text-white/70">Full Name</p>
                    <p className="text-white font-medium">{currentUser.name}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <Mail className="h-5 w-5 text-fluxcloud-cyan" />
                  <div>
                    <p className="text-sm text-white/70">Email Address</p>
                    <p className="text-white font-medium">{currentUser.email}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <Building className="h-5 w-5 text-fluxcloud-cyan" />
                  <div>
                    <p className="text-sm text-white/70">Company</p>
                    <p className="text-white font-medium">{currentUser.company || "N/A"}</p>
                  </div>
                </div>
                <div className="bg-white/5 p-3 rounded-md">
                  <p className="text-sm text-white/70 mb-1">Status</p>
                  <Badge
                    className={currentUser.status === "ACTIVE" ? "bg-green-500 text-black" : "bg-gray-500 text-black"}
                  >
                    {currentUser.status}
                  </Badge>
                </div>
                {currentUser.description && (
                  <div className="bg-white/5 p-3 rounded-md">
                    <p className="text-sm text-white/70 mb-1">Description</p>
                    <p className="text-white">{currentUser.description}</p>
                  </div>
                )}
                <div className="bg-white/5 p-3 rounded-md">
                  <p className="text-sm text-white/70 mb-1">Joined</p>
                  <p className="text-white">{new Date(currentUser.createdAt || Date.now()).toLocaleString()}</p>
                </div>
              </div>
              <DialogFooter>
                <Button
                  variant="outline"
                  className="border-white/10 text-white hover:bg-white/10"
                  onClick={() => setIsViewDialogOpen(false)}
                >
                  Close
                </Button>
                <Button
                  className="bg-fluxcloud-cyan hover:bg-fluxcloud-cyan/80 text-black"
                  onClick={() => router.push(`/admin/users/edit/${currentUser.id}`)}
                >
                  Edit Client
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

