"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { AlertCircle, ArrowLeft } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { useRouter } from "next/navigation"
import { Loader } from "@/components/loader"

export default function CreateClientPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [success, setSuccess] = useState(false)
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    company: "",
    description: "",
  })
  const apiUrl = process.env.NEXT_PUBLIC_API_URL || "/api"

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setFormData({
      ...formData,
      [name]: value,
    })
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    try {
      const response = await fetch(`${apiUrl}/admin/users`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify({
          name: formData.name,
          email: formData.email,
          password: formData.password,
          company: formData.company,
          description: formData.description,
          role: "CLIENT",
          status: "ACTIVE",
        }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.message || "Failed to create client")
      }

      setSuccess(true)
      setFormData({
        name: "",
        email: "",
        password: "",
        company: "",
        description: "",
      })

      // Redirect after a short delay
      setTimeout(() => {
        router.push("/admin/users")
      }, 2000)
    } catch (err) {
      console.error("Error creating client:", err)
      setError(err.message || "Failed to create client. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center">
        <Button
          variant="ghost"
          className="mr-4 text-white hover:bg-white/10"
          onClick={() => router.push("/admin/users")}
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back
        </Button>
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-white neon-text-cyan">Create New Client</h1>
          <p className="text-white/70">Add a new client to your platform</p>
        </div>
      </div>

      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {success && (
        <Alert className="bg-green-500/20 text-green-500 border-green-500/50">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Success</AlertTitle>
          <AlertDescription>Client created successfully! Redirecting...</AlertDescription>
        </Alert>
      )}

      <Card className="glass-card border-white/10 max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle className="text-white">Client Information</CardTitle>
          <CardDescription className="text-white/70">Enter the details for the new client account</CardDescription>
        </CardHeader>
        <form onSubmit={handleSubmit}>
          <CardContent className="space-y-4">
            <div className="grid gap-2">
              <Label htmlFor="name" className="text-white">
                Full Name
              </Label>
              <Input
                id="name"
                name="name"
                value={formData.name}
                onChange={handleInputChange}
                className="bg-white/5 border-white/10 text-white"
                required
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="email" className="text-white">
                Email Address
              </Label>
              <Input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleInputChange}
                className="bg-white/5 border-white/10 text-white"
                required
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="password" className="text-white">
                Password
              </Label>
              <Input
                id="password"
                name="password"
                type="password"
                value={formData.password}
                onChange={handleInputChange}
                className="bg-white/5 border-white/10 text-white"
                required
              />
              <p className="text-xs text-white/50">Password must be at least 8 characters long</p>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="company" className="text-white">
                Company Name
              </Label>
              <Input
                id="company"
                name="company"
                value={formData.company}
                onChange={handleInputChange}
                className="bg-white/5 border-white/10 text-white"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="description" className="text-white">
                Description (Optional)
              </Label>
              <Textarea
                id="description"
                name="description"
                value={formData.description}
                onChange={handleInputChange}
                className="bg-white/5 border-white/10 text-white"
                placeholder="Additional notes about this client..."
              />
            </div>
          </CardContent>
          <CardFooter>
            <Button
              type="submit"
              className="w-full bg-fluxcloud-cyan hover:bg-fluxcloud-cyan/80 text-black"
              disabled={loading}
            >
              {loading ? <Loader size="sm" /> : "Create Client"}
            </Button>
          </CardFooter>
        </form>
      </Card>
    </div>
  )
}

