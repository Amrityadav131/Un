/**
 * Health Check API Route
 * Software made by nikhil & arpit | AuraNodes 2025
 */

import { NextResponse } from "next/server"
import { testDatabaseConnection } from "@/lib/db-connect"

export async function GET() {
  const dbConnected = await testDatabaseConnection()

  return NextResponse.json({
    status: "ok",
    timestamp: new Date().toISOString(),
    database: dbConnected ? "connected" : "disconnected",
    environment: process.env.NODE_ENV,
    version: "1.0.0",
    copyright: "nikhil & arpit | AuraNodes 2025",
  })
}

