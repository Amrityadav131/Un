import { NextResponse } from "next/server"

export async function POST(request: Request, { params }: { params: { id: string } }) {
  try {
    const body = await request.json()

    // In a real application, you would save this reply to a database
    // For now, we'll just return a success message
    return NextResponse.json(
      {
        id: Math.random().toString(36).substring(2, 9),
        ticketId: params.id,
        ...body,
        createdAt: new Date().toISOString(),
      },
      { status: 201 },
    )
  } catch (error) {
    return NextResponse.json({ error: "Failed to reply to ticket" }, { status: 500 })
  }
}

