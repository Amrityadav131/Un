import { type NextRequest, NextResponse } from "next/server"
import { getInvoiceById, updateInvoice } from "@/lib/db/invoices"
import { sendDiscordWebhook } from "@/lib/webhook"

export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const invoice = await getInvoiceById(params.id)

    if (!invoice) {
      return NextResponse.json({ error: "Invoice not found" }, { status: 404 })
    }

    // Determine webhook type based on invoice status
    let webhookType: "new" | "paid" | "overdue" = "new"
    if (invoice.status === "paid") {
      webhookType = "paid"
    } else if (invoice.status === "overdue") {
      webhookType = "overdue"
    }

    // Send the webhook
    const webhookSent = await sendDiscordWebhook(invoice, webhookType)

    if (!webhookSent) {
      return NextResponse.json({ error: "Failed to send webhook" }, { status: 500 })
    }

    // Update the invoice with webhook status
    await updateInvoice(invoice.id, { webhookSent: true })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error sending webhook:", error)
    return NextResponse.json({ error: "Failed to send webhook" }, { status: 500 })
  }
}

