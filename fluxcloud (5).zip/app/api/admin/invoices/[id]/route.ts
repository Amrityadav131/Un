import { type NextRequest, NextResponse } from "next/server"
import { getInvoiceById, updateInvoice, deleteInvoice } from "@/lib/db/invoices"
import { sendDiscordWebhook } from "@/lib/webhook"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const invoice = await getInvoiceById(params.id)

    if (!invoice) {
      return NextResponse.json({ error: "Invoice not found" }, { status: 404 })
    }

    return NextResponse.json(invoice)
  } catch (error) {
    console.error("Error fetching invoice:", error)
    return NextResponse.json({ error: "Failed to fetch invoice" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const data = await request.json()
    const currentInvoice = await getInvoiceById(params.id)

    if (!currentInvoice) {
      return NextResponse.json({ error: "Invoice not found" }, { status: 404 })
    }

    // Check if status is changing to paid or overdue
    const statusChanged = data.status && data.status !== currentInvoice.status
    const sendWebhookNotification = data.sendWebhook || false

    // Update the invoice
    const updatedInvoice = await updateInvoice(params.id, data)

    if (!updatedInvoice) {
      return NextResponse.json({ error: "Failed to update invoice" }, { status: 500 })
    }

    // Send webhook notification if requested or if status changed to paid or overdue
    if (sendWebhookNotification || (statusChanged && (data.status === "paid" || data.status === "overdue"))) {
      const webhookType = data.status === "paid" ? "paid" : data.status === "overdue" ? "overdue" : "new"
      const webhookSent = await sendDiscordWebhook(updatedInvoice, webhookType)

      // Update the invoice with webhook status
      if (webhookSent) {
        await updateInvoice(updatedInvoice.id, { webhookSent: true })
      }
    }

    return NextResponse.json(updatedInvoice)
  } catch (error) {
    console.error("Error updating invoice:", error)
    return NextResponse.json({ error: "Failed to update invoice" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const success = await deleteInvoice(params.id)

    if (!success) {
      return NextResponse.json({ error: "Invoice not found" }, { status: 404 })
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error deleting invoice:", error)
    return NextResponse.json({ error: "Failed to delete invoice" }, { status: 500 })
  }
}

