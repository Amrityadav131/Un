import { NextResponse } from "next/server"

export async function GET() {
  // In a real application, you would fetch users from a database
  // For now, we'll return an empty array
  return NextResponse.json([])
}

export async function POST(request: Request) {
  try {
    const body = await request.json()

    // In a real application, you would save this to a database and hash the password
    // For now, we'll just return the data with a fake ID (excluding the password)
    const { password, ...userData } = body

    return NextResponse.json(
      {
        id: Math.random().toString(36).substring(2, 9),
        ...userData,
        createdAt: new Date().toISOString(),
      },
      { status: 201 },
    )
  } catch (error) {
    return NextResponse.json({ error: "Failed to create user" }, { status: 500 })
  }
}

