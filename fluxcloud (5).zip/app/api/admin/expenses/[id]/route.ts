import { NextResponse } from "next/server"

// Reference to the in-memory storage from the main route
// In a real app, this would be a database
import { expenses } from "../route"

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const expense = expenses.find((e) => e.id === params.id)

    if (!expense) {
      return NextResponse.json({ error: "Expense not found" }, { status: 404 })
    }

    return NextResponse.json(expense)
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch expense" }, { status: 500 })
  }
}

export async function PUT(request: Request, { params }: { params: { id: string } }) {
  try {
    const body = await request.json()
    const expenseIndex = expenses.findIndex((e) => e.id === params.id)

    if (expenseIndex === -1) {
      return NextResponse.json({ error: "Expense not found" }, { status: 404 })
    }

    // Update expense
    expenses[expenseIndex] = {
      ...expenses[expenseIndex],
      description: body.description || expenses[expenseIndex].description,
      amount: body.amount !== undefined ? Number.parseFloat(body.amount) : expenses[expenseIndex].amount,
      category: body.category || expenses[expenseIndex].category,
      date: body.date || expenses[expenseIndex].date,
      updatedAt: new Date().toISOString(),
    }

    return NextResponse.json(expenses[expenseIndex])
  } catch (error) {
    return NextResponse.json({ error: "Failed to update expense" }, { status: 500 })
  }
}

export async function DELETE(request: Request, { params }: { params: { id: string } }) {
  try {
    const expenseIndex = expenses.findIndex((e) => e.id === params.id)

    if (expenseIndex === -1) {
      return NextResponse.json({ error: "Expense not found" }, { status: 404 })
    }

    // Remove expense
    const deletedExpense = expenses[expenseIndex]
    expenses.splice(expenseIndex, 1)

    return NextResponse.json(deletedExpense)
  } catch (error) {
    return NextResponse.json({ error: "Failed to delete expense" }, { status: 500 })
  }
}

