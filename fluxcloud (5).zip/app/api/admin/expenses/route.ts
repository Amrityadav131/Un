import { NextResponse } from "next/server"

// In-memory storage for expenses (replace with database in production)
const expenses = []

export async function GET() {
  try {
    return NextResponse.json(expenses)
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch expenses" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()

    // Validate required fields
    if (!body.description || !body.amount || !body.category || !body.date) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Create new expense
    const newExpense = {
      id: Math.random().toString(36).substring(2, 9),
      description: body.description,
      amount: Number.parseFloat(body.amount),
      category: body.category,
      date: body.date,
      createdAt: new Date().toISOString(),
    }

    expenses.push(newExpense)

    return NextResponse.json(newExpense, { status: 201 })
  } catch (error) {
    return NextResponse.json({ error: "Failed to create expense" }, { status: 500 })
  }
}

