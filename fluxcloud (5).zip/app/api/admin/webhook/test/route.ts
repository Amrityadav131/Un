import { type NextRequest, NextResponse } from "next/server"
import { sendDiscordWebhook } from "@/lib/webhook"

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()

    // Create a test invoice object
    const testInvoice = {
      id: "test-invoice-id",
      clientId: null,
      email: data.email || "test@example.com",
      discordId: data.discordId,
      description: data.description || "Test invoice description",
      amount: data.amount || 100,
      status: "pending",
      dueDate: new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }

    // Send the webhook
    const webhookSent = await sendDiscordWebhook(testInvoice, "new")

    if (!webhookSent) {
      return NextResponse.json({ error: "Failed to send webhook" }, { status: 500 })
    }

    return NextResponse.json({ success: true, message: "Test webhook sent successfully" })
  } catch (error) {
    console.error("Error sending test webhook:", error)
    return NextResponse.json({ error: "Failed to send test webhook" }, { status: 500 })
  }
}

