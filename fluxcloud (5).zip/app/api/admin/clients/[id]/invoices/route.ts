import { NextResponse } from "next/server"

// This would be replaced with your actual database
const invoices = [
  // No sample data - will be populated from database
]

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const { id } = params

    // In a real application, you would fetch from your database
    // For example: const clientInvoices = await prisma.invoice.findMany({ where: { clientId: id } });

    const clientInvoices = invoices.filter((invoice) => invoice.clientId === id)

    return NextResponse.json({ invoices: clientInvoices }, { status: 200 })
  } catch (error) {
    console.error("Error fetching client invoices:", error)
    return NextResponse.json({ message: "Failed to fetch client invoices" }, { status: 500 })
  }
}

