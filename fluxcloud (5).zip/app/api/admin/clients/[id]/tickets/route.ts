import { NextResponse } from "next/server"

// This would be replaced with your actual database
const tickets = [
  // No sample data - will be populated from database
]

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const { id } = params

    // In a real application, you would fetch from your database
    // For example: const clientTickets = await prisma.ticket.findMany({ where: { clientId: id } });

    const clientTickets = tickets.filter((ticket) => ticket.clientId === id)

    return NextResponse.json({ tickets: clientTickets }, { status: 200 })
  } catch (error) {
    console.error("Error fetching client tickets:", error)
    return NextResponse.json({ message: "Failed to fetch client tickets" }, { status: 500 })
  }
}

