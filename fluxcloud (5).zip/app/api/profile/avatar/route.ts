import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    // In a real app, you would upload the avatar to a storage service
    // and save the URL in the database
    // For now, we'll just return a mock URL

    const formData = await request.formData()
    const avatar = formData.get("avatar")

    if (!avatar) {
      return NextResponse.json({ error: "No avatar file provided" }, { status: 400 })
    }

    // Mock URL for the uploaded avatar
    const avatarUrl = "/placeholder.svg?height=200&width=200"

    return NextResponse.json({ url: avatarUrl })
  } catch (error) {
    return NextResponse.json({ error: "Failed to upload avatar" }, { status: 500 })
  }
}

