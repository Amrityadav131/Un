import { NextResponse } from "next/server"

export async function GET(request: Request) {
  try {
    // In a real app, you would fetch the user profile from a database
    // For now, we'll return a mock user
    const user = {
      id: "123",
      name: "John Doe",
      email: "john@example.com",
      company: "Acme Inc",
      bio: "I am a software developer",
      avatar: null,
      role: "CLIENT",
      status: "ACTIVE",
      createdAt: new Date().toISOString(),
    }

    return NextResponse.json(user)
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch profile" }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json()

    // In a real app, you would update the user profile in a database
    // For now, we'll just return the updated user
    const updatedUser = {
      id: "123",
      name: body.name || "John Doe",
      email: body.email || "john@example.com",
      company: body.company || "",
      bio: body.bio || "",
      avatar: body.avatar || null,
      role: "CLIENT",
      status: "ACTIVE",
      updatedAt: new Date().toISOString(),
    }

    return NextResponse.json(updatedUser)
  } catch (error) {
    return NextResponse.json({ error: "Failed to update profile" }, { status: 500 })
  }
}

