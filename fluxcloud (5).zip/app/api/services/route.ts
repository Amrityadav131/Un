import { NextResponse } from "next/server"
import { z } from "zod"
import { prisma } from "@/lib/db"

const serviceSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters" }),
  description: z.string().optional(),
  price: z.number().positive({ message: "Price must be a positive number" }),
  clientId: z.string(),
  status: z.enum(["ACTIVE", "PENDING", "INACTIVE"]).default("ACTIVE"),
  startDate: z.string().datetime().optional(),
  endDate: z.string().datetime().optional(),
})

export async function GET() {
  try {
    const services = await prisma.service.findMany({
      include: {
        client: {
          include: {
            user: {
              select: {
                name: true,
                email: true,
              },
            },
          },
        },
      },
    })

    return NextResponse.json(services)
  } catch (error) {
    console.error("Error fetching services:", error)
    return NextResponse.json({ message: "Something went wrong" }, { status: 500 })
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json()
    const { name, description, price, clientId, status, startDate, endDate } = serviceSchema.parse(body)

    // Check if client exists
    const client = await prisma.client.findUnique({
      where: { id: clientId },
    })

    if (!client) {
      return NextResponse.json({ message: "Client not found" }, { status: 404 })
    }

    // Create service
    const service = await prisma.service.create({
      data: {
        name,
        description,
        price,
        clientId,
        status: status as any,
        startDate: startDate ? new Date(startDate) : new Date(),
        endDate: endDate ? new Date(endDate) : null,
      },
    })

    return NextResponse.json({ message: "Service created successfully", service }, { status: 201 })
  } catch (error) {
    console.error("Error creating service:", error)
    if (error instanceof z.ZodError) {
      return NextResponse.json({ message: "Validation error", errors: error.errors }, { status: 400 })
    }
    return NextResponse.json({ message: "Something went wrong" }, { status: 500 })
  }
}

