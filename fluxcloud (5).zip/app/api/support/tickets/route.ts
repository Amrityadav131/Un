import { NextResponse } from "next/server"
import { z } from "zod"
import { prisma } from "@/lib/db"

const ticketSchema = z.object({
  title: z.string().min(2, { message: "Title must be at least 2 characters" }),
  description: z.string().min(10, { message: "Description must be at least 10 characters" }),
  clientId: z.string(),
  priority: z.enum(["LOW", "MEDIUM", "HIGH", "CRITICAL"]).default("MEDIUM"),
})

export async function GET() {
  try {
    const tickets = await prisma.supportTicket.findMany({
      include: {
        client: {
          include: {
            user: {
              select: {
                name: true,
                email: true,
              },
            },
          },
        },
        user: {
          select: {
            name: true,
            email: true,
          },
        },
        messages: {
          orderBy: {
            createdAt: "asc",
          },
        },
      },
      orderBy: {
        updatedAt: "desc",
      },
    })

    return NextResponse.json(tickets)
  } catch (error) {
    console.error("Error fetching tickets:", error)
    return NextResponse.json({ message: "Something went wrong" }, { status: 500 })
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json()
    const { title, description, clientId, priority } = ticketSchema.parse(body)

    // Check if client exists
    const client = await prisma.client.findUnique({
      where: { id: clientId },
      include: { user: true },
    })

    if (!client) {
      return NextResponse.json({ message: "Client not found" }, { status: 404 })
    }

    // Create ticket
    const ticket = await prisma.supportTicket.create({
      data: {
        title,
        description,
        clientId,
        userId: client.user.id, // Set the user who created the ticket
        priority: priority as any,
      },
    })

    // Create initial message
    await prisma.supportMessage.create({
      data: {
        content: description,
        ticketId: ticket.id,
        userId: client.user.id,
      },
    })

    return NextResponse.json({ message: "Support ticket created successfully", ticket }, { status: 201 })
  } catch (error) {
    console.error("Error creating ticket:", error)
    if (error instanceof z.ZodError) {
      return NextResponse.json({ message: "Validation error", errors: error.errors }, { status: 400 })
    }
    return NextResponse.json({ message: "Something went wrong" }, { status: 500 })
  }
}

