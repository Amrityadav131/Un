import { NextResponse } from "next/server"
import { checkOverdueInvoices, updateInvoice } from "@/lib/db/invoices"
import { sendDiscordWebhook } from "@/lib/webhook"

export async function GET() {
  try {
    // Check for overdue invoices
    const overdueInvoices = await checkOverdueInvoices()

    // Send webhook notifications for each overdue invoice
    const results = await Promise.all(
      overdueInvoices.map(async (invoice) => {
        const webhookSent = await sendDiscordWebhook(invoice, "overdue")

        if (webhookSent) {
          // Update the invoice with webhook status
          await updateInvoice(invoice.id, { webhookSent: true })
        }

        return {
          id: invoice.id,
          webhookSent,
        }
      }),
    )

    return NextResponse.json({
      success: true,
      processed: overdueInvoices.length,
      results,
    })
  } catch (error) {
    console.error("Error checking overdue invoices:", error)
    return NextResponse.json({ error: "Failed to check overdue invoices" }, { status: 500 })
  }
}

