import { NextResponse } from "next/server"

export async function GET() {
  // In a real application, you would fetch invoices from a database
  // For now, we'll return an empty array
  return NextResponse.json([])
}

export async function POST(request: Request) {
  try {
    const data = await request.json()

    // In a real application, you would validate and save the invoice to a database
    // For now, we'll just return the data with a mock ID and invoice number
    const newInvoice = {
      id: Date.now().toString(),
      invoiceNumber: `INV-${Math.floor(1000 + Math.random() * 9000)}`,
      ...data,
      createdAt: new Date().toISOString(),
      status: data.status || "PENDING",
      paidDate: data.status === "PAID" ? new Date().toISOString() : null,
    }

    return NextResponse.json(newInvoice, { status: 201 })
  } catch (error) {
    return NextResponse.json({ error: "Failed to create invoice" }, { status: 500 })
  }
}

