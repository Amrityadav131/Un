import { NextResponse } from "next/server"
import { z } from "zod"
import { prisma } from "@/lib/db"

const clientSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters" }),
  email: z.string().email({ message: "Please enter a valid email address" }),
  company: z.string().optional(),
  phone: z.string().optional(),
  address: z.string().optional(),
  password: z.string().min(6, { message: "Password must be at least 6 characters" }),
})

export async function GET() {
  try {
    const clients = await prisma.client.findMany({
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
            avatar: true,
            createdAt: true,
          },
        },
      },
    })

    return NextResponse.json(clients)
  } catch (error) {
    console.error("Error fetching clients:", error)
    return NextResponse.json({ message: "Something went wrong" }, { status: 500 })
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json()
    const { name, email, company, phone, address, password } = clientSchema.parse(body)

    // Check if user already exists
    const existingUser = await prisma.user.findUnique({
      where: { email },
    })

    if (existingUser) {
      return NextResponse.json({ message: "User with this email already exists" }, { status: 409 })
    }

    // Create user and client in a transaction
    const result = await prisma.$transaction(async (tx) => {
      // Create user
      const user = await tx.user.create({
        data: {
          name,
          email,
          password, // In a real app, this would be hashed
          role: "CLIENT",
        },
      })

      // Create client
      const client = await tx.client.create({
        data: {
          userId: user.id,
          company,
          phone,
          address,
        },
      })

      return { user, client }
    })

    return NextResponse.json({ message: "Client created successfully", client: result.client }, { status: 201 })
  } catch (error) {
    console.error("Error creating client:", error)
    if (error instanceof z.ZodError) {
      return NextResponse.json({ message: "Validation error", errors: error.errors }, { status: 400 })
    }
    return NextResponse.json({ message: "Something went wrong" }, { status: 500 })
  }
}

