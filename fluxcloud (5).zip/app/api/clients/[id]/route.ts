import { NextResponse } from "next/server"
import { z } from "zod"
import { prisma } from "@/lib/db"

const updateClientSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters" }).optional(),
  company: z.string().optional(),
  phone: z.string().optional(),
  address: z.string().optional(),
  status: z.enum(["ACTIVE", "PENDING", "INACTIVE"]).optional(),
})

export async function GET(req: Request, { params }: { params: { id: string } }) {
  try {
    const client = await prisma.client.findUnique({
      where: { id: params.id },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
            avatar: true,
            createdAt: true,
          },
        },
        services: true,
        invoices: true,
      },
    })

    if (!client) {
      return NextResponse.json({ message: "Client not found" }, { status: 404 })
    }

    return NextResponse.json(client)
  } catch (error) {
    console.error("Error fetching client:", error)
    return NextResponse.json({ message: "Something went wrong" }, { status: 500 })
  }
}

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  try {
    const body = await req.json()
    const { name, company, phone, address, status } = updateClientSchema.parse(body)

    // Check if client exists
    const existingClient = await prisma.client.findUnique({
      where: { id: params.id },
      include: { user: true },
    })

    if (!existingClient) {
      return NextResponse.json({ message: "Client not found" }, { status: 404 })
    }

    // Update client and user in a transaction
    const result = await prisma.$transaction(async (tx) => {
      // Update user if name is provided
      if (name) {
        await tx.user.update({
          where: { id: existingClient.userId },
          data: { name },
        })
      }

      // Update client
      const client = await tx.client.update({
        where: { id: params.id },
        data: {
          company,
          phone,
          address,
          status: status as any,
        },
      })

      return client
    })

    return NextResponse.json(result)
  } catch (error) {
    console.error("Error updating client:", error)
    if (error instanceof z.ZodError) {
      return NextResponse.json({ message: "Validation error", errors: error.errors }, { status: 400 })
    }
    return NextResponse.json({ message: "Something went wrong" }, { status: 500 })
  }
}

export async function DELETE(req: Request, { params }: { params: { id: string } }) {
  try {
    // Check if client exists
    const existingClient = await prisma.client.findUnique({
      where: { id: params.id },
    })

    if (!existingClient) {
      return NextResponse.json({ message: "Client not found" }, { status: 404 })
    }

    // Delete client
    await prisma.client.delete({
      where: { id: params.id },
    })

    return NextResponse.json({ message: "Client deleted successfully" }, { status: 200 })
  } catch (error) {
    console.error("Error deleting client:", error)
    return NextResponse.json({ message: "Something went wrong" }, { status: 500 })
  }
}

