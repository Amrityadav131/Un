import { NextResponse } from "next/server"
import { z } from "zod"
import { prisma } from "@/lib/db"

const expenseSchema = z.object({
  description: z.string().min(2, { message: "Description must be at least 2 characters" }),
  amount: z.number().positive({ message: "Amount must be a positive number" }),
  category: z.string(),
  date: z.string().datetime(),
  receipt: z.string().optional(),
})

export async function GET() {
  try {
    const expenses = await prisma.expense.findMany({
      orderBy: {
        date: "desc",
      },
    })

    return NextResponse.json(expenses)
  } catch (error) {
    console.error("Error fetching expenses:", error)
    return NextResponse.json({ message: "Something went wrong" }, { status: 500 })
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json()
    const { description, amount, category, date, receipt } = expenseSchema.parse(body)

    // Create expense
    const expense = await prisma.expense.create({
      data: {
        description,
        amount,
        category,
        date: new Date(date),
        receipt,
      },
    })

    return NextResponse.json({ message: "Expense created successfully", expense }, { status: 201 })
  } catch (error) {
    console.error("Error creating expense:", error)
    if (error instanceof z.ZodError) {
      return NextResponse.json({ message: "Validation error", errors: error.errors }, { status: 400 })
    }
    return NextResponse.json({ message: "Something went wrong" }, { status: 500 })
  }
}

