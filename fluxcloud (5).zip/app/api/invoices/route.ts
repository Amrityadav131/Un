import { NextResponse } from "next/server"
import { z } from "zod"
import { prisma } from "@/lib/db"

const invoiceItemSchema = z.object({
  serviceId: z.string(),
  description: z.string(),
  quantity: z.number().int().positive(),
  unitPrice: z.number().positive(),
})

const invoiceSchema = z.object({
  clientId: z.string(),
  dueDate: z.string().datetime(),
  items: z.array(invoiceItemSchema),
})

export async function GET() {
  try {
    const invoices = await prisma.invoice.findMany({
      include: {
        client: {
          include: {
            user: {
              select: {
                name: true,
                email: true,
              },
            },
          },
        },
        items: {
          include: {
            service: true,
          },
        },
      },
    })

    return NextResponse.json(invoices)
  } catch (error) {
    console.error("Error fetching invoices:", error)
    return NextResponse.json({ message: "Something went wrong" }, { status: 500 })
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json()
    const { clientId, dueDate, items } = invoiceSchema.parse(body)

    // Check if client exists
    const client = await prisma.client.findUnique({
      where: { id: clientId },
    })

    if (!client) {
      return NextResponse.json({ message: "Client not found" }, { status: 404 })
    }

    // Calculate total amount
    const totalAmount = items.reduce((sum, item) => sum + item.quantity * item.unitPrice, 0)

    // Generate invoice number
    const invoiceNumber = `INV-${Date.now().toString().slice(-6)}`

    // Create invoice and items in a transaction
    const invoice = await prisma.$transaction(async (tx) => {
      // Create invoice
      const newInvoice = await tx.invoice.create({
        data: {
          invoiceNumber,
          clientId,
          amount: totalAmount,
          dueDate: new Date(dueDate),
          items: {
            create: items.map((item) => ({
              serviceId: item.serviceId,
              description: item.description,
              quantity: item.quantity,
              unitPrice: item.unitPrice,
              amount: item.quantity * item.unitPrice,
            })),
          },
        },
        include: {
          items: true,
        },
      })

      return newInvoice
    })

    return NextResponse.json({ message: "Invoice created successfully", invoice }, { status: 201 })
  } catch (error) {
    console.error("Error creating invoice:", error)
    if (error instanceof z.ZodError) {
      return NextResponse.json({ message: "Validation error", errors: error.errors }, { status: 400 })
    }
    return NextResponse.json({ message: "Something went wrong" }, { status: 500 })
  }
}

