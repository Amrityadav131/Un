import { NextResponse } from "next/server"

export async function POST() {
  try {
    // Create a response
    const response = NextResponse.json({ success: true })

    // Clear the auth cookie
    response.cookies.set({
      name: "auth_token",
      value: "",
      httpOnly: true,
      path: "/",
      secure: process.env.NODE_ENV === "production",
      maxAge: 0, // Expire immediately
    })

    return response
  } catch (error) {
    console.error("Logout failed:", error)
    return NextResponse.json({ error: "Logout failed" }, { status: 500 })
  }
}

