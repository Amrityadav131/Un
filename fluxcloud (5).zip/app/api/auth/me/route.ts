import { NextResponse } from "next/server"
import { cookies } from "next/headers"
import { verifyJwt } from "@/lib/jwt"

// Use the environment variable directly
const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key-here"

export async function GET() {
  try {
    // In Next.js 14+, we need to use a different approach for cookies
    const authToken = cookies().get("auth_token")
    const token = authToken?.value

    if (!token) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 })
    }

    // Verify the JWT token
    try {
      const { valid, payload } = verifyJwt(token, JWT_SECRET)

      if (!valid || !payload || !payload.sub) {
        return NextResponse.json({ error: "Invalid token" }, { status: 401 })
      }

      // Return user data
      return NextResponse.json({
        id: payload.sub,
        name: payload.name,
        email: payload.email,
        role: payload.role,
        avatar: payload.avatar || null,
      })
    } catch (error) {
      console.error("Token verification failed:", error)
      return NextResponse.json({ error: "Invalid token" }, { status: 401 })
    }
  } catch (error) {
    console.error("Auth check failed:", error)
    return NextResponse.json({ error: "Authentication failed" }, { status: 500 })
  }
}

