import { NextResponse } from "next/server"

// Mock user data for demo purposes
const users = {
  ADMIN: {
    id: "admin-123",
    name: "Admin User",
    email: "admin@fluxcloud.com",
    role: "ADMIN",
    avatar: null,
  },
  CLIENT: {
    id: "client-456",
    name: "Client User",
    email: "client@example.com",
    role: "CLIENT",
    avatar: null,
  },
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { role } = body

    if (!role || !users[role]) {
      return NextResponse.json({ error: "Invalid role" }, { status: 400 })
    }

    const user = users[role]

    // Create a simple token (in a real app, use a proper JWT library)
    const token = JSON.stringify({
      sub: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      avatar: user.avatar,
      exp: Math.floor(Date.now() / 1000) + 60 * 60 * 24, // 24 hours
    })

    // Base64 encode the token
    const encodedToken = Buffer.from(token).toString("base64")

    // Set the cookie
    const response = NextResponse.json(user)

    // Set the cookie with proper options
    response.cookies.set({
      name: "auth_token",
      value: encodedToken,
      httpOnly: true,
      path: "/",
      secure: process.env.NODE_ENV === "production",
      maxAge: 60 * 60 * 24, // 24 hours
    })

    return response
  } catch (error) {
    console.error("Login failed:", error)
    return NextResponse.json({ error: "Login failed" }, { status: 500 })
  }
}

