import { NextResponse } from "next/server"
import fs from "fs"
import path from "path"

// Directory and file paths
const DATA_DIR = path.join(process.cwd(), "data")
const INVOICES_FILE = path.join(DATA_DIR, "invoices.json")

// Helper function to read invoices from file
function getInvoices() {
  try {
    if (!fs.existsSync(INVOICES_FILE)) {
      return []
    }
    const data = fs.readFileSync(INVOICES_FILE, "utf8")
    return JSON.parse(data)
  } catch (error) {
    console.error("Error reading invoices file:", error)
    return []
  }
}

// Helper function to write invoices to file
function saveInvoices(invoices) {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true })
    }
    fs.writeFileSync(INVOICES_FILE, JSON.stringify(invoices, null, 2), "utf8")
    return true
  } catch (error) {
    console.error("Error writing invoices file:", error)
    return false
  }
}

// Helper function to send Discord webhook
async function sendDiscordWebhook(invoice) {
  try {
    // Use the provided webhook URL
    const webhookUrl =
      process.env.DISCORD_WEBHOOK_URL ||
      "https://discord.com/api/webhooks/1351399066705203332/khH6VWNnUlSq44Dn3dyDla4_lgPAeTSi32x7Z-9AnNsG_hcuOpK2ftcQ5OHX7o5zC3Rt"

    // Create the webhook payload
    const payload = {
      content: invoice.discordId ? `<@${invoice.discordId}>` : "",
      embeds: [
        {
          title: "💰 Invoice Paid",
          description: `Invoice #${invoice.id} has been paid.`,
          color: 0x57f287, // Discord green
          fields: [
            {
              name: "Client",
              value: invoice.clientName || invoice.email,
              inline: true,
            },
            {
              name: "Amount",
              value: `$${Number.parseFloat(invoice.amount).toFixed(2)}`,
              inline: true,
            },
            {
              name: "Payment Date",
              value: new Date().toLocaleDateString("en-US", {
                year: "numeric",
                month: "long",
                day: "numeric",
              }),
              inline: true,
            },
            {
              name: "Description",
              value:
                invoice.description.length > 1000 ? invoice.description.substring(0, 997) + "..." : invoice.description,
            },
          ],
          footer: {
            text: "FluxCloud Invoice System",
          },
          timestamp: new Date().toISOString(),
        },
      ],
    }

    // Send the webhook
    const response = await fetch(webhookUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    })

    if (!response.ok) {
      throw new Error(`Failed to send Discord webhook: ${response.statusText}`)
    }

    console.log(`Discord webhook sent successfully for invoice ${invoice.id}`)
    return true
  } catch (error) {
    console.error("Error sending Discord webhook:", error)
    return false
  }
}

export async function POST(request, { params }) {
  try {
    const invoices = getInvoices()
    const index = invoices.findIndex((inv) => inv.id === params.id)

    if (index === -1) {
      return NextResponse.json({ error: "Invoice not found" }, { status: 404 })
    }

    // Check if invoice is already paid
    if (invoices[index].status === "paid") {
      return NextResponse.json({ error: "Invoice is already paid" }, { status: 400 })
    }

    // Update invoice status to paid
    invoices[index].status = "paid"
    invoices[index].updatedAt = new Date().toISOString()

    if (saveInvoices(invoices)) {
      // Send webhook notification
      const webhookSent = await sendDiscordWebhook(invoices[index])

      return NextResponse.json({
        message: "Invoice marked as paid successfully",
        webhookSent,
      })
    } else {
      return NextResponse.json({ error: "Failed to update invoice" }, { status: 500 })
    }
  } catch (error) {
    console.error("Error marking invoice as paid:", error)
    return NextResponse.json({ error: "Failed to mark invoice as paid" }, { status: 500 })
  }
}

