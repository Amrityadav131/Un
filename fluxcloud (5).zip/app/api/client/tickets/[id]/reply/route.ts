import { NextResponse } from "next/server"

// Reference to the in-memory storage from the main route
// In a real app, this would be a database
import { tickets } from "../../route"

export async function POST(request: Request, { params }: { params: { id: string } }) {
  try {
    const body = await request.json()
    const ticketIndex = tickets.findIndex((t) => t.id === params.id)

    if (ticketIndex === -1) {
      return NextResponse.json({ error: "Ticket not found" }, { status: 404 })
    }

    // Validate required fields
    if (!body.message) {
      return NextResponse.json({ error: "Message is required" }, { status: 400 })
    }

    // Create reply
    const reply = {
      message: body.message,
      userId: body.userId || "anonymous",
      userName: body.userName || "Client",
      isAdmin: false,
      createdAt: new Date().toISOString(),
    }

    // Add reply to ticket
    if (!tickets[ticketIndex].replies) {
      tickets[ticketIndex].replies = []
    }

    tickets[ticketIndex].replies.push(reply)
    tickets[ticketIndex].status = "PENDING"
    tickets[ticketIndex].updatedAt = new Date().toISOString()

    return NextResponse.json(tickets[ticketIndex])
  } catch (error) {
    return NextResponse.json({ error: "Failed to add reply" }, { status: 500 })
  }
}

