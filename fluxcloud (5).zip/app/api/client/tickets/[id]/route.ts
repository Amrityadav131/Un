import { NextResponse } from "next/server"

// Reference to the in-memory storage from the main route
// In a real app, this would be a database
import { tickets } from "../route"

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const ticket = tickets.find((t) => t.id === params.id)

    if (!ticket) {
      return NextResponse.json({ error: "Ticket not found" }, { status: 404 })
    }

    return NextResponse.json(ticket)
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch ticket" }, { status: 500 })
  }
}

