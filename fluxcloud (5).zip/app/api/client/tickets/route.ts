import { NextResponse } from "next/server"

// In-memory storage for tickets (replace with database in production)
const tickets = []

export async function GET() {
  try {
    return NextResponse.json(tickets)
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch tickets" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()

    // Validate required fields
    if (!body.subject || !body.message) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Create new ticket
    const newTicket = {
      id: Math.random().toString(36).substring(2, 9),
      subject: body.subject,
      message: body.message,
      priority: body.priority || "MEDIUM",
      status: "OPEN",
      userId: body.userId || "anonymous",
      userName: body.userName || "Client",
      replies: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }

    tickets.push(newTicket)

    return NextResponse.json(newTicket, { status: 201 })
  } catch (error) {
    return NextResponse.json({ error: "Failed to create ticket" }, { status: 500 })
  }
}

