import { NextResponse } from "next/server"
import { z } from "zod"
import { sendDiscordNotification } from "@/lib/discord"

const notificationSchema = z.object({
  message: z.string(),
  title: z.string().optional(),
  type: z.enum(["info", "success", "warning", "error"]).optional(),
  fields: z
    .array(
      z.object({
        name: z.string(),
        value: z.string(),
        inline: z.boolean().optional(),
      }),
    )
    .optional(),
  footer: z.string().optional(),
})

export async function POST(req: Request) {
  try {
    const body = await req.json()
    const { message, title, type, fields, footer } = notificationSchema.parse(body)

    await sendDiscordNotification(message, {
      title,
      type,
      fields,
      footer,
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error sending notification:", error)
    if (error instanceof z.ZodError) {
      return NextResponse.json({ message: "Validation error", errors: error.errors }, { status: 400 })
    }
    return NextResponse.json({ message: "Something went wrong" }, { status: 500 })
  }
}

