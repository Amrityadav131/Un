"use client"

import React from "react"

/**
 * Login Page Component
 * Software made by nikhil & arpit | AuraNodes 2025
 */

import { useState, useEffect } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { Cloud, Loader2, Eye, EyeOff, AlertCircle } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { useToast } from "@/components/ui/use-toast"
import { useAuth } from "@/components/auth-provider"
import { Alert, AlertDescription } from "@/components/ui/alert"

const formSchema = z.object({
  email: z.string().email({ message: "Please enter a valid email address" }),
  password: z.string().min(6, { message: "Password must be at least 6 characters" }),
})

export default function LoginPage() {
  const { login, user } = useAuth()
  const { toast } = useToast()
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      email: "",
      password: "",
    },
  })

  // Redirect if already logged in
  useEffect(() => {
    if (user) {
      const dashboardPath = user.role === "ADMIN" ? "/admin/dashboard" : "/client/dashboard"
      router.push(dashboardPath)
    }
  }, [user, router])

  // Clear error when form values change
  useEffect(() => {
    if (error) {
      const subscription = form.watch(() => setError(null))
      return () => subscription.unsubscribe()
    }
  }, [error, form])

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setIsLoading(true)
    setError(null)

    try {
      await login(values.email, values.password)
      // The redirect will be handled by the login function in AuthProvider
    } catch (error) {
      setError(error instanceof Error ? error.message : "Login failed. Please check your credentials.")
      form.setFocus("email")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-black bg-crystal-mountains bg-cover bg-center bg-no-repeat p-4">
      <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/50 to-black/70 backdrop-blur-sm"></div>

      <div className="relative z-10 w-full max-w-md">
        <Card className="glass-card border-white/10 shadow-glass overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-fluxcloud-black/30 to-fluxcloud-black/10 pointer-events-none"></div>
          <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-fluxcloud-cyan via-fluxcloud-navy-green to-fluxcloud-navy-yellow"></div>

          <CardHeader className="space-y-1 relative">
            <div className="flex items-center justify-center mb-4">
              <div>
                <Cloud className="h-12 w-12 text-fluxcloud-cyan" />
              </div>
            </div>
            <CardTitle className="text-2xl font-bold text-center text-white neon-text-cyan">
              Login to FluxCloud
            </CardTitle>
            <CardDescription className="text-center text-white/70">
              Enter your credentials to access your dashboard
            </CardDescription>
          </CardHeader>

          <CardContent className="relative">
            <React.Fragment>
              {error && (
                <Alert variant="destructive" className="bg-red-500/10 border-red-500/20 text-red-500 mb-4">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}
            </React.Fragment>

            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-white">Email</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="email@example.com"
                          {...field}
                          className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus-visible:ring-fluxcloud-cyan"
                          disabled={isLoading}
                          autoComplete="email"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-white">Password</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <Input
                            type={showPassword ? "text" : "password"}
                            placeholder="••••••••"
                            {...field}
                            className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus-visible:ring-fluxcloud-cyan pr-10"
                            disabled={isLoading}
                            autoComplete="current-password"
                          />
                          <button
                            type="button"
                            className="absolute right-3 top-1/2 -translate-y-1/2 text-white/50 hover:text-white"
                            onClick={() => setShowPassword(!showPassword)}
                            tabIndex={-1}
                          >
                            {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                          </button>
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button
                  type="submit"
                  className="w-full bg-fluxcloud-cyan text-black hover:bg-fluxcloud-cyan/80 shadow-neon-cyan btn-hover-effect"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Logging in...
                    </>
                  ) : (
                    "Login"
                  )}
                </Button>
              </form>
            </Form>
            <div className="mt-4 text-center text-sm">
              <Link href="/auth/forgot-password" className="text-fluxcloud-cyan hover:underline neon-text-cyan">
                Forgot password?
              </Link>
            </div>
          </CardContent>

          <CardFooter className="flex flex-col space-y-4 relative">
            <div className="text-center text-sm text-white/70">
              Don&apos;t have an account?{" "}
              <Link href="/auth/register" className="text-fluxcloud-cyan hover:underline neon-text-cyan">
                Register
              </Link>
            </div>
            <div className="text-center text-sm">
              <Link href="/" className="text-white/50 hover:underline">
                Back to home
              </Link>
            </div>
          </CardFooter>
        </Card>

        <div className="mt-4 text-center text-xs text-white/30">Software made by nikhil & arpit | AuraNodes 2025</div>
      </div>
    </div>
  )
}

