"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/components/auth-provider"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, Cloud, Shield, Users, Zap } from "lucide-react"

export default function Home() {
  const { user, loading } = useAuth()
  const router = useRouter()

  // Redirect authenticated users to their dashboard
  useEffect(() => {
    if (!loading && user) {
      const dashboardPath = user.role === "ADMIN" ? "/admin/dashboard" : "/client/dashboard"
      router.push(dashboardPath)
    }
  }, [user, loading, router])

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-black">
        <div className="h-12 w-12 rounded-full border-4 border-fluxcloud-cyan border-t-transparent animate-spin"></div>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen flex-col bg-black bg-crystal-mountains bg-cover bg-center bg-no-repeat">
      <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/50 to-black/70 backdrop-blur-sm"></div>
      <header className="relative z-10 w-full border-b border-white/10 bg-black/20 backdrop-blur-md">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2 font-bold text-white">
            <Cloud className="h-6 w-6 text-fluxcloud-cyan animate-pulse" />
            <span className="text-xl tracking-tight">FluxCloud</span>
          </div>
          <nav className="hidden gap-8 md:flex">
            <Link
              href="#features"
              className="text-sm font-medium text-white/70 transition-colors hover:text-fluxcloud-cyan"
            >
              Features
            </Link>
            <Link
              href="#pricing"
              className="text-sm font-medium text-white/70 transition-colors hover:text-fluxcloud-cyan"
            >
              Pricing
            </Link>
            <Link
              href="#about"
              className="text-sm font-medium text-white/70 transition-colors hover:text-fluxcloud-cyan"
            >
              About
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <Link href="/auth/login">
              <Button
                variant="ghost"
                size="sm"
                className="text-white hover:bg-white/10 hover:text-fluxcloud-cyan btn-hover-effect"
              >
                Login
              </Button>
            </Link>
            <Link href="/auth/register">
              <Button
                size="sm"
                className="bg-fluxcloud-cyan text-black hover:bg-fluxcloud-cyan/80 shadow-neon-cyan btn-hover-effect"
              >
                Register
              </Button>
            </Link>
          </div>
        </div>
      </header>
      <main className="relative z-10 flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-[1fr_400px] lg:gap-12 xl:grid-cols-[1fr_600px]">
              <div className="flex flex-col justify-center space-y-4">
                <div className="space-y-2">
                  <h1 className="text-3xl font-bold tracking-tighter text-white sm:text-5xl xl:text-6xl/none gradient-text">
                    Cloud Services Management Reimagined
                  </h1>
                  <p className="max-w-[600px] text-white/70 md:text-xl">
                    Streamline your cloud infrastructure with our powerful, intuitive dashboard. Manage clients,
                    services, and billing in one secure platform.
                  </p>
                </div>
                <div className="flex flex-col gap-2 min-[400px]:flex-row">
                  <Link href="/auth/register">
                    <Button
                      size="lg"
                      className="gap-1.5 bg-fluxcloud-cyan text-black hover:bg-fluxcloud-cyan/80 shadow-neon-cyan btn-hover-effect"
                    >
                      Get Started
                      <ArrowRight className="h-4 w-4" />
                    </Button>
                  </Link>
                  <Link href="/auth/login">
                    <Button
                      size="lg"
                      variant="outline"
                      className="border-white/20 text-white hover:bg-white/10 btn-hover-effect"
                    >
                      Login
                    </Button>
                  </Link>
                </div>
              </div>
              <div className="flex items-center justify-center">
                <div className="glass-card relative h-[350px] w-full overflow-hidden rounded-xl p-8 shadow-lg card-hover-lift">
                  <div className="absolute inset-0 bg-gradient-to-br from-fluxcloud-black/50 to-fluxcloud-black/20"></div>
                  <div className="relative flex h-full flex-col items-center justify-center gap-4 text-center">
                    <Cloud className="h-16 w-16 text-fluxcloud-cyan animate-float" />
                    <div className="space-y-2">
                      <h2 className="text-2xl font-bold text-white neon-text-cyan">FluxCloud Dashboard</h2>
                      <p className="text-white/70">Powerful. Intuitive. Secure.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section id="features" className="w-full py-12 md:py-24 lg:py-32 bg-black/80">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter text-white sm:text-5xl neon-text-cyan">
                  Key Features
                </h2>
                <p className="max-w-[900px] text-white/70 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Everything you need to manage your cloud services efficiently
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 py-12 md:grid-cols-3">
              <div className="glass-card flex flex-col items-center space-y-2 rounded-lg p-6 shadow-md card-hover-lift">
                <Users className="h-12 w-12 text-fluxcloud-cyan" />
                <h3 className="text-xl font-bold text-white">Client Management</h3>
                <p className="text-center text-white/70">
                  Easily manage clients, track their services, and handle invoicing with precision
                </p>
              </div>
              <div className="glass-card flex flex-col items-center space-y-2 rounded-lg p-6 shadow-md card-hover-lift">
                <Cloud className="h-12 w-12 text-fluxcloud-navy-green" />
                <h3 className="text-xl font-bold text-white">Service Tracking</h3>
                <p className="text-center text-white/70">
                  Monitor all your cloud services, their status, and performance in real-time
                </p>
              </div>
              <div className="glass-card flex flex-col items-center space-y-2 rounded-lg p-6 shadow-md card-hover-lift">
                <Shield className="h-12 w-12 text-fluxcloud-navy-yellow" />
                <h3 className="text-xl font-bold text-white">Secure Access</h3>
                <p className="text-center text-white/70">
                  Role-based access control for admins and clients with advanced security features
                </p>
              </div>
            </div>
          </div>
        </section>
        <section id="about" className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-t from-black/90 to-black/70">
          <div className="container px-4 md:px-6">
            <div className="grid gap-10 lg:grid-cols-2">
              <div className="flex flex-col justify-center space-y-4">
                <div>
                  <h2 className="text-3xl font-bold tracking-tighter text-white sm:text-4xl md:text-5xl neon-text-green">
                    Why Choose FluxCloud?
                  </h2>
                  <p className="mt-4 text-white/70 md:text-xl">
                    FluxCloud provides a comprehensive solution for managing cloud services, clients, and billing in one
                    secure platform.
                  </p>
                </div>
                <ul className="grid gap-4">
                  <li className="flex items-center gap-3">
                    <Zap className="h-5 w-5 text-fluxcloud-cyan" />
                    <span className="text-white">Intuitive dashboard with real-time analytics</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <Zap className="h-5 w-5 text-fluxcloud-cyan" />
                    <span className="text-white">Automated billing and invoice management</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <Zap className="h-5 w-5 text-fluxcloud-cyan" />
                    <span className="text-white">Secure client portal for service management</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <Zap className="h-5 w-5 text-fluxcloud-cyan" />
                    <span className="text-white">Comprehensive reporting and analytics</span>
                  </li>
                </ul>
              </div>
              <div className="flex items-center justify-center">
                <div className="glass-card relative h-full w-full overflow-hidden rounded-xl p-8 shadow-lg card-hover-lift">
                  <div className="absolute inset-0 bg-gradient-to-br from-fluxcloud-black/50 to-fluxcloud-black/20"></div>
                  <div className="relative flex h-full flex-col items-center justify-center gap-6 text-center">
                    <div className="space-y-2">
                      <h3 className="text-2xl font-bold text-white neon-text-yellow">Ready to Get Started?</h3>
                      <p className="text-white/70">
                        Join thousands of businesses that trust FluxCloud for their cloud service management needs.
                      </p>
                    </div>
                    <Link href="/auth/register" className="w-full max-w-xs">
                      <Button className="w-full bg-fluxcloud-cyan text-black hover:bg-fluxcloud-cyan/80 shadow-neon-cyan btn-hover-effect">
                        Create Your Account
                      </Button>
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer className="relative z-10 w-full border-t border-white/10 bg-black/30 py-6 backdrop-blur-md">
        <div className="container flex flex-col items-center justify-center gap-4 md:flex-row md:justify-between">
          <div className="flex items-center gap-2 font-bold text-white">
            <Cloud className="h-6 w-6 text-fluxcloud-cyan" />
            <span>FluxCloud</span>
          </div>
          <p className="text-center text-sm text-white/50">
            © {new Date().getFullYear()} FluxCloud. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  )
}

