/**
 * Database Connection Utility
 * Software made by nikhil & arpit | AuraNodes 2025
 */

import { PrismaClient } from "@prisma/client"

// Add prisma to the NodeJS global type
declare global {
  var prisma: PrismaClient | undefined
}

let prisma: PrismaClient

// Prevent multiple instances of Prisma Client in development
if (process.env.NODE_ENV === "production") {
  prisma = new PrismaClient({
    log: process.env.NODE_ENV === "development" ? ["query", "error", "warn"] : ["error"],
  })
} else {
  if (!global.prisma) {
    global.prisma = new PrismaClient({
      log: process.env.NODE_ENV === "development" ? ["query", "error", "warn"] : ["error"],
    })
  }
  prisma = global.prisma
}

// Function to test database connection
export async function testDatabaseConnection() {
  try {
    // Try to query the database
    await prisma.$queryRaw`SELECT 1`
    console.log("✅ Database connection successful")
    return true
  } catch (error) {
    console.error("❌ Database connection failed:", error)
    return false
  }
}

export { prisma }

