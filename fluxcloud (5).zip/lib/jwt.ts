// Simple JWT utility functions for demo purposes

// Parse a JWT token
export function parseJwt(token: string) {
  try {
    // For our simplified token, just decode the base64
    const decoded = Buffer.from(token, "base64").toString()
    return JSON.parse(decoded)
  } catch (error) {
    console.error("Failed to parse token:", error)
    return null
  }
}

// Verify a JWT token
export function verifyJwt(token: string, secret: string) {
  try {
    if (!token) {
      return { valid: false, payload: null }
    }

    const payload = parseJwt(token)

    if (!payload) {
      return { valid: false, payload: null }
    }

    // Check if token is expired
    if (payload.exp && payload.exp < Math.floor(Date.now() / 1000)) {
      return { valid: false, payload: null }
    }

    return { valid: true, payload }
  } catch (error) {
    console.error("JWT verification failed:", error)
    return { valid: false, payload: null }
  }
}

// Create a JWT token
export function createJwt(payload: any, secret: string) {
  try {
    const token = JSON.stringify({
      ...payload,
      exp: Math.floor(Date.now() / 1000) + 60 * 60 * 24, // 24 hours
    })

    return Buffer.from(token).toString("base64")
  } catch (error) {
    console.error("JWT creation failed:", error)
    return null
  }
}

