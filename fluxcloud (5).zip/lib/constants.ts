export const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key-for-development"

