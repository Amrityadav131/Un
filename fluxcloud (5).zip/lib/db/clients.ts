import fs from "fs"
import path from "path"
import { generateId } from "../utils"

// Define the client type
export interface Client {
  id: string
  name: string
  email: string
  discordId?: string
  phone?: string
  address?: string
  createdAt: string
  updatedAt: string
}

// Path to the clients data file
const clientsFilePath = path.join(process.cwd(), "data", "clients.json")

// Function to ensure the data directory exists
function ensureDataDirectoryExists() {
  const dataDir = path.join(process.cwd(), "data")
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true })
  }
}

// Function to read all clients from the JSON file
export async function getAllClients(): Promise<Client[]> {
  ensureDataDirectoryExists()

  try {
    if (!fs.existsSync(clientsFilePath)) {
      // If the file doesn't exist, create it with an empty clients array
      fs.writeFileSync(clientsFilePath, JSON.stringify({ clients: [] }, null, 2))
      return []
    }

    const data = fs.readFileSync(clientsFilePath, "utf8")
    const parsedData = JSON.parse(data)

    // Handle both array format and { clients: [] } format
    return Array.isArray(parsedData) ? parsedData : parsedData.clients || []
  } catch (error) {
    console.error("Error reading clients data:", error)
    return []
  }
}

// Function to save clients to the JSON file
async function saveClients(clients: Client[]): Promise<void> {
  ensureDataDirectoryExists()
  fs.writeFileSync(clientsFilePath, JSON.stringify({ clients }, null, 2))
}

// Function to get a client by ID
export async function getClientById(id: string): Promise<Client | null> {
  const clients = await getAllClients()
  return clients.find((client) => client.id === id) || null
}

// Function to create a new client
export async function createClient(clientData: Omit<Client, "id" | "createdAt" | "updatedAt">): Promise<Client> {
  const clients = await getAllClients()

  const newClient: Client = {
    id: generateId(),
    ...clientData,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  }

  clients.push(newClient)
  await saveClients(clients)

  return newClient
}

// Function to update a client
export async function updateClient(
  id: string,
  clientData: Partial<Omit<Client, "id" | "createdAt">>,
): Promise<Client | null> {
  const clients = await getAllClients()
  const clientIndex = clients.findIndex((client) => client.id === id)

  if (clientIndex === -1) {
    return null
  }

  const updatedClient: Client = {
    ...clients[clientIndex],
    ...clientData,
    updatedAt: new Date().toISOString(),
  }

  clients[clientIndex] = updatedClient
  await saveClients(clients)

  return updatedClient
}

// Function to delete a client
export async function deleteClient(id: string): Promise<boolean> {
  const clients = await getAllClients()
  const filteredClients = clients.filter((client) => client.id !== id)

  if (filteredClients.length === clients.length) {
    return false // No client was removed
  }

  await saveClients(filteredClients)
  return true
}

