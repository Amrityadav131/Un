import fs from "fs"
import path from "path"
import { generateId } from "../utils"

// Define the invoice type
export interface Invoice {
  id: string
  clientId: string | null // Make clientId optional
  email: string // Email is required
  discordId?: string
  description: string
  amount: number
  status: "paid" | "pending" | "overdue"
  dueDate: string
  repaymentDate?: string
  createdAt: string
  updatedAt: string
  webhookSent?: boolean
}

// Path to the invoices data file
const invoicesFilePath = path.join(process.cwd(), "data", "invoices.json")

// Function to ensure the data directory exists
function ensureDataDirectoryExists() {
  const dataDir = path.join(process.cwd(), "data")
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true })
  }
}

// Function to read all invoices from the JSON file
export async function getAllInvoices(): Promise<Invoice[]> {
  ensureDataDirectoryExists()

  try {
    if (!fs.existsSync(invoicesFilePath)) {
      // If the file doesn't exist, create it with an empty array
      fs.writeFileSync(invoicesFilePath, JSON.stringify([], null, 2))
      return []
    }

    const data = fs.readFileSync(invoicesFilePath, "utf8")
    return JSON.parse(data)
  } catch (error) {
    console.error("Error reading invoices data:", error)
    return []
  }
}

// Function to save invoices to the JSON file
export async function saveInvoices(invoices: Invoice[]): Promise<void> {
  ensureDataDirectoryExists()
  fs.writeFileSync(invoicesFilePath, JSON.stringify(invoices, null, 2))
}

// Function to get an invoice by ID
export async function getInvoiceById(id: string): Promise<Invoice | null> {
  const invoices = await getAllInvoices()
  return invoices.find((invoice) => invoice.id === id) || null
}

// Function to create a new invoice
export async function createInvoice(invoiceData: Omit<Invoice, "id" | "createdAt" | "updatedAt">): Promise<Invoice> {
  // Validate email
  if (!invoiceData.email) {
    throw new Error("Email is required")
  }

  const invoices = await getAllInvoices()

  const newInvoice: Invoice = {
    id: generateId(),
    ...invoiceData,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  }

  invoices.push(newInvoice)
  await saveInvoices(invoices)

  return newInvoice
}

// Function to update an invoice
export async function updateInvoice(
  id: string,
  invoiceData: Partial<Omit<Invoice, "id" | "createdAt">>,
): Promise<Invoice | null> {
  const invoices = await getAllInvoices()
  const invoiceIndex = invoices.findIndex((invoice) => invoice.id === id)

  if (invoiceIndex === -1) {
    return null
  }

  const updatedInvoice: Invoice = {
    ...invoices[invoiceIndex],
    ...invoiceData,
    updatedAt: new Date().toISOString(),
  }

  invoices[invoiceIndex] = updatedInvoice
  await saveInvoices(invoices)

  return updatedInvoice
}

// Function to delete an invoice
export async function deleteInvoice(id: string): Promise<boolean> {
  const invoices = await getAllInvoices()
  const filteredInvoices = invoices.filter((invoice) => invoice.id !== id)

  if (filteredInvoices.length === invoices.length) {
    return false // No invoice was removed
  }

  await saveInvoices(filteredInvoices)
  return true
}

// Function to check for overdue invoices
export async function checkOverdueInvoices(): Promise<Invoice[]> {
  const invoices = await getAllInvoices()
  const today = new Date()
  const overdueInvoices: Invoice[] = []

  for (const invoice of invoices) {
    if (invoice.status === "pending") {
      const dueDate = new Date(invoice.dueDate)

      if (dueDate < today) {
        // Update the invoice status to overdue
        const updatedInvoice = await updateInvoice(invoice.id, {
          status: "overdue",
          webhookSent: false, // Reset webhook status so a new notification can be sent
        })

        if (updatedInvoice) {
          overdueInvoices.push(updatedInvoice)
        }
      }
    }
  }

  return overdueInvoices
}

