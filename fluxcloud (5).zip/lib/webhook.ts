import type { Invoice } from "./db/invoices"

export async function sendDiscordWebhook(invoice: Invoice, type: "new" | "paid" | "overdue"): Promise<boolean> {
  try {
    // Get the webhook URL from environment variables
    const webhookUrl = process.env.DISCORD_WEBHOOK_URL

    if (!webhookUrl) {
      console.error("Discord webhook URL not configured")
      return false
    }

    // Create the webhook payload based on the invoice type
    const payload = createWebhookPayload(invoice, type)

    // Send the webhook
    const response = await fetch(webhookUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    })

    if (!response.ok) {
      const errorText = await response.text()
      console.error(`Discord webhook failed with status ${response.status}: ${errorText}`)
      throw new Error(`Discord webhook failed with status ${response.status}`)
    }

    console.log(`Successfully sent ${type} invoice webhook notification for invoice ${invoice.id}`)
    return true
  } catch (error) {
    console.error("Error sending Discord webhook:", error)
    return false
  }
}

function createWebhookPayload(invoice: Invoice, type: "new" | "paid" | "overdue") {
  // Format the amount as currency
  const formattedAmount = `$${invoice.amount.toFixed(2)}`

  // Format dates
  const dueDate = new Date(invoice.dueDate).toLocaleDateString()

  // Create a mention if Discord ID is available
  const mention = invoice.discordId ? `<@${invoice.discordId}>` : ""

  // Set color based on type
  let color = 0x3498db // Blue for new
  let title = `New Invoice Created`
  let description = `A new invoice has been created for ${invoice.email}.`

  if (type === "paid") {
    color = 0x2ecc71 // Green for paid
    title = `Invoice Paid`
    description = `An invoice has been marked as paid.`
  } else if (type === "overdue") {
    color = 0xe74c3c // Red for overdue
    title = `Invoice Overdue`
    description = `An invoice is now overdue.`
  }

  // Add mention to description if available
  if (mention) {
    description += `\n${mention}`
  }

  // Create the webhook payload
  return {
    embeds: [
      {
        title: `${title} - ${formattedAmount}`,
        description,
        color,
        fields: [
          {
            name: "Invoice ID",
            value: invoice.id,
            inline: true,
          },
          {
            name: "Email",
            value: invoice.email,
            inline: true,
          },
          {
            name: "Amount",
            value: formattedAmount,
            inline: true,
          },
          {
            name: "Status",
            value: invoice.status.charAt(0).toUpperCase() + invoice.status.slice(1),
            inline: true,
          },
          {
            name: "Description",
            value: invoice.description || "No description provided",
          },
          {
            name: "Due Date",
            value: dueDate,
            inline: true,
          },
        ],
        timestamp: new Date().toISOString(),
        footer: {
          text: "FluxCloud Invoice System",
        },
      },
    ],
  }
}

