type NotificationType = "info" | "success" | "warning" | "error"

interface DiscordNotificationOptions {
  title?: string
  type?: NotificationType
  fields?: Array<{ name: string; value: string; inline?: boolean }>
  footer?: string
}

export async function sendDiscordNotification(message: string, options: DiscordNotificationOptions = {}) {
  try {
    if (!process.env.DISCORD_WEBHOOK_URL) {
      console.warn("Discord webhook URL not configured")
      return
    }

    // Set color based on notification type
    let color: number
    switch (options.type) {
      case "success":
        color = 0x2e8b57 // Navy green
        break
      case "warning":
        color = 0xffd700 // Navy yellow
        break
      case "error":
        color = 0xff0000 // Red
        break
      case "info":
      default:
        color = 0x00bfff // Cyan
        break
    }

    const payload = {
      embeds: [
        {
          title: options.title || "FluxCloud Notification",
          description: message,
          color: color,
          timestamp: new Date().toISOString(),
          fields: options.fields || [],
          footer: options.footer ? { text: options.footer } : undefined,
        },
      ],
    }

    const response = await fetch(process.env.DISCORD_WEBHOOK_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    })

    if (!response.ok) {
      throw new Error(`Discord notification failed: ${response.statusText}`)
    }
  } catch (error) {
    console.error("Error sending Discord notification:", error)
  }
}

