import type React from "react"
import type { LucideIcon } from "lucide-react"
import { cn } from "@/lib/utils"

interface EmptyPlaceholderProps {
  icon?: LucideIcon
  title: string
  description: string
  action?: React.ReactNode
  className?: string
  compact?: boolean
}

export function EmptyPlaceholder({
  icon: Icon,
  title,
  description,
  action,
  className,
  compact = false,
}: EmptyPlaceholderProps) {
  return (
    <div className={cn("flex flex-col items-center justify-center text-center", compact ? "py-6" : "py-12", className)}>
      {Icon && (
        <div className="flex h-20 w-20 items-center justify-center rounded-full bg-fluxcloud-black/60 mb-4">
          <Icon className="h-10 w-10 text-fluxcloud-cyan/50" />
        </div>
      )}
      <h3 className="text-lg font-semibold text-white mb-1">{title}</h3>
      <p className="text-sm text-white/70 mb-6">{description}</p>
      {action && <div>{action}</div>}
    </div>
  )
}

