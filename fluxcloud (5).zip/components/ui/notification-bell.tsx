"use client"

import { useState } from "react"
import { Bell } from "lucide-react"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { cn } from "@/lib/utils"

type Notification = {
  id: string
  title: string
  message: string
  time: string
  read: boolean
  type: "info" | "warning" | "success" | "error"
}

export function NotificationBell() {
  const [notifications, setNotifications] = useState<Notification[]>([
    {
      id: "1",
      title: "New Client",
      message: "John Doe has registered as a new client.",
      time: "10 minutes ago",
      read: false,
      type: "info",
    },
    {
      id: "2",
      title: "Invoice Paid",
      message: "Invoice #INV-001 has been paid.",
      time: "1 hour ago",
      read: false,
      type: "success",
    },
    {
      id: "3",
      title: "Service Alert",
      message: "CDN service is experiencing degraded performance.",
      time: "2 hours ago",
      read: false,
      type: "warning",
    },
    {
      id: "4",
      title: "Support Ticket",
      message: "New support ticket #1234 has been created.",
      time: "3 hours ago",
      read: true,
      type: "info",
    },
    {
      id: "5",
      title: "System Update",
      message: "System maintenance scheduled for tonight at 2 AM.",
      time: "5 hours ago",
      read: true,
      type: "info",
    },
  ])

  const unreadCount = notifications.filter((n) => !n.read).length

  const markAllAsRead = () => {
    setNotifications(notifications.map((n) => ({ ...n, read: true })))
  }

  const markAsRead = (id: string) => {
    setNotifications(notifications.map((n) => (n.id === id ? { ...n, read: true } : n)))
  }

  const getTypeStyles = (type: Notification["type"]) => {
    switch (type) {
      case "info":
        return "bg-fluxcloud-cyan/10 border-fluxcloud-cyan"
      case "warning":
        return "bg-fluxcloud-navy-yellow/10 border-fluxcloud-navy-yellow"
      case "success":
        return "bg-fluxcloud-navy-green/10 border-fluxcloud-navy-green"
      case "error":
        return "bg-red-500/10 border-red-500"
      default:
        return "bg-fluxcloud-cyan/10 border-fluxcloud-cyan"
    }
  }

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" className="relative">
          <Bell className="h-5 w-5 text-white/70" />
          {unreadCount > 0 && (
            <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-fluxcloud-cyan text-[10px] font-medium text-black">
              {unreadCount}
            </span>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80 p-0 bg-fluxcloud-black border border-white/10" align="end">
        <div className="flex items-center justify-between border-b border-white/10 px-4 py-2">
          <h4 className="font-medium text-white">Notifications</h4>
          {unreadCount > 0 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={markAllAsRead}
              className="h-auto p-0 text-xs text-fluxcloud-cyan hover:text-fluxcloud-cyan/80 hover:bg-transparent"
            >
              Mark all as read
            </Button>
          )}
        </div>
        <ScrollArea className="h-[300px]">
          {notifications.length > 0 ? (
            <div className="flex flex-col">
              {notifications.map((notification) => (
                <div
                  key={notification.id}
                  className={cn(
                    "flex flex-col gap-1 border-l-2 px-4 py-3 transition-colors hover:bg-white/5",
                    notification.read ? "border-transparent" : getTypeStyles(notification.type),
                    notification.read ? "bg-transparent" : "bg-white/5",
                  )}
                  onClick={() => markAsRead(notification.id)}
                >
                  <div className="flex items-center justify-between">
                    <h5 className={cn("font-medium", notification.read ? "text-white/70" : "text-white")}>
                      {notification.title}
                    </h5>
                    <span className="text-xs text-white/50">{notification.time}</span>
                  </div>
                  <p className="text-sm text-white/70">{notification.message}</p>
                </div>
              ))}
            </div>
          ) : (
            <div className="flex h-full items-center justify-center">
              <p className="text-sm text-white/50">No notifications</p>
            </div>
          )}
        </ScrollArea>
        <div className="border-t border-white/10 p-2">
          <Button
            variant="outline"
            size="sm"
            className="w-full border-white/10 text-white hover:bg-white/10 hover:text-fluxcloud-cyan"
          >
            View all notifications
          </Button>
        </div>
      </PopoverContent>
    </Popover>
  )
}

