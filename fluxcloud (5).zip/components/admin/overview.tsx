"use client"

import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts"
import { EmptyPlaceholder } from "@/components/empty-placeholder"
import { BarChart3 } from "lucide-react"

// Empty data for initial state
const emptyData = [
  { name: "Jan", total: 0 },
  { name: "Feb", total: 0 },
  { name: "Mar", total: 0 },
  { name: "Apr", total: 0 },
  { name: "May", total: 0 },
  { name: "Jun", total: 0 },
  { name: "Jul", total: 0 },
  { name: "Aug", total: 0 },
  { name: "Sep", total: 0 },
  { name: "Oct", total: 0 },
  { name: "Nov", total: 0 },
  { name: "Dec", total: 0 },
]

export function Overview() {
  // Check if all values are zero
  const hasData = emptyData.some((item) => item.total > 0)

  if (!hasData) {
    return (
      <EmptyPlaceholder
        icon={BarChart3}
        title="No revenue data yet"
        description="Revenue data will appear here once you start generating income"
      />
    )
  }

  return (
    <ResponsiveContainer width="100%" height={350}>
      <BarChart data={emptyData} margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
        <defs>
          <linearGradient id="barGradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#00BFFF" stopOpacity={0.8} />
            <stop offset="100%" stopColor="#00BFFF" stopOpacity={0.2} />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="rgba(255, 255, 255, 0.1)" />
        <XAxis
          dataKey="name"
          stroke="rgba(255, 255, 255, 0.5)"
          fontSize={12}
          tickLine={false}
          axisLine={{ stroke: "rgba(255, 255, 255, 0.2)" }}
        />
        <YAxis
          stroke="rgba(255, 255, 255, 0.5)"
          fontSize={12}
          tickLine={false}
          axisLine={{ stroke: "rgba(255, 255, 255, 0.2)" }}
          tickFormatter={(value) => `₹${value}`}
        />
        <Tooltip
          formatter={(value) => [`₹${value}`, "Revenue"]}
          cursor={{ fill: "rgba(255, 255, 255, 0.05)" }}
          contentStyle={{
            backgroundColor: "rgba(18, 18, 18, 0.9)",
            border: "1px solid rgba(0, 191, 255, 0.3)",
            borderRadius: "6px",
            boxShadow: "0 4px 12px rgba(0, 0, 0, 0.5)",
            color: "white",
          }}
          itemStyle={{ color: "#00BFFF" }}
          labelStyle={{ color: "white", fontWeight: "bold" }}
        />
        <Bar
          dataKey="total"
          fill="url(#barGradient)"
          radius={[4, 4, 0, 0]}
          animationDuration={1500}
          animationEasing="ease-in-out"
        />
      </BarChart>
    </ResponsiveContainer>
  )
}

