"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  BarChart3,
  Cloud,
  CreditCard,
  FileText,
  HelpCircle,
  LayoutDashboard,
  LogOut,
  Settings,
  Users,
  Wallet,
} from "lucide-react"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { useAuth } from "@/components/auth-provider"
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from "@/components/ui/sidebar"

export function AdminSidebar() {
  const pathname = usePathname()
  const { logout } = useAuth()

  const routes = [
    {
      title: "Dashboard",
      icon: LayoutDashboard,
      href: "/admin/dashboard",
    },
    {
      title: "Clients",
      icon: Users,
      href: "/admin/clients",
    },
    {
      title: "Services",
      icon: Cloud,
      href: "/admin/services",
    },
    {
      title: "Invoices",
      icon: FileText,
      href: "/admin/invoices",
    },
    {
      title: "Payments",
      icon: CreditCard,
      href: "/admin/payments",
    },
    {
      title: "Support Tickets",
      icon: HelpCircle,
      href: "/admin/support",
    },
    {
      title: "Expenses",
      icon: Wallet,
      href: "/admin/expenses",
    },
    {
      title: "Analytics",
      icon: BarChart3,
      href: "/admin/analytics",
    },
    {
      title: "Settings",
      icon: Settings,
      href: "/admin/settings",
    },
  ]

  return (
    <Sidebar className="bg-fluxcloud-black border-r border-white/10">
      <SidebarHeader className="border-b border-white/10 px-6 py-3">
        <Link href="/admin/dashboard" className="flex items-center gap-2 font-bold text-white">
          <Cloud className="h-6 w-6 text-fluxcloud-cyan animate-pulse" />
          <span className="text-lg tracking-tight">FluxCloud</span>
        </Link>
      </SidebarHeader>
      <SidebarContent className="bg-fluxcloud-black">
        <ScrollArea className="h-[calc(100vh-8rem)]">
          <SidebarMenu>
            {routes.map((route) => (
              <SidebarMenuItem key={route.href}>
                <SidebarMenuButton
                  asChild
                  isActive={pathname === route.href}
                  tooltip={route.title}
                  className={cn(
                    "text-white/70 hover:text-white hover:bg-white/10 transition-all duration-200",
                    pathname === route.href && "bg-fluxcloud-cyan/20 text-fluxcloud-cyan shadow-neon-cyan",
                  )}
                >
                  <Link href={route.href}>
                    <route.icon
                      className={cn("h-5 w-5", pathname === route.href ? "text-fluxcloud-cyan" : "text-white/70")}
                    />
                    <span>{route.title}</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
            ))}
          </SidebarMenu>
        </ScrollArea>
      </SidebarContent>
      <SidebarFooter className="border-t border-white/10 p-4 bg-fluxcloud-black">
        <Button
          variant="outline"
          className="w-full justify-start text-white border-white/10 hover:bg-white/10 hover:text-fluxcloud-cyan btn-hover-effect"
          onClick={logout}
        >
          <LogOut className="mr-2 h-4 w-4" />
          Logout
        </Button>
      </SidebarFooter>
    </Sidebar>
  )
}

