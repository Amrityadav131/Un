import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export function RecentSales() {
  return (
    <div className="space-y-8">
      <div className="flex items-center">
        <Avatar className="h-9 w-9">
          <AvatarImage src="/placeholder.svg" alt="Avatar" />
          <AvatarFallback className="bg-fluxcloud-cyan/20 text-fluxcloud-cyan">JD</AvatarFallback>
        </Avatar>
        <div className="ml-4 space-y-1">
          <p className="text-sm font-medium leading-none text-white">John Doe</p>
          <p className="text-sm text-white/70">john.doe@example.com</p>
        </div>
        <div className="ml-auto font-medium text-green-500">Active</div>
      </div>
      <div className="flex items-center">
        <Avatar className="h-9 w-9">
          <AvatarImage src="/placeholder.svg" alt="Avatar" />
          <AvatarFallback className="bg-fluxcloud-navy-green/20 text-fluxcloud-navy-green">JL</AvatarFallback>
        </Avatar>
        <div className="ml-4 space-y-1">
          <p className="text-sm font-medium leading-none text-white">Jane Lane</p>
          <p className="text-sm text-white/70">jane.lane@example.com</p>
        </div>
        <div className="ml-auto font-medium text-green-500">Active</div>
      </div>
      <div className="flex items-center">
        <Avatar className="h-9 w-9">
          <AvatarImage src="/placeholder.svg" alt="Avatar" />
          <AvatarFallback className="bg-fluxcloud-navy-yellow/20 text-fluxcloud-navy-yellow">SD</AvatarFallback>
        </Avatar>
        <div className="ml-4 space-y-1">
          <p className="text-sm font-medium leading-none text-white">Sarah Davis</p>
          <p className="text-sm text-white/70">sarah.davis@example.com</p>
        </div>
        <div className="ml-auto font-medium text-yellow-500">Pending</div>
      </div>
      <div className="flex items-center">
        <Avatar className="h-9 w-9">
          <AvatarImage src="/placeholder.svg" alt="Avatar" />
          <AvatarFallback className="bg-fluxcloud-cyan/20 text-fluxcloud-cyan">RK</AvatarFallback>
        </Avatar>
        <div className="ml-4 space-y-1">
          <p className="text-sm font-medium leading-none text-white">Raj Kumar</p>
          <p className="text-sm text-white/70">raj.kumar@example.com</p>
        </div>
        <div className="ml-auto font-medium text-green-500">Active</div>
      </div>
      <div className="flex items-center">
        <Avatar className="h-9 w-9">
          <AvatarImage src="/placeholder.svg" alt="Avatar" />
          <AvatarFallback className="bg-fluxcloud-navy-green/20 text-fluxcloud-navy-green">AS</AvatarFallback>
        </Avatar>
        <div className="ml-4 space-y-1">
          <p className="text-sm font-medium leading-none text-white">Anita Singh</p>
          <p className="text-sm text-white/70">anita.singh@example.com</p>
        </div>
        <div className="ml-auto font-medium text-gray-500">Inactive</div>
      </div>
    </div>
  )
}

