"use client"

/**
 * Client Stats Display Component
 * Software made by nikhil & arpit | AuraNodes 2025
 */

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Cloud, FileText, DollarSign } from "lucide-react"
import { useAuth } from "@/components/auth-provider"

interface ClientStats {
  activeServices: number
  pendingInvoices: number
  totalSpent: number
}

export function ClientStatsDisplay() {
  const { user } = useAuth()
  const [stats, setStats] = useState<ClientStats>({
    activeServices: 0,
    pendingInvoices: 0,
    totalSpent: 0,
  })
  const [loading, setLoading] = useState(true)
  const apiUrl = process.env.NEXT_PUBLIC_API_URL || "/api"

  useEffect(() => {
    const fetchStats = async () => {
      if (!user) return

      try {
        const response = await fetch(`${apiUrl}/clients/stats`, {
          credentials: "include",
        })

        if (response.ok) {
          const data = await response.json()
          setStats(data)
        }
      } catch (error) {
        console.error("Error fetching client stats:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchStats()
  }, [user, apiUrl])

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
      <div>
        <Card className="glass-card border-white/10 card-hover-lift">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-white">Active Services</CardTitle>
            <Cloud className="h-4 w-4 text-fluxcloud-cyan" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white neon-text-cyan">
              {loading ? (
                <div className="h-8 w-8 rounded-full border-2 border-fluxcloud-cyan border-t-transparent animate-spin"></div>
              ) : (
                stats.activeServices
              )}
            </div>
            <p className="text-xs text-white/70">
              {stats.activeServices === 0
                ? "No active services yet"
                : stats.activeServices === 1
                  ? "1 service running"
                  : `${stats.activeServices} services running`}
            </p>
          </CardContent>
        </Card>
      </div>

      <div>
        <Card className="glass-card border-white/10 card-hover-lift">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-white">Pending Invoices</CardTitle>
            <FileText className="h-4 w-4 text-fluxcloud-navy-yellow" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white neon-text-yellow">
              {loading ? (
                <div className="h-8 w-8 rounded-full border-2 border-fluxcloud-navy-yellow border-t-transparent animate-spin"></div>
              ) : (
                stats.pendingInvoices
              )}
            </div>
            <p className="text-xs text-white/70">
              {stats.pendingInvoices === 0
                ? "No pending invoices"
                : stats.pendingInvoices === 1
                  ? "1 invoice pending"
                  : `${stats.pendingInvoices} invoices pending`}
            </p>
          </CardContent>
        </Card>
      </div>

      <div>
        <Card className="glass-card border-white/10 card-hover-lift">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-white">Total Spent</CardTitle>
            <DollarSign className="h-4 w-4 text-fluxcloud-navy-green" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white neon-text-green">
              {loading ? (
                <div className="h-8 w-8 rounded-full border-2 border-fluxcloud-navy-green border-t-transparent animate-spin"></div>
              ) : (
                `₹${stats.totalSpent.toFixed(2)}`
              )}
            </div>
            <p className="text-xs text-white/70">
              {stats.totalSpent === 0 ? "No payments made yet" : "Total amount spent on services"}
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

