import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"

export function ClientServicesList() {
  const services = [
    {
      id: "srv-001",
      name: "Web Hosting - Premium",
      status: "active",
      nextBilling: "April 30, 2023",
      price: "₹1,200/month",
    },
    {
      id: "srv-002",
      name: "Database Cluster",
      status: "active",
      nextBilling: "April 30, 2023",
      price: "₹2,500/month",
    },
    {
      id: "srv-003",
      name: "Email Service - Business",
      status: "active",
      nextBilling: "May 15, 2023",
      price: "₹750/month",
    },
    {
      id: "srv-004",
      name: "CDN Service",
      status: "active",
      nextBilling: "May 15, 2023",
      price: "₹1,800/month",
    },
    {
      id: "srv-005",
      name: "Cloud Storage - 500GB",
      status: "active",
      nextBilling: "April 30, 2023",
      price: "₹900/month",
    },
  ]

  return (
    <div className="space-y-4">
      {services.map((service) => (
        <div key={service.id} className="flex items-center justify-between border-b border-white/10 pb-4">
          <div className="space-y-1">
            <div className="font-medium text-white">{service.name}</div>
            <div className="text-sm text-white/70">Next billing: {service.nextBilling}</div>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-sm font-medium text-white">{service.price}</div>
            <Badge
              variant={service.status === "active" ? "default" : "secondary"}
              className="bg-green-500 text-black hover:bg-green-600"
            >
              {service.status === "active" ? "Active" : "Inactive"}
            </Badge>
            <Button
              variant="outline"
              size="sm"
              className="border-white/10 text-white hover:bg-white/10 hover:text-fluxcloud-cyan"
            >
              Manage
            </Button>
          </div>
        </div>
      ))}
      <Button
        variant="outline"
        className="w-full border-white/10 text-white hover:bg-white/10 hover:text-fluxcloud-cyan"
      >
        View All Services
      </Button>
    </div>
  )
}

