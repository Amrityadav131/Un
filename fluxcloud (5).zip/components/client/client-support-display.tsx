"use client"

/**
 * Client Support Display Component
 * Software made by nikhil & arpit | AuraNodes 2025
 */

import { useEffect, useState } from "react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { useAuth } from "@/components/auth-provider"
import { EmptyPlaceholder } from "@/components/empty-placeholder"
import { HelpCircle, AlertCircle } from "lucide-react"

interface SupportTicket {
  id: string
  title: string
  status: "OPEN" | "IN_PROGRESS" | "RESOLVED" | "CLOSED"
  priority: "LOW" | "MEDIUM" | "HIGH" | "CRITICAL"
  createdAt: string
  updatedAt: string
}

export function ClientSupportDisplay() {
  const { user } = useAuth()
  const [tickets, setTickets] = useState<SupportTicket[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const apiUrl = process.env.NEXT_PUBLIC_API_URL || "/api"

  useEffect(() => {
    const fetchTickets = async () => {
      if (!user) return

      try {
        const response = await fetch(`${apiUrl}/clients/support-tickets`, {
          credentials: "include",
        })

        if (response.ok) {
          const data = await response.json()
          setTickets(data)
        } else {
          const errorData = await response.json()
          setError(errorData.message || "Failed to load support tickets")
        }
      } catch (error) {
        console.error("Error fetching support tickets:", error)
        setError("Failed to load support tickets. Please try again later.")
      } finally {
        setLoading(false)
      }
    }

    fetchTickets()
  }, [user, apiUrl])

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <div className="h-12 w-12 rounded-full border-4 border-fluxcloud-cyan border-t-transparent animate-spin"></div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center py-8 text-center">
        <AlertCircle className="h-12 w-12 text-red-500 mb-4" />
        <h3 className="text-lg font-semibold text-white">Error Loading Tickets</h3>
        <p className="text-white/70 mt-1">{error}</p>
        <Button
          onClick={() => window.location.reload()}
          variant="outline"
          className="mt-4 border-white/10 text-white hover:bg-white/10 hover:text-fluxcloud-cyan"
        >
          Try Again
        </Button>
      </div>
    )
  }

  if (tickets.length === 0) {
    return (
      <EmptyPlaceholder
        icon={HelpCircle}
        title="No support tickets"
        description="Create a ticket if you need assistance"
        action={
          <Button
            size="sm"
            variant="outline"
            className="border-white/10 text-white hover:bg-white/10 hover:text-fluxcloud-cyan btn-hover-effect"
          >
            Create Ticket
          </Button>
        }
        compact
      />
    )
  }

  // Only show open or in progress tickets
  const activeTickets = tickets.filter((ticket) => ticket.status === "OPEN" || ticket.status === "IN_PROGRESS")

  if (activeTickets.length === 0) {
    return (
      <EmptyPlaceholder
        icon={HelpCircle}
        title="No active tickets"
        description="All your support tickets have been resolved"
        action={
          <Button
            size="sm"
            variant="outline"
            className="border-white/10 text-white hover:bg-white/10 hover:text-fluxcloud-cyan btn-hover-effect"
          >
            Create Ticket
          </Button>
        }
        compact
      />
    )
  }

  return (
    <div className="space-y-4">
      {activeTickets.map((ticket, index) => (
        <div key={ticket.id} className="rounded-md border border-white/10 bg-white/5 p-3">
          <div className="flex items-center justify-between mb-2">
            <div className="font-medium text-white">{ticket.title}</div>
            <Badge
              className={
                ticket.priority === "LOW"
                  ? "bg-blue-500 text-white"
                  : ticket.priority === "MEDIUM"
                    ? "bg-yellow-500 text-black"
                    : ticket.priority === "HIGH"
                      ? "bg-orange-500 text-black"
                      : "bg-red-500 text-white"
              }
            >
              {ticket.priority}
            </Badge>
          </div>
          <div className="flex items-center justify-between">
            <div className="text-sm text-white/70">
              Ticket #{ticket.id.substring(0, 8)} - {ticket.status.replace("_", " ")}
            </div>
            <Button
              size="sm"
              variant="outline"
              className="border-white/10 text-white hover:bg-white/10 hover:text-fluxcloud-cyan"
            >
              View
            </Button>
          </div>
        </div>
      ))}
      <Button
        variant="outline"
        className="w-full border-white/10 text-white hover:bg-white/10 hover:text-fluxcloud-cyan btn-hover-effect"
      >
        View All Tickets
      </Button>
    </div>
  )
}

