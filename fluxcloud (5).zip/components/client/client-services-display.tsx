"use client"

import React from "react"

/**
 * Client Services Display Component
 * Software made by nikhil & arpit | AuraNodes 2025
 */

import { useEffect, useState } from "react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { useAuth } from "@/components/auth-provider"
import { EmptyPlaceholder } from "@/components/empty-placeholder"
import { Cloud, ExternalLink, AlertCircle } from "lucide-react"

interface Service {
  id: string
  name: string
  description: string
  status: "ACTIVE" | "PENDING" | "INACTIVE"
  price: number
  nextBillingDate: string
}

interface ClientServicesDisplayProps {
  compact?: boolean
}

export function ClientServicesDisplay({ compact = false }: ClientServicesDisplayProps) {
  const { user } = useAuth()
  const [services, setServices] = useState<Service[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const apiUrl = process.env.NEXT_PUBLIC_API_URL || "/api"

  useEffect(() => {
    const fetchServices = async () => {
      if (!user) return

      try {
        const response = await fetch(`${apiUrl}/clients/services`, {
          credentials: "include",
        })

        if (response.ok) {
          const data = await response.json()
          setServices(data)
        } else {
          const errorData = await response.json()
          setError(errorData.message || "Failed to load services")
        }
      } catch (error) {
        console.error("Error fetching client services:", error)
        setError("Failed to load services. Please try again later.")
      } finally {
        setLoading(false)
      }
    }

    fetchServices()
  }, [user, apiUrl])

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <div className="h-12 w-12 rounded-full border-4 border-fluxcloud-cyan border-t-transparent animate-spin"></div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center py-8 text-center">
        <AlertCircle className="h-12 w-12 text-red-500 mb-4" />
        <h3 className="text-lg font-semibold text-white">Error Loading Services</h3>
        <p className="text-white/70 mt-1">{error}</p>
        <Button
          onClick={() => window.location.reload()}
          variant="outline"
          className="mt-4 border-white/10 text-white hover:bg-white/10 hover:text-fluxcloud-cyan"
        >
          Try Again
        </Button>
      </div>
    )
  }

  if (services.length === 0) {
    return (
      <EmptyPlaceholder
        icon={Cloud}
        title="No services yet"
        description="Request your first service to get started"
        action={
          <Button
            size="sm"
            className="bg-fluxcloud-cyan text-black hover:bg-fluxcloud-cyan/80 shadow-neon-cyan btn-hover-effect"
          >
            Request Service
          </Button>
        }
      />
    )
  }

  return (
    <div className="space-y-4">
      <React.Fragment>
        {services.slice(0, compact ? 3 : services.length).map((service, index) => (
          <div key={service.id} className="flex items-center justify-between border-b border-white/10 pb-4">
            <div className="space-y-1">
              <div className="font-medium text-white">{service.name}</div>
              <div className="text-sm text-white/70">
                Next billing: {new Date(service.nextBillingDate).toLocaleDateString()}
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-sm font-medium text-white">₹{service.price.toFixed(2)}/month</div>
              <Badge
                variant={service.status === "ACTIVE" ? "default" : "secondary"}
                className={
                  service.status === "ACTIVE"
                    ? "bg-green-500 text-black hover:bg-green-600"
                    : service.status === "PENDING"
                      ? "bg-yellow-500 text-black hover:bg-yellow-600"
                      : "bg-gray-500 text-black hover:bg-gray-600"
                }
              >
                {service.status}
              </Badge>
              <Button
                variant="outline"
                size="sm"
                className="border-white/10 text-white hover:bg-white/10 hover:text-fluxcloud-cyan"
              >
                Manage
              </Button>
            </div>
          </div>
        ))}
      </React.Fragment>

      {compact && services.length > 3 && (
        <Button
          variant="outline"
          className="w-full border-white/10 text-white hover:bg-white/10 hover:text-fluxcloud-cyan btn-hover-effect"
        >
          View All Services
          <ExternalLink className="ml-2 h-4 w-4" />
        </Button>
      )}
    </div>
  )
}

