"use client"

/**
 * Client System Status Component
 * Software made by nikhil & arpit | AuraNodes 2025
 */

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"

interface SystemService {
  name: string
  status: "operational" | "degraded" | "outage" | "maintenance"
}

export function ClientSystemStatus() {
  const [services, setServices] = useState<SystemService[]>([
    { name: "Web Hosting", status: "operational" },
    { name: "Database", status: "operational" },
    { name: "Email Service", status: "operational" },
    { name: "CDN", status: "operational" },
  ])

  const [lastChecked, setLastChecked] = useState<string>("")
  const [loading, setLoading] = useState(false)

  // Set the last checked time on client-side only
  useEffect(() => {
    setLastChecked(new Date().toLocaleTimeString())
  }, [])

  const getStatusColor = (status: string) => {
    switch (status) {
      case "operational":
        return "bg-green-500"
      case "degraded":
        return "bg-yellow-500"
      case "outage":
        return "bg-red-500"
      case "maintenance":
        return "bg-blue-500"
      default:
        return "bg-gray-500"
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case "operational":
        return "Operational"
      case "degraded":
        return "Degraded"
      case "outage":
        return "Outage"
      case "maintenance":
        return "Maintenance"
      default:
        return "Unknown"
    }
  }

  const getStatusTextColor = (status: string) => {
    switch (status) {
      case "operational":
        return "text-green-500"
      case "degraded":
        return "text-yellow-500"
      case "outage":
        return "text-red-500"
      case "maintenance":
        return "text-blue-500"
      default:
        return "text-gray-500"
    }
  }

  const refreshStatus = () => {
    setLoading(true)

    // Simulate API call
    setTimeout(() => {
      setLastChecked(new Date().toLocaleTimeString())
      setLoading(false)
    }, 1000)
  }

  const allOperational = services.every((service) => service.status === "operational")

  return (
    <div className="space-y-4">
      <div className="text-2xl font-bold text-white">
        {allOperational ? (
          <span className="text-green-500">All Systems Operational</span>
        ) : (
          <span className="text-yellow-500">Some Systems Degraded</span>
        )}
      </div>
      <p className="text-xs text-white/70 mt-1">
        {lastChecked ? `Last checked: ${lastChecked}` : "Checking status..."}
      </p>

      <div className="space-y-3 mt-4">
        {services.map((service, index) => (
          <div key={service.name} className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className={`h-2 w-2 rounded-full ${getStatusColor(service.status)}`}></div>
              <p className="text-sm font-medium text-white">{service.name}</p>
            </div>
            <div className={`text-sm ${getStatusTextColor(service.status)}`}>{getStatusText(service.status)}</div>
          </div>
        ))}
      </div>

      <Button
        variant="outline"
        size="sm"
        className="w-full border-white/10 text-white hover:bg-white/10 hover:text-fluxcloud-cyan btn-hover-effect"
        onClick={refreshStatus}
        disabled={loading}
      >
        {loading ? (
          <>
            <div className="h-4 w-4 rounded-full border-2 border-current border-t-transparent animate-spin mr-2"></div>
            Refreshing...
          </>
        ) : (
          "Refresh Status"
        )}
      </Button>
    </div>
  )
}

