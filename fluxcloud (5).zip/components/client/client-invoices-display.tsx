"use client"

/**
 * Client Invoices Display Component
 * Software made by nikhil & arpit | AuraNodes 2025
 */

import { useEffect, useState, React } from "react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { useAuth } from "@/components/auth-provider"
import { EmptyPlaceholder } from "@/components/empty-placeholder"
import { ExternalLink, AlertCircle, CreditCard } from "lucide-react"

interface Invoice {
  id: string
  invoiceNumber: string
  amount: number
  status: "PAID" | "PENDING" | "OVERDUE" | "CANCELLED"
  dueDate: string
  items: Array<{
    description: string
    amount: number
  }>
}

interface ClientInvoicesDisplayProps {
  compact?: boolean
}

export function ClientInvoicesDisplay({ compact = false }: ClientInvoicesDisplayProps) {
  const { user } = useAuth()
  const [invoices, setInvoices] = useState<Invoice[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const apiUrl = process.env.NEXT_PUBLIC_API_URL || "/api"

  useEffect(() => {
    const fetchInvoices = async () => {
      if (!user) return

      try {
        const response = await fetch(`${apiUrl}/clients/invoices`, {
          credentials: "include",
        })

        if (response.ok) {
          const data = await response.json()
          setInvoices(data)
        } else {
          const errorData = await response.json()
          setError(errorData.message || "Failed to load invoices")
        }
      } catch (error) {
        console.error("Error fetching client invoices:", error)
        setError("Failed to load invoices. Please try again later.")
      } finally {
        setLoading(false)
      }
    }

    fetchInvoices()
  }, [user, apiUrl])

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <div className="h-12 w-12 rounded-full border-4 border-fluxcloud-cyan border-t-transparent animate-spin"></div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center py-8 text-center">
        <AlertCircle className="h-12 w-12 text-red-500 mb-4" />
        <h3 className="text-lg font-semibold text-white">Error Loading Invoices</h3>
        <p className="text-white/70 mt-1">{error}</p>
        <Button
          onClick={() => window.location.reload()}
          variant="outline"
          className="mt-4 border-white/10 text-white hover:bg-white/10 hover:text-fluxcloud-cyan"
        >
          Try Again
        </Button>
      </div>
    )
  }

  if (invoices.length === 0) {
    return (
      <EmptyPlaceholder
        icon={CreditCard}
        title="No upcoming payments"
        description="Your upcoming payments will appear here"
        compact={compact}
      />
    )
  }

  // Sort invoices by due date (most recent first)
  const sortedInvoices = [...invoices].sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime())

  // For compact view, only show pending or overdue invoices
  const filteredInvoices = compact
    ? sortedInvoices.filter((inv) => inv.status === "PENDING" || inv.status === "OVERDUE")
    : sortedInvoices

  return (
    <div className="space-y-4">
      <React.Fragment>
        {filteredInvoices.slice(0, compact ? 2 : filteredInvoices.length).map((invoice, index) => (
          <div key={invoice.id} className="flex items-center justify-between border-b border-white/10 pb-4">
            <div className="space-y-1">
              <div className="font-medium text-white">{invoice.invoiceNumber}</div>
              <div className="text-sm text-white/70">Due: {new Date(invoice.dueDate).toLocaleDateString()}</div>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-sm font-medium text-white">₹{invoice.amount.toFixed(2)}</div>
              <Badge
                variant={invoice.status === "PAID" ? "default" : "secondary"}
                className={
                  invoice.status === "PAID"
                    ? "bg-green-500 text-black hover:bg-green-600"
                    : invoice.status === "PENDING"
                      ? "bg-yellow-500 text-black hover:bg-yellow-600"
                      : invoice.status === "OVERDUE"
                        ? "bg-red-500 text-black hover:bg-red-600"
                        : "bg-gray-500 text-black hover:bg-gray-600"
                }
              >
                {invoice.status}
              </Badge>
              {invoice.status !== "PAID" && (
                <Button
                  size="sm"
                  className="bg-fluxcloud-cyan text-black hover:bg-fluxcloud-cyan/80 shadow-neon-cyan btn-hover-effect"
                >
                  Pay Now
                </Button>
              )}
            </div>
          </div>
        ))}
      </React.Fragment>

      {compact && filteredInvoices.length > 2 && (
        <Button
          variant="outline"
          className="w-full border-white/10 text-white hover:bg-white/10 hover:text-fluxcloud-cyan btn-hover-effect"
        >
          View All Invoices
          <ExternalLink className="ml-2 h-4 w-4" />
        </Button>
      )}

      {filteredInvoices.length === 0 && compact && (
        <EmptyPlaceholder
          icon={CreditCard}
          title="No upcoming payments"
          description="Your upcoming payments will appear here"
          compact
        />
      )}
    </div>
  )
}

