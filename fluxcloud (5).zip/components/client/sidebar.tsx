"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  Cloud,
  CreditCard,
  FileText,
  HelpCircle,
  LayoutDashboard,
  LogOut,
  Settings,
  User,
  Search,
  ShieldAlert,
} from "lucide-react"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { useAuth } from "@/components/auth-provider"
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarInput,
  SidebarSeparator,
} from "@/components/ui/sidebar"
import { Badge } from "@/components/ui/badge"

export function ClientSidebar() {
  const pathname = usePathname()
  const { user, logout } = useAuth()

  const routes = [
    {
      title: "Dashboard",
      icon: LayoutDashboard,
      href: "/client/dashboard",
    },
    {
      title: "Services",
      icon: Cloud,
      href: "/client/services",
    },
    {
      title: "Invoices",
      icon: FileText,
      href: "/client/invoices",
    },
    {
      title: "Payments",
      icon: CreditCard,
      href: "/client/payments",
    },
    {
      title: "Support",
      icon: HelpCircle,
      href: "/client/support",
    },
    {
      title: "Profile",
      icon: User,
      href: "/client/profile",
    },
    {
      title: "Settings",
      icon: Settings,
      href: "/client/settings",
    },
  ]

  return (
    <Sidebar className="bg-fluxcloud-black/80 border-r border-white/10 backdrop-blur-md z-20">
      <SidebarHeader className="border-b border-white/10 px-6 py-3">
        <Link href="/client/dashboard" className="flex items-center gap-2 font-bold text-white">
          <Cloud className="h-6 w-6 text-fluxcloud-cyan animate-pulse" />
          <span className="text-lg tracking-tight">FluxCloud</span>
        </Link>
      </SidebarHeader>

      <SidebarContent className="bg-transparent">
        <div className="px-4 py-2">
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-white/50" />
            <SidebarInput
              placeholder="Search..."
              className="pl-9 bg-white/5 border-white/10 text-white placeholder:text-white/50"
            />
          </div>
        </div>

        <ScrollArea className="h-[calc(100vh-8rem)]">
          <SidebarMenu>
            {routes.map((route) => (
              <SidebarMenuItem key={route.href}>
                <SidebarMenuButton
                  asChild
                  isActive={pathname === route.href}
                  tooltip={route.title}
                  className={cn(
                    "text-white/70 hover:text-white hover:bg-white/10 transition-all duration-200",
                    pathname === route.href && "bg-fluxcloud-cyan/20 text-fluxcloud-cyan shadow-neon-cyan",
                  )}
                >
                  <Link href={route.href}>
                    <route.icon
                      className={cn("h-5 w-5", pathname === route.href ? "text-fluxcloud-cyan" : "text-white/70")}
                    />
                    <span>{route.title}</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
            ))}
          </SidebarMenu>

          {user?.role === "ADMIN" && (
            <>
              <SidebarSeparator className="my-2" />
              <div className="px-4 py-2">
                <Badge
                  variant="outline"
                  className="w-full justify-center py-1 border-fluxcloud-navy-yellow/30 text-fluxcloud-navy-yellow"
                >
                  Admin Access
                </Badge>
              </div>
              <SidebarMenu>
                <SidebarMenuItem>
                  <SidebarMenuButton
                    asChild
                    tooltip="Admin Dashboard"
                    className="text-fluxcloud-navy-yellow hover:text-fluxcloud-navy-yellow hover:bg-fluxcloud-navy-yellow/10 border border-fluxcloud-navy-yellow/20"
                  >
                    <Link href="/admin/dashboard">
                      <ShieldAlert className="h-5 w-5 text-fluxcloud-navy-yellow" />
                      <span>Admin Dashboard</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              </SidebarMenu>
            </>
          )}
        </ScrollArea>
      </SidebarContent>

      <SidebarFooter className="border-t border-white/10 p-4 bg-fluxcloud-black/50 backdrop-blur-md">
        <Button
          variant="outline"
          className="w-full justify-start text-white border-white/10 hover:bg-white/10 hover:text-fluxcloud-cyan btn-hover-effect"
          onClick={logout}
        >
          <LogOut className="mr-2 h-4 w-4" />
          Logout
        </Button>
      </SidebarFooter>
    </Sidebar>
  )
}

