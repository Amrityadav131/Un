"use client"

import type React from "react"

import { createContext, useContext, useState, useEffect } from "react"
import { useRouter, usePathname } from "next/navigation"

// Define the User type
type User = {
  id: string
  name: string
  email: string
  role: "ADMIN" | "CLIENT"
  avatar: string | null
}

// Define the AuthContext type
type AuthContextType = {
  user: User | null
  loading: boolean
  login: (role: "ADMIN" | "CLIENT") => Promise<boolean>
  logout: () => Promise<void>
  updateUser: (updatedUser: User) => void
}

const AuthContext = createContext<AuthContextType | null>(null)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)
  const router = useRouter()
  const pathname = usePathname()

  useEffect(() => {
    // Check if user is logged in
    const checkAuth = async () => {
      try {
        const response = await fetch(`/api/auth/me`, {
          credentials: "include",
        })

        if (response.ok) {
          const userData = await response.json()
          setUser(userData)
        } else {
          setUser(null)

          // Redirect to login if not on login page or not-authorized page
          if (pathname !== "/login" && pathname !== "/not-authorized" && !pathname.startsWith("/_next")) {
            router.push("/login")
          }
        }
      } catch (error) {
        console.error("Auth check failed:", error)
        setUser(null)
      } finally {
        setLoading(false)
      }
    }

    checkAuth()
  }, [pathname, router])

  const login = async (role: "ADMIN" | "CLIENT"): Promise<boolean> => {
    try {
      const response = await fetch(`/api/auth/login`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify({ role }),
      })

      if (response.ok) {
        const userData = await response.json()
        setUser(userData)

        // Redirect based on role
        if (role === "ADMIN") {
          router.push("/admin/dashboard")
        } else {
          router.push("/client/dashboard")
        }

        return true
      }

      return false
    } catch (error) {
      console.error("Login failed:", error)
      return false
    }
  }

  const logout = async (): Promise<void> => {
    try {
      await fetch(`/api/auth/logout`, {
        method: "POST",
        credentials: "include",
      })

      setUser(null)
      router.push("/login")
    } catch (error) {
      console.error("Logout failed:", error)
    }
  }

  const updateUser = (updatedUser: User): void => {
    setUser(updatedUser)
  }

  return <AuthContext.Provider value={{ user, loading, login, logout, updateUser }}>{children}</AuthContext.Provider>
}

export function useAuth(): AuthContextType {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}

