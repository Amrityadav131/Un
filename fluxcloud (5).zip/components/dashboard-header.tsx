"use client"

import { NotificationBell } from "@/components/ui/notification-bell"
import { UserProfile } from "@/components/ui/user-profile"
import { ModeToggle } from "@/components/ui/mode-toggle"
import { SidebarTrigger } from "@/components/ui/sidebar"
import { Separator } from "@/components/ui/separator"
import { Search } from "lucide-react"
import { Input } from "@/components/ui/input"

interface DashboardHeaderProps {
  title?: string
}

export function DashboardHeader({ title }: DashboardHeaderProps) {
  return (
    <header className="sticky top-0 z-10 flex h-16 items-center gap-4 border-b border-white/10 bg-fluxcloud-black/80 px-6 backdrop-blur-md">
      <SidebarTrigger className="text-white/70 hover:text-white" />
      <Separator orientation="vertical" className="h-6 bg-white/10" />

      {title && (
        <>
          <h1 className="text-lg font-semibold text-white">{title}</h1>
          <div className="flex-1" />
        </>
      )}

      {!title && (
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-white/50" />
          <Input
            type="search"
            placeholder="Search..."
            className="w-full bg-white/5 border-white/10 pl-9 text-white placeholder:text-white/50 focus-visible:ring-fluxcloud-cyan"
          />
        </div>
      )}

      <div className="flex items-center gap-2">
        <NotificationBell />
        <ModeToggle />
        <UserProfile />
      </div>
    </header>
  )
}

