import { LogoutButton } from "@/components/logout-button"

const Sidebar = () => {
  return (
    <aside className="flex flex-col h-full w-64 bg-gray-100 border-r">
      <div className="p-4">Sidebar Content</div>
      <div className="mt-auto pt-4 border-t">
        <LogoutButton />
      </div>
    </aside>
  )
}

export default Sidebar

