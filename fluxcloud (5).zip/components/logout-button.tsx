"use client"

import { Button } from "@/components/ui/button"
import { LogOut } from "lucide-react"
import { useRouter } from "next/navigation"
import { toast } from "@/components/ui/use-toast"

export function LogoutButton() {
  const router = useRouter()

  const handleLogout = () => {
    // Clear the auth cookies
    document.cookie = "auth_token=; path=/; max-age=0"
    document.cookie = "user_role=; path=/; max-age=0"

    toast({
      title: "Logged out",
      description: "You have been successfully logged out",
    })

    // Redirect to login page
    router.push("/login")
  }

  return (
    <Button variant="ghost" size="sm" onClick={handleLogout}>
      <LogOut className="h-4 w-4 mr-2" />
      Logout
    </Button>
  )
}

