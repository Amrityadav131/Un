/**
 * Database Setup Script
 * Software made by nikhil & arpit | AuraNodes 2025
 *
 * Run this script to initialize your database:
 * npx ts-node scripts/setup-db.ts
 */

import { PrismaClient } from "@prisma/client"
import { hash } from "bcryptjs" // Changed from 'bcrypt' to 'bcryptjs'

const prisma = new PrismaClient()

async function main() {
  console.log("🔧 Setting up database...")

  try {
    // Create admin user
    const adminPassword = await hash("admin123", 10)
    const admin = await prisma.user.upsert({
      where: { email: "admin@fluxcloud.com" },
      update: {},
      create: {
        email: "admin@fluxcloud.com",
        name: "Admin User",
        password: adminPassword,
        role: "ADMIN",
      },
    })

    console.log(`✅ Admin user created: ${admin.email}`)

    // Create client user
    const clientPassword = await hash("client123", 10)
    const client = await prisma.user.upsert({
      where: { email: "client@fluxcloud.com" },
      update: {},
      create: {
        email: "client@fluxcloud.com",
        name: "Client User",
        password: clientPassword,
        role: "CLIENT",
        client: {
          create: {
            company: "Demo Company",
            phone: "+1 (555) 123-4567",
            address: "123 Demo Street, Demo City",
            status: "ACTIVE",
          },
        },
      },
    })

    console.log(`✅ Client user created: ${client.email}`)

    // Create sample service
    const clientRecord = await prisma.client.findUnique({
      where: { userId: client.id },
    })

    if (clientRecord) {
      const service = await prisma.service.create({
        data: {
          name: "Web Hosting - Premium",
          description: "High-performance web hosting with 99.9% uptime guarantee",
          price: 1200,
          clientId: clientRecord.id,
          status: "ACTIVE",
        },
      })

      console.log(`✅ Sample service created: ${service.name}`)

      // Create sample invoice
      const invoice = await prisma.invoice.create({
        data: {
          invoiceNumber: `INV-${Date.now().toString().slice(-6)}`,
          clientId: clientRecord.id,
          amount: 1200,
          status: "PENDING",
          dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days from now
          items: {
            create: {
              serviceId: service.id,
              description: "Web Hosting - Premium (Monthly)",
              quantity: 1,
              unitPrice: 1200,
              amount: 1200,
            },
          },
        },
      })

      console.log(`✅ Sample invoice created: ${invoice.invoiceNumber}`)

      // Create sample support ticket
      const ticket = await prisma.supportTicket.create({
        data: {
          title: "Need help with my hosting",
          description: "I am having trouble accessing my hosting control panel.",
          clientId: clientRecord.id,
          userId: client.id,
          status: "OPEN",
          priority: "MEDIUM",
          messages: {
            create: {
              content: "I am having trouble accessing my hosting control panel. Can you help?",
              userId: client.id,
            },
          },
        },
      })

      console.log(`✅ Sample support ticket created: ${ticket.title}`)
    }

    console.log("✅ Database setup completed successfully!")
    console.log("\nLogin credentials:")
    console.log("Admin: admin@fluxcloud.com / admin123")
    console.log("Client: client@fluxcloud.com / client123")
  } catch (error) {
    console.error("❌ Database setup failed:", error)
  } finally {
    await prisma.$disconnect()
  }
}

main()

